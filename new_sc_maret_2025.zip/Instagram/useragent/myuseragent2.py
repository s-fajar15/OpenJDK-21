
import random, os

class DeviceCatalog:
	instagram_app = [
		("368.0.0.45.96", "700073482"),
		("361.0.0.46.88", "674674275"),
		("309.1.0.41.113", "672461242")
	]
	
	def app_version(Jar):
		return [{"version": v, "code": c} for v, c in Jar.instagram_app]
	
	def generate_device(Jar):
		return {
			'OnePlus': [
				{'model': 'OnePlus 9', 'product': 'OnePlus9', 'hardware': 'qcom', 'version': '12'},
				{'model': 'OnePlus 10', 'product': 'OnePlus10', 'hardware': 'qcom', 'version': '13'},
				{'model': 'OnePlus 11', 'product': 'OnePlus11', 'hardware': 'qcom', 'version': '14'},
			],
			'Oppo': [
				{'model': 'Oppo Find X5', 'product': 'FindX5', 'hardware': 'mt6893', 'version': '12'},
				{'model': 'Oppo Reno 8', 'product': 'Reno8', 'hardware': 'mt6893', 'version': '13'},
				{'model': 'Oppo A96', 'product': 'A96', 'hardware': 'mt6833', 'version': '11'},
			],
			'Sony': [
				{'model': 'Xperia 1 III', 'product': 'XQ-BC72', 'hardware': 'qcom', 'version': '12'},
				{'model': 'Xperia 5 III', 'product': 'XQ-BQ72', 'hardware': 'qcom', 'version': '12'},
				{'model': 'Xperia 10 IV', 'product': 'XQ-CC72', 'hardware': 'mt6833', 'version': '13'},
			],
			'Huawei': [
				{'model': 'Mate 40 Pro', 'product': 'NOH-NX9', 'hardware': 'Kirin 9000', 'version': '12'},
				{'model': 'P50 Pro', 'product': 'JAD-AL50', 'hardware': 'Kirin 9000', 'version': '13'},
				{'model': 'Nova 9', 'product': 'NAM-AL00', 'hardware': 'Snapdragon 778G', 'version': '11'},
			],
			'Nokia': [
				{'model': 'Nokia 8.3', 'product': 'TA-1243', 'hardware': 'qcom', 'version': '11'},
				{'model': 'Nokia X20', 'product': 'TA-1338', 'hardware': 'qcom', 'version': '12'},
				{'model': 'Nokia G50', 'product': 'TA-1358', 'hardware': 'qcom', 'version': '13'},
			],
			'Asus': [
				{'model': 'ZenFone 8', 'product': 'ZS590KS', 'hardware': 'qcom', 'version': '12'},
				{'model': 'ROG Phone 5', 'product': 'ZS673KS', 'hardware': 'qcom', 'version': '13'},
				{'model': 'ROG Phone 6', 'product': 'AI2201', 'hardware': 'qcom', 'version': '14'},
			],
			'Motorola': [
				{'model': 'Moto G100', 'product': 'XT2125', 'hardware': 'qcom', 'version': '11'},
				{'model': 'Moto Edge 30', 'product': 'XT2203', 'hardware': 'qcom', 'version': '12'},
				{'model': 'Moto G200', 'product': 'XT2175', 'hardware': 'qcom', 'version': '13'},
			],
			'LG': [
				{'model': 'LG Velvet', 'product': 'LM-G900', 'hardware': 'qcom', 'version': '11'},
				{'model': 'LG Wing', 'product': 'LM-F100', 'hardware': 'qcom', 'version': '12'},
				{'model': 'LG G8X', 'product': 'LM-G850', 'hardware': 'qcom', 'version': '10'},
			],
			'Google': [
				{'model': 'Pixel 6', 'product': 'Pixel6', 'hardware': 'google', 'version': '13'},
				{'model': 'Pixel 7', 'product': 'Pixel7', 'hardware': 'google', 'version': '14'},
				{'model': 'Pixel 8', 'product': 'Pixel8', 'hardware': 'google', 'version': '15'},
			]
		}

class UserAgentGenerator:
	dpi = [
		'240dpi; 1760x792', '240dpi; 1920x864', '320dpi; 2400x1080',
		'400dpi; 3200x1440', '480dpi; 1080x1920', '320dpi; 900x1600',
		'320dpi; 720x1280', '240dpi; 540x960', '280dpi; 1920x1080'
	]
	
	versi_android = {'9': '28', '10': '29', '11': '30', '12': '31', '13': '32', '14': '33'}
	
	def __init__(Jar):
		Jar.device = DeviceCatalog().generate_device()
		Jar.device_list = list(Jar.device.keys())
		Jar.dpi_pixel = random.choice(Jar.dpi)
	
	def android_version(Jar, android_version):
		return Jar.versi_android.get(str(android_version), '34')
	
	def get_device(Jar, brand=None, system=False):
		if system:return Jar.get_system_device()
		if not brand or brand not in Jar.device:
			brand = random.choice(Jar.device_list)
		device = random.choice(Jar.device[brand])
		return {'brand': brand,'model': device['model'],'product': device['product'], 'hardware': device['hardware'],'version': device['version'],'sdk': Jar.android_version(device['version'])}
	
	def get_system_device(Jar):
		try:
			brand = os.popen("getprop ro.product.manufacturer").read().strip()
			model = os.popen("getprop ro.product.device").read().strip()
			product = os.popen("getprop ro.build.product").read().strip()
			hardware = os.popen("getprop ro.hardware").read().strip()
			version = os.popen("getprop ro.build.version.release").read().strip()
			sdk = os.popen("getprop ro.build.version.sdk").read().strip()
			if not brand or not model or not sdk:
				return Jar.get_device()
			return {'brand': brand, 'model': model, 'product': product, 'hardware': hardware, 'version': version, 'sdk': sdk}
		except Exception:
			return Jar.get_device()
	
	def Useragent(Jar, brand=None, system=False):
		device_info = Jar.get_device(brand, system)
		app_version = random.choice(DeviceCatalog().app_version())
		brand, model, product, hardware, version, sdk = device_info.values()
		return f'Instagram {app_version["version"]} Android ({sdk}/{version}; {Jar.dpi_pixel}; {brand}; {model}; {product}; {hardware}; in_ID; {app_version["code"]})'


if __name__ == "__main__":
	UserAgentGenerator()
    