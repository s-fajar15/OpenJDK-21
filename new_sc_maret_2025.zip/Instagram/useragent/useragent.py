import random

class Generateuseragent:
	
	app_version = "368.0.0.45.96"
	app_code = "700073482"
	locale = "in_ID"
	useragent_format = "Instagram %s Android (%s/%s; %s; %s; %s; %s; %s; %s; %s; %s)"
	
	devices = [
		"Google; Pixel 7 Pro; cheetah; qcom",
		"Google; Pixel 8 Pro; husky; qcom",
		"Google; Pixel 6 Pro; raven; qcom",
		"Google; Pixel 5; redfin; qcom",   
		"Samsung; Galaxy S23 Ultra; dm3q; qcom",
		"Samsung; Galaxy S24 Ultra; dm4q; qcom",
		"Samsung; Galaxy S22 Ultra; dm2q; qcom",
		"Samsung; Galaxy S21 Ultra; o1q; qcom",
		"Samsung; Galaxy Z Fold 5; q5q; qcom",
		"Samsung; Galaxy Z Fold 4; q4q; qcom",
		"Samsung; Galaxy Z Flip 5; b5q; qcom",
		"Samsung; Galaxy Z Flip 4; b4q; qcom",
		"Xiaomi; Mi 13 Ultra; ishtar; qcom",
		"Xiaomi; Mi 11 Ultra; star; qcom",
		"Xiaomi; Redmi K60 Pro; mondrian; qcom",
		"Xiaomi; Poco F5 Pro; mondrian; qcom",
		"Xiaomi; Black Shark 5 Pro; katana; qcom",
		"OnePlus; OnePlus 11; ophyx; qcom",
		"OnePlus; OnePlus 12; phi; qcom",
		"OnePlus; OnePlus 10 Pro; ne2211; qcom",
		"OnePlus; OnePlus 9 Pro; le2121; qcom",
		"Sony; Xperia 1 V; pdx-234; qcom",
		"Sony; Xperia 5 V; pdx-241; qcom",
		"Sony; Xperia 1 IV; pdx-223; qcom",
		"Asus; ROG Phone 7; ai2205; qcom",
		"Asus; ROG Phone 8 Pro; ai2401; qcom",
		"Asus; Zenfone 10; ai2302; qcom",
		"Nothing; Phone (2); abel; qcom",
		"Nothing; Phone (1); spacewar; qcom",
		"Realme; GT 3; rmx3709; qcom",
		"Realme; GT Neo 5; rmx3706; qcom",
		"Motorola; Edge 40 Pro; xt2301; qcom",
		"Motorola; Edge+ (2023); xt2301-4; qcom",
		"Motorola; Razr 40 Ultra; xt2321; qcom"
	]
	
	dpi_options = ['320dpi', '400dpi', '440dpi', '480dpi', '560dpi', '640dpi', '720dpi']
	resolution = ['720x1280', '1080x1920', '1080x2400', '1440x2560', '1440x3088', '1600x3200', '2160x3840', '2400x1080', '2560x1440']
	versi_android = {'9': '28', '10': '29', '11': '30', '12': '31', '13': '32', '14': '33'}
	
	def __init__(jar):
		jar._init_from_device_string()
	
	def _init_from_device_string(jar):
		device_string = random.choice(jar.devices)
		jar.manufacturer, jar.model, jar.device, jar.cpu = device_string.split('; ')
		jar.android_ver = str(random.randint(9,14))
		jar.android_api = jar.versi_android.get(jar.android_ver, '34')
		jar.dpi = random.choice(jar.dpi_options)
		jar.pixel = random.choice(jar.resolution)
		jar.useragent = jar.build_useragent()
	
	def build_useragent(jar):
		return jar.useragent_format % (
			jar.app_version,jar.android_api,jar.android_ver,
			jar.dpi,jar.pixel,jar.manufacturer,
			jar.model,jar.device,jar.cpu,
			jar.locale,jar.app_code,
		)
	
	def instagram(jar):
		return jar.useragent

if __name__ == "__main__":
	ua = Generateuseragent()