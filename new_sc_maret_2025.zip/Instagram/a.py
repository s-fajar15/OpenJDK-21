from nacl.public import PrivateKey

private_key = PrivateKey.generate()
public_key = private_key.public_key

print("Public Key (Base64):", public_key.encode().hex())