
from config.profilpic import UploadProfile

def main(cookie):
	UploadProfile(cookie).ganti_profie()
	up_id = UploadProfile(cookie).upload1()
	profile = UploadProfile(cookie).upload2(up_id)
	print(profile)

cookie = 'datr=sZfMZ-ErZkCI34igNL14viTQ; ig_did=DA20232B-6E30-4E10-9904-99FEADCC1CC0; dpr=1.712499976158142; mid=Z8yXsQABAAFgxtT5eQlMotUFEhsM; ps_l=1; ps_n=1; ig_nrcb=1; csrftoken=eDCFEIr5fma5hOsgBj6c8pjEAq5iK6Q5; ds_user_id=72920169756; sessionid=72920169756%3Ab3jFnFW5Z13KyX%3A14%3AAYd3hL9kI7YasM2UslyierorBaiteRUXi1dkj8aGLA; wd=421x803; rur="HIL\05472920169756\0541773275202:01f7b0a048e2c9c5745a40a8a342b395acd575399ebeaf0f5b98ef139a25b87e0c01b274"'
main(cookie)