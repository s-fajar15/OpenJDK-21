import requests
from bs4 import BeautifulSoup

class FakeIdent:
	def __init__(Jar):
		pass
	
	def generate_name(Jar):
		try:
			with requests.Session() as r:
				headers = {'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36"}
				response = requests.get("https://www.behindthename.com/random/random.php?gender=f&number=2&sets=1&surname=&usage_ins=1", headers=headers)
				soup = BeautifulSoup(response.text, "html.parser")
				name = soup.select("div.random-results a.plain")
				nama = " ".join([nama.text.strip() for nama in name])
				return nama
		except Exception as e:print(e)
		