import requests, re, random, time, os, json

P = '\033[0m'
H = "\033[32m"
A = "\033[1;30m"
M = '\x1b[1;91m'

class UploadProfile:
	def __init__(Jar, cookie):
		Jar.cookies = cookie
		Jar.random_file = random.choice(os.listdir("Profile"))
		Jar.file_path = os.path.join('Profile', Jar.random_file)
		Jar.img = os.path.getsize(Jar.file_path)
		Jar.ext = str(os.path.splitext(Jar.file_path)[1])
		Jar.times = str(int(time.time() * 1000))
	
	def ganti_profie(Jar):
		try:
			with requests.Session() as r:					
				files   = {'profile_pic': (f"profilepic{Jar.ext}" ,open(Jar.file_path,'rb'))}
				headers = {
					'host': 'www.instagram.com',
					'content-length': str(Jar.img),
					'sec-ch-ua-platform': '"Android"',
					'sec-ch-ua': '"Not(A:Brand";v="99", "Android WebView";v="133", "Chromium";v="133"',
					'sec-ch-ua-mobile': '?1',
					'x-ig-app-id': '936619743392459',
					'x-requested-with': 'XMLHttpRequest',
					'accept': '*/*',
					'x-instagram-ajax': '1020795520',
					'x-csrftoken': re.search(r'csrftoken=([^;]+)', Jar.cookies).group(1),
					'x-asbd-id': '359341',
					'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
					'origin': 'https://www.instagram.com',
					'sec-fetch-site': 'same-origin',
					'sec-fetch-mode': 'cors',
					'sec-fetch-dest': 'empty',
					'referer': 'https://www.instagram.com/',
					'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
				}
				response = r.post("https://www.instagram.com/api/v1/web/accounts/web_change_profile_picture/", files=files, headers=headers, cookies={'cookie':Jar.cookies})
		except Exception as e:print(e)
	
	def upload1(Jar):
		try:
			with requests.Session() as r:
				pic_ = open(Jar.file_path, 'rb')
				headers = {
					'content-type': 'image/jpeg',
					'offset': '0',
					'origin': 'https://www.instagram.com',
					'referer': 'https://www.instagram.com/',
					'sec-ch-ua': '"Not(A:Brand";v="99", "Android WebView";v="133", "Chromium";v="133"',
					'sec-ch-ua-mobile': '?1',
					'sec-ch-ua-platform': '"Android"',
					'sec-fetch-site': 'same-site',
					'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
					'x-entity-length': str(Jar.img),
					'x-entity-name': f'fb_uploader_{Jar.times}',
					'x-entity-type': 'image/jpeg',
					'x-ig-app-id': '1217981644879628',
					'x-instagram-ajax': '1020795520',
					'x-instagram-rupload-params': json.dumps({"media_type":1,"upload_id":Jar.times,"upload_media_height":1080,"upload_media_width":1080})
				}
				response = r.post(f'https://i.instagram.com/rupload_igphoto/fb_uploader_{Jar.times}', headers=headers, data=pic_, cookies={'cookie':Jar.cookies})
				Jar.up_id = response.json().get("upload_id")
				return Jar.up_id
		except Exception as e:pass
	
	def upload2(Jar, up_id):
		try:
			with requests.Session() as r:
				headers = {
					'x-asbd-id': '129477',
					'x-ig-app-id': '936619743392459',
					'x-instagram-ajax': '1015038960',
					'content-length': str(Jar.img),
					'x-csrftoken': re.search(r'csrftoken=([^;]+)', Jar.cookies).group(1),
					'sec-ch-ua-platform': '"Android"',
					'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
					'content-Type': 'application/x-www-form-urlencoded',
				}
				data = {
					'clips_share_preview_to_feed': "1",
					'disable_comments': "0",
					'igtv_share_preview_to_feed': "1",
					'is_meta_only_post': "0",
					'is_unified_video': "1",
					'like_and_view_counts_disabled': "0",
					'media_share_flow': "creation_flow",
					'share_to_facebook': "",
					'share_to_fb_destination_type': "USER",
					'source_type': "library",
					'upload_id': up_id,
					'video_subtitles_enabled': "0",
					'jazoest': "22644"
				}
				response = r.post('https://www.instagram.com/api/v1/media/configure/', data=data, headers=headers, cookies={'cookie':Jar.cookies})
				if '"status":"ok"' in response.text:
					return f'{H}True{P}'
				else:
					return f'{M}False{P}'
		except Exception as e:pass