import requests, re, time, calendar, random, datetime, binascii, struct, base64, sys, os, pyotp, json, uuid
import ssl
from colorama import Fore
from termcolor import colored
from rich.console import Console
from rich.panel import Panel
from rich.columns import Columns
# from rich import print
from fake_email import Email
from bs4 import BeautifulSoup as bs
from urllib.parse import quote_plus
import re,os,sys,bs4,json,random,time,datetime,requests,string
from datetime import datetime
from fake_email import Email
from faker import Faker
#from data import *
#from Terminalize.Styles import style_terminal
import time,datetime
#.from Penyimpanan.Banner import Terminal
from bs4 import BeautifulSoup as bs
#from run import Main2
from rich import print as prints
from rich.tree import Tree
import cloudscraper
import subprocess
import http.client
from datetime import datetime

from rich.panel import Panel
R = '\033[91;1m' 
G = '\033[92;1m'
R = '\033[31;1m'
RED = '\x1b[38;5;46m'
G = '\033[32;1m'
Y = '\033[33;1m'
B = '\033[34;1m'
M = '\033[35;1m'
C = '\033[36;1m'
R = '{RED}' 
XXXX = '\x1b[38;5;123m'
P = C
XXX = '\x1b[38;5;14m'
#from Cryptodome import Random
#from Cryptodome.Cipher import AES
#from nacl.public import PublicKey, SealedBox

head_email= {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','Accept-Encoding':'gzip, deflate','Accept-Language':'en-US,en;q=0.9','Pragma':'akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-ssl-client-session-id, akamai-x-get-true-cache-key, akamai-x-serial-no, akamai-x-get-request-id,akamai-x-get-nonces,akamai-x-get-client-ip,akamai-x-feo-trace','Sec-Ch-Ua':'','Sec-Ch-Ua-Mobile':'?1','Sec-Ch-Ua-Platform':'','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (Linux; Android 11; vivo 1918 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.0000.00 Mobile Safari/537.36'}
HeadersChangPicture = lambda token, p_pic_s : {"Host": "www.instagram.com", "Accept": "*/*", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36", "Accept-Language": "en-US,en;q=0.5", "Accept-Encoding": "gzip, deflate, br", "Referer": "https://www.instagram.com", "X-CSRFToken": str(token),"X-Instagram-AJAX": "1013618137", "X-Requested-With": "XMLHttpRequest", "Content-Length": str(p_pic_s),"DNT": "1", "Connection": "keep-alive",}

def clear(): os.system('cls' if 'win' in sys.platform.lower() else 'clear')
hasilnya = 0

def emailx():
    response = requests.post('https://api.internal.temp-mail.io/api/v3/email/new').json()
    return response['email']
    return None
def codex(email):
    try:
        response = requests.get(f'https://api.internal.temp-mail.io/api/v3/email/{email}/messages').text
        code = re.search(r'(\d{6})', response).group(1)
      #  ;print(f'{response}\n{code}')
        return code
    except:
        return None
TOKEN=[]
import requests
from bs4 import BeautifulSoup
import time
import re

API_URL = "https://harakirimail.com/api/v1"
BASE_URL = "https://harakirimail.com/"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0"

def get_random_email():
    """Mengambil email random dari halaman utama HarakiriMail"""
    response = requests.get(BASE_URL, headers={"User-Agent": USER_AGENT})
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        email_element = soup.select_one("#randominboxLink")
        if email_element:
            email = email_element.text.strip()
            username = email.split("@")[0]
            return email, username
    print("[❌] Gagal mengambil email random")
    return None, None

def ib(inbox_name):
    """Mengambil inbox email dari HarakiriMail berdasarkan nama email (tanpa domain)."""
    url = f"{API_URL}/inbox/{inbox_name}"
    headers = {"User-Agent": USER_AGENT}
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        return response.json()
    else:
        print(f"[❌] Gagal mengambil inbox: {response.status_code}")
        return None

def extract_otp(inbox_data):
    """Mengekstrak kode OTP (6 digit) dari email Instagram."""
    if "emails" in inbox_data and inbox_data["emails"]:
        for email in inbox_data["emails"]:
            if "Instagram" in email.get("from", ""):
                match = re.search(r'(\d{6})', email["subject"])
                if match:
                    return match.group(1)
    return None

import requests
import random
import time
import re
header = {
    "host": "tempmail.so",
    "sec-ch-ua-platform": "android",
    "x-inbox-lifespan": "600",
    "user-agent": "Mozilla/5.0 (Linux; Android 10; REALME RMX1911 Build/NMF26F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.96 Mobile Safari/537.36 AlohaBrowser/2.21.1",
    "accept": "application/json",
    "sec-ch-ua": "android webview;v=131, chromium;v=131, not_a brand;v=24",
    "content-type": "application/json",
    "sec-ch-ua-mobile": "?1",
    "x-requested-with": "mark.via.gp",
    "sec-fetch-site": "same-origin",
    "sec-fetch-mode": "cors",
    "sec-fetch-dest": "empty",
    "referer": "https://tempmail.so/",
    "accept-encoding": "gzip, deflate",
    "accept-language": "id-id,id;q=0.9,en-us;q=0.8,en;q=0.7"
}

import requests
import time
import json
import re
class Mail:
    def __init__(self):
        self.r = requests.Session()
        self.times = time.time()
        self.current = int(self.times * 1000)

    def home(self):
        get = self.r.get(f"https://tempmail.so/us/api/inbox?requestTime={self.current}&lang=us", headers=header).text
        self.data = json.loads(get)

        print("Response JSON (home):", json.dumps(self.data, indent=2))

        if self.data.get("code") == 0 and self.data.get("message") == "Success":
            email = self.data["data"].get("name")
            return email if email else None
        else:
            print("Gagal mendapatkan email.")
            return None

    def kodex(self):
        get = self.r.get(f"https://tempmail.so/us/api/inbox?requestTime={self.current}&lang=us", headers=header).text
        self.data = json.loads(get)

        print("Response JSON (kodex):", json.dumps(self.data, indent=2))

        if self.data.get("code") == 0 and self.data.get("message") == "Success":
            inbox = self.data["data"].get("inbox", [])
            if inbox:
                body = inbox[0].get("textBody", "")  # Ambil textBody dari email pertama
                print("\n[DEBUG] Isi textBody:\n", repr(body))  # Lihat teks asli
                
                match = re.search(r'(\d{6})', body)  # Cari kode OTP 6 digit
                if match:
                    return match.group(1)
                else:
                    print("Kode tidak ditemukan dalam email.")
                    return None
            else:
                print("Inbox masih kosong, belum ada email masuk.")
                return None
        else:
            print("Gagal mendapatkan kode OTP.")
            return None

# Buat objek Mail
main = Mail()
#mail = 
#print(mail)
#time.sleep(30)
#while True:
  #kode = main.kode()
  #print(kode)
prox = open('proxyscrape_premium_http_proxies.txt','r').read().splitlines()
nip=random.choice(prox)
proxs= {'http': 'socks4://'+nip}
class MailTD:
    def __init__(self):
        self.base_url = "https://mail.td"
        self.session = requests.Session()
        self.headers = {
            'authority': 'mail.td',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }

    def generate_email(self):
        domain = random.choice(["@qabq.com", "@nqmo.com"])
        nama = ''.join(random.choices("abcdefghijklmnopqrstuvwxyz1234567890", k=random.randint(8, 12)))
        email = nama + domain
        return email

    def get_email(self):
        email = self.generate_email()
        headers2 = {
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'x-nextjs-data': '1',
            'Referer': f'https://mail.td/en/mail/{email}',
            'sec-ch-ua-mobile': '?1',
            'User-Agent': self.headers['user-agent'],
            'sec-ch-ua-platform': '"Android"',
        }
        params = {'name': email}

        try:
            response = self.session.get(f"{self.base_url}/_next/data/Vo6ilNCStMVNBJtfMWiXR/en/mail/{email}.json", params=params, headers=headers2)
            response.raise_for_status()
            print(email)
            return email
        except requests.RequestException as e:
            print(f"Error saat mendapatkan email: {e}")
            return None

    

    def get_code(self, email):
        
        headers = {
            'authority': 'mail.td',
            'accept': '*/*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'referer': f'https://mail.td/en/mail/{email}',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': self.headers['user-agent'],
        }

        try:
            response = self.session.get(f"{self.base_url}/api/api/v1/mailbox/{email}", headers=headers)
            response.raise_for_status()
            messages = response.json()
            print(messages)
            if messages:
                content = messages[0].get("text", "")
                match = re.search(r'\b\d{6}\b', content)
                return match.group() if match else None
            return None
        except requests.RequestException as e:
            print(f"Error saat mendapatkan kode: {e}")
            return None

    def wait_for_code(self):
        timer = 60
        while timer > 0:
            print(f'\rMenunggu kode dalam waktu {timer} detik...', end='\r')
            time.sleep(1)
            timer -= 1


class Ontime:
    def __init__(self) -> None:
        self.api_key = "1918471c4cmsh6e3c2771238871bp130808jsn60f82f9ccc2f"
        self.api_host = "one-time-temp-email-for-quick-sign-ups-verifications.p.rapidapi.com"
        self.conn = http.client.HTTPSConnection(self.api_host, context=ssl._create_unverified_context())
        self.headers = {
            'x-rapidapi-key': self.api_key,
            'x-rapidapi-host': self.api_host,
            'Content-Type': "application/json",
        }

    def emailya(self) -> str | bool:
        domain = random.choice(["12388101.xyz", "postixx.de", "takefast.casa"])
        nomor = random.randint(1000000, 100000000)
        namaacak = random.choice(["cikkawan", "meledakmamen", "anjayhayu", "yowwwww", "gaskan", "katamuhebat", "premnihdek"])
        email = f"{namaacak}{nomor}@{domain}"
        try:
            self.conn.request("GET", f"/create_mailbox?email={email}", headers=self.headers)
            res = self.conn.getresponse()
            data = res.read()
            email_data = json.loads(data.decode("utf-8"))
            email = email_data.get("email")
            # print(f"Email baru: {email}")
            return email
        except Exception as e:
            print(f"Error saat mendapatkan email: {e}")
            return False
    def jeda(self):
        timers = int(60)
        while timers > 0:
            print(f'\rMenunggu kode Dalam  Waktu {timers}                              ', end='\r')
            time.sleep(1)
            timers -= 1
    def pesenya(self, email: str) -> str | None:
       # self.jeda()
        try:
            self.conn.request("GET", f"/get_emails_by_address?email={email}&limit=100", headers=self.headers)
            res = self.conn.getresponse()
            data = res.read()
            messages_data = json.loads(data.decode("utf-8"))
            if messages_data:
                content = messages_data[0]['text']
                match = re.search(r'\b\d{6}\b', content)
                if match:
                    return match.group()
                else:
                    print("Kode 6 digit tidak ditemukan.")
                    return None
            else:
                print("Tidak ada pesan di inbox.")
                return None
        except Exception as e:
            print(f"Error saat mendapatkan pesan: {e}")
            return None

# Contoh penggunaan
headers = {
    'authority': 'temporary-mail-generator.vercel.app',
    'accept': '*/*',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'referer': 'https://temporary-mail-generator.vercel.app/',
    'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
}
def emailp():
  #  konek()
    """Membuat email sementara dan mengembalikan email serta token."""
    url = 'https://temporary-mail-generator.vercel.app/api/create-basic-inbox'
    res = ses.get(url, headers=headers).json()
    return res.get('address'), res.get('token')


def inbox(token):
 #   konek()
    """Memeriksa pesan masuk berdasarkan token dan mencari kode verifikasi."""
    url = f'https://temporary-mail-generator.vercel.app/api/check-inbox/{token}'
    res = ses.get(url, headers=headers).json()

    if res and isinstance(res, dict) and "emails" in res:
        emails = res["emails"]
        
        if emails:
            for email in emails:
                subject = email.get("subject", "")
                body = email.get("html", "")

                # Cari kode di subject atau body HTML
                code = re.search(r'\b\d{5,6}\b', subject) or re.search(r'\b\d{5,6}\b', body)
                if code:
                    return code.group()  # Ambil kode verifikasi
                
class PlusPlus:
    def __init__(self):pass
    def mailyt(self):
        name = random.choice(['cikawanmela','mantaobesae','mesieaf','afadjajajaIiuasd','asdhhhahs','MantraosajJas'])
        nam = name.lower().replace(' ','')
        jam = str(datetime.now().strftime("%X")).replace(':','')
        ran = str(random.randrange(1000,10000))
        dom = random.choice(['chitthi.in','any.pink','mailto.plus','fexpost.com','fexbox.org','mailbox.in.ua','rover.info','fextemp.com','merepost.com'])
        email = f'{nam}{ran}{jam}@{dom}'
        return email

    def kode(self,email) -> bool:
        url = f'https://tempmail.plus/api/mails?email={email}'
        try:
            req = ses.get(url, headers=head_email).json()
            print(req)
            if req.get('result') and req.get('mail_list'):
                subject = req['mail_list'][0]['subject']
                code = re.search(r'\b\d{5,6}\b', subject)  # Cari kode 5 atau 6 digit
                if code:
                    return code.group()  # Return hanya kodenya
                
            return None  # Return None jika tidak ada kode
            
        except Exception as e:
            print(f"Error: {e}")
            return None
        
class PanggillJs:
    def __init__(self):pass
    def Work(self, kode = False, token=None):
        biji = 'email' if kode is False else 'biji2'
        attr = ["node", "main.js",biji] if token is None else ["node", "main.js",biji,TOKEN[0]]
        process = subprocess.Popen(attr,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        for line in process.stdout:
            self.cd = line.strip()
            if kode:
                self.ab = re.findall(r'Subjek: (\d+)',str(self.cd))
                if self.ab: 
                    return self.ab
            else:
                self.dt = re.findall('Email : (.*)',str(self.cd))
                if self.dt: 
                    em,tk = self.dt[0].split('|')
                    TOKEN.append(tk)
                    return em
        process.wait()
proxy = None
ses = requests.Session()
class MohmalAPI:
    def _init_(self, proxy=None):
        self.session = requests.Session()
        self.proxy = None
        self.mail = None

        self.headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Google Chrome Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36',
            'DNT': '1',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,/;q=0.8,application/signed-exchange;v=b3',
            'Accept-Language': 'en-US,en;q=0.5',
        }
        self.session.headers.update(self.headers)

    def get_domain_list(self):
        domains = ses.get("https://www.mohmal.com/en", proxies=proxy, allow_redirects=True)
        domains_match = re.compile('<option value="(.+?)"').findall(domains.text)
        return domains_match

    def create_mail(self, name, domain):
        post_data = {"name": name, "domain": domain}
        create = ses.post("https://www.mohmal.com/en/create", data=post_data, proxies=proxy, allow_redirects=True)
        verify = create.text.find(name + "@" + domain)
        if verify != -1:
            self.mail = name + "@" + domain
            return self.mail
        else:
            return -1  # Cannot create mail

    def create_random_mail(self):
        lst = self.get_domain_list()
        if len(lst) > 0:
            # Generate a new random email every time the function is called
            random_email = ''.join(random.choice('0123456789qwertyuiopasdfghjklzxcvbnm') for _ in range(10))
            return self.create_mail(random_email, lst[0])
        else:
            return -1  # Cannot create mail

    def get_messages_list(self):
        inbox = ses.get("https://www.mohmal.com/en/inbox", proxies=proxy, allow_redirects=True)
        messages_match = re.compile('<tr data-msg-id="(.+?)"').findall(inbox.text)
        return messages_match

    def get_message(self, msg_id):
        msg = ses.get("https://www.mohmal.com/en/message/" + str(msg_id), proxies=proxy, allow_redirects=True)
        return msg.text

    def extract_confirmation_code(self, message):
        code_match = re.search(r'(\d{6})', message)
        if code_match:
            return code_match.group(0)
        return None
Meledak=[]
console = Console()
class TempMail:
    def __init__(self):
        self.session = requests.Session()
        self.base_url = "https://email.vwh.sh"
        self.headers = {
            'accept': 'application/json',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
        }
        self.email = self._generate_email()

    def _generate_email(self):
        """Generate temporary email"""
        abc = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))
        abc1 = ''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))
        return f"{abc}-{abc1}@vwh.sh"

    def emailnya(self):
        """Return the generated email"""
        return self.email

    def kodenya(self):
        """Retrieve and return the 6-digit verification code"""
        time.sleep(5)  # Tunggu 5 detik supaya email masuk

        email_endpoint = f"{self.base_url}/api/email/{self.email}"
        response = self.session.get(email_endpoint, headers=self.headers)

        if response.status_code == 200 and response.json():
            messages = response.json()
            inbox_id = messages[0]['id']

            message_endpoint = f"{self.base_url}/api/inbox/{inbox_id}"
            response = self.session.get(message_endpoint, headers=self.headers)

            if response.status_code == 200:
                content = response.json().get('textContent', '')
                code_match = re.search(r'\b\d{6}\b', content)  # Cari kode 6 digit

                if code_match:
                    return code_match.group(0)
        
        return None  # Jika tidak ditemukan

# Contoh penggunaan
najay = TempMail()

import re
import random
import requests
import time

class EyePasteAPI:
    BASE_URL = "https://www.eyepaste.com"

    def __init__(self):
        self.session = requests.Session()
        self.email = None

    def create_random_mail(self):
        """Membuat email acak dengan domain @eyepaste.com."""
        random_name = ''.join(random.choice('abcdefghijklmnopqrstuvwxyz1234567890') for _ in range(8))
        self.email = f"{random_name}@eyepaste.com"
        print(f"Email baru: {self.email}")
        return self.email

    def get_inbox(self, email):
        """Mengambil inbox dari Eyepaste."""
        inbox_url = f"{self.BASE_URL}/inbox/{email}"
        response = self.session.get(inbox_url)
  #      data = response.json()
        match = re.search(r'(\d{6}) adalah kode Instagram Anda', response.text)

        return match.group(0) if match else None

       # if response.status_code == 200:
          #  return response.text
      #  else:
           # print("Gagal mengakses inbox.")
           # return None

    def extract_confirmation_code(self, inbox_content):
        """Ekstrak kode 6 digit dari isi inbox."""
        


class FakeEmailye:
    def __init__(self):
        self.eyepaste_api = EyePasteAPI()
        self.email = None

    def emailya(self):
        """Membuat email sementara menggunakan Eyepaste."""
        self.email = self.eyepaste_api.create_random_mail()
        return self.email

    def kodeya(self):
        """Mendapatkan kode verifikasi dari inbox."""
        #time.sleep(10)  # Tunggu beberapa detik agar email masuk
        inbox_content = self.eyepaste_api.get_inbox(self.email)
        print(inbox_content)
        match = re.search(r'(\d{6})', inbox_content)

        return match.group(0) if match else None

   
fakes = FakeEmailye()
def emailh():
    return f"{random.randint(100000, 999999)}@harakirimail.com"
def menu():
    Meledak.clear()
    Meledak.append(Panel.fit("[bold white]1. [bold green]Create Instagram One Time\n[bold white]2. [bold green]Create Instagram Manual\n[bold white]3. [bold green]Create Instagram Plus Plus", style="blue"))
    Meledak.append(Panel.fit("[bold white]4. [bold green]Bantuan\n[bold white]0. [bold red]Keluar", style="blue"))
    Meledak.append(Panel.fit("[bold white]5. [bold green]Create Instagram Ninja\n[bold white]6. [bold green]Create Instagram Mohmal", style="blue"))
    console.print(Columns(Meledak))
    pilih = input(f"\n+ Masukkan pilihan Anda: ")
    if pilih == '1':
        pwd = 'enc2025'
        while True:
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.Ontime()
            lo.step1()
            lo.step2()
            lo.step3()
        	#lo.jeda(3, 'OTP')
            lo.CodeOntime()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
          #  lo.step9()
        #    time.sleep(10)
    elif pilih == '2':
        pwd = "enc2025"
        while True:
            email = input(f"\n+ Masukkan Email: ")
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.Email(email)
            lo.step1()
            lo.step2()
            lo.step3()
        #	lo.jeda(3, 'OTP')
            lo.EmailCode()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
           # lo.step9()
          #  time.sleep(10)
    elif pilih == '7':
        pwd = "enc2025"
        while True:
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.mailey()
            lo.step1()
            lo.step2()
            lo.step3()
        #	lo.jeda(3, 'OTP')
            lo.mailkode()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
          #  lo.step9()
          #  time.sleep(10)
    elif pilih == '3':
        pwd = "enc2025"
        while True:
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.Plusplus()
            lo.step1()
            lo.step2()
            lo.step3()
        #	lo.jeda(3, 'OTP')
            lo.CodePlusplus()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
          #  lo.step9()
          #  time.sleep(10)
    elif pilih == '4':
        options()
    elif pilih == '5':
        pwd = "enc2025"
        while True:
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.Ninja()
            lo.step1()
            lo.step2()
            lo.step3()
        #	lo.jeda(3, 'OTP')
            lo.CodeNinja()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
           # lo.step9()
          #  time.sleep(10)
    elif pilih == '8':
        pwd = "enc2025"
        while True:
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.mailbru()
            lo.step1()
            lo.step2()
            lo.step3()
        #	lo.jeda(3, 'OTP')
            lo.mailib()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
         #   lo.step9()
         #   time.sleep(10)
    elif pilih == '6':
        pwd = "enc2025"
        while True:
            lo = instagram(pwd)
            lo.getname()
            lo.GetData()
            lo.Mohmal()
            lo.step1()
            lo.step2()
            lo.step3()
        #	lo.jeda(3, 'OTP')
            lo.CodeMohmal()
            lo.step4()
            lo.step5()
            lo.step6()
            lo.step7()
            lo.step8()
         #   lo.step9()
         #   time.sleep(10)
    elif pilih == '0':
        sys.exit()
    else:
        os.system('clear')
        menu()
def PassGenerator():
    text = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    angka = '1234567890'
    simbol = '~!@#$%^&*()_+'
    karakter = text + angka + simbol+ "1"
    length = random.choice([8, 12])  # Pilih panjang password secara acak
    password = ''.join(random.sample(karakter, length))
    return password
import socket
import time
def konek():
    try:
        # Coba membuat koneksi ke Google DNS (8.8.8.8) untuk cek internet
        socket.create_connection(("8.8.8.8", 53), timeout=3)
   #     print("Koneksi Anda masih nyala\nLanjut...")
    except OSError:
        print("Koneksi Anda bermasalah\nTunggu beberapa saat sebelum mencoba lagi...")
        time.sleep(5)  # Tunggu 5 detik sebelum mencoba lagi
        konek()  # Coba lagi sampai koneksi kembali
def options():
    prints(Panel.fit(f"[bold white]Mode bantuan"))
    tree = Tree("[bold white]Bantuan Masalah Api Email")
    tree.add("[bold white]1. buka web temp-mail-api3 p rapid", style=style_terminal)
    tree.add("[bold white]2. setelah itu daftar memakai basic", style=style_terminal)
    tree.add("[bold white]3. jika sudah terdaftar maka ke web temp-mail-api3 p rapid", style=style_terminal)
    tree.add("[bold white]4. jika sudah nanti test endpoind / subscript test", style=style_terminal)
    tree.add("[bold white]5. Pilih plan yang basic lalau test lagi test endpoin pilih yang python dan ambil key nya", style=style_terminal)
    prints(tree)
    tree = Tree("[bold white]Bantuan Masalah Bug Sc")
    tree.add("[bold white]Bisa Menghubungi ke no 081322544391", style=style_terminal)
    prints(tree)
	
	
FAE = Ontime()
FAEE = MohmalAPI()
FAEEE = PlusPlus()
api = "https://harakirimail.com/api/v1"
user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0"
url_bio ='https://www.rumahweb.com/'
bio_teks =''
bio_links = [{"url": f"{url_bio}", "title": f"{bio_teks}"}]
def get_inbox(inbox_name):
    url = f"{api}/inbox/{inbox_name}"
    headers = {"User-Agent": user_agent}
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Gagal mengambil inbox: {response.status_code}")
        return None

def get_kode_verifikasi(email):
    data = get_inbox(email)
    if data:
        for email_data in data['emails']:
            subject = email_data['subject']
            if "kode" in subject.lower():
                kode = subject.split()[-1]
                return kode
    return None
def nama():
    fake = Faker("id_ID")
    depan = fake.first_name_female()
    belakang = fake.first_name_female()
    lakidepan = fake.first_name_male()
    lakibelakang = fake.first_name_male()
    nomor = random.randint(10,99999)
    na = f"{depan}_{belakang}{nomor}".lower()
    na2 = f"{depan}.{belakang}{nomor}".lower()
    na3 = f"_{depan}.{belakang}{nomor}".lower()
    nal = f"{lakidepan}_{lakibelakang}{nomor}".lower()
    nal2 = f"{lakidepan}.{lakibelakang}{nomor}".lower()
    nal3 = f"_{lakidepan}.{lakibelakang}{nomor}".lower()
    nameyow = random.choice([nal,nal2,nal3,na3,na2,na])
    return nameyow

headers = {
    'authority': 'temporary-mail-generator.vercel.app',
    'accept': '*/*',
    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
    'referer': 'https://temporary-mail-generator.vercel.app/',
    'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36',
}
def emailp():
    """Membuat email sementara dan mengembalikan email serta token."""
    url = 'https://temporary-mail-generator.vercel.app/api/create-basic-inbox'
    res = ses.get(url, headers=headers).json()
    return res.get('address'), res.get('token')


from bs4 import BeautifulSoup as bsp
import time
import random
import requests
import time
import re  # Tambahkan modul regex

class Kal:
    def __init__(self):
        self.sees = requests.Session()  # Menggunakan requests.Session untuk menyimpan cookies

    def mail(self):
        headers = {
            'authority': 'mail.td',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }

        self.sees.get('https://mail.td/en', headers=headers)  # Permintaan awal untuk mendapatkan cookies

        abs_chars = 'abcdefghijklmnopqrstuvwxyz12345678910'
        domain = random.choice(['@qabq.com','@nqmo.com','@end.tw','@uuf.me','@yzm.de'])
        abc = ''.join(random.choice(abs_chars) for _ in range(random.randint(8, 12)))
        email = abc + domain

        headers2 = {
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'x-nextjs-data': '1',
            'Referer': f'https://mail.td/en/mail/{email}',
            'sec-ch-ua-mobile': '?1',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
            'sec-ch-ua-platform': '"Android"',
        }

        params = {'name': email}
        self.sees.get(
            f'https://mail.td/_next/data/Vo6ilNCStMVNBJtfMWiXR/en/mail/{email}.json',
            params=params,
            headers=headers2
        )

        return email

    def GetCodeV3(self, Email):
        print("Menunggu Kode Konfirmasi...")

        auth = self.sees.cookies.get_dict().get('auth_token', '')

        headers = {
            'authority': 'mail.td',
            'accept': '*/*',
            'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'authorization': f'bearer {auth}',
            'referer': f'https://mail.td/en/mail/{Email}',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        }

        response = self.sees.get(
            f'https://mail.td/api/api/v1/mailbox/{Email}',
            headers=headers
        )

        if response.status_code == 200:
            data = response.json()
            
            if isinstance(data, list) and len(data) > 0:
                subject = data[0].get('subject', '')

                # Cari kode 6 digit dalam subject
                match = re.search(r'\b\d{6}\b', subject)
                if match:
                    return match.group(0)  # Kembalikan hanya angka 6 digit
                
        return "Gagal mendapatkan kode verifikasi"

kal = Kal()
from bs4 import BeautifulSoup as bsp
import time
class InstaBot:
    def __init__(self):
        self.acak1 = 'abcdefghijklmnopqrstuvwxyz'

    def email(self):
        """Membuat email acak di InboxKitten."""
        email_prefix = ''.join(random.choices(self.acak1, k=8))
        email = f"{email_prefix}{random.randint(1, 9999)}@inboxkitten.com"
        return email

    def kode(self, email):
        """Cek apakah ada pesan masuk di email yang dibuat."""
        inbox_url = f"https://inboxkitten.com/api/v1/mail/list?recipient={email}"
        response = requests.get(inbox_url).text

        # Ambil key dan region dari email masuk
        key = re.findall('"key":"(.*?)"', response)
        region = re.findall('"region":"(.*?)"', response)

        if key and region:
            return self.get_verification_code(region[0], key[0])
        return None

    def get_verification_code(self, region, key):
        """Mengambil isi pesan dari email yang masuk."""
        url = 'https://inboxkitten.com/api/v1/mail/getHtml'
        params = {'region': region, 'key': key}
        headers = {
            'user-agent': 'Mozilla/5.0 (Linux; Android 10)',
            'accept': 'text/html,application/xhtml+xml,application/xml'
        }

        req = requests.get(url, params=params, headers=headers)
        sdr = bsp(req.text, 'html.parser')

        # Cari kode verifikasi dalam pesan
        for yxz in sdr.find_all('td'):
            match = re.findall(r'<td style=".*?">(\d+)</td>', str(yxz))
            if match:
                return match[0]
        return None
bot = InstaBot()
import http.client
import random
from datetime import datetime
class yesforu:
    def __init__(self) -> None:
        self.api_key = "1918471c4cmsh6e3c2771238871bp130808jsn60f82f9ccc2f"
        self.api_host = "one-time-temp-email-for-quick-sign-ups-verifications.p.rapidapi.com"
        self.conn = http.client.HTTPSConnection(self.api_host, context=ssl._create_unverified_context())
        self.headers = {
            'x-rapidapi-key': self.api_key,
            'x-rapidapi-host': self.api_host,
            'Content-Type': "application/json",
        }

    def emailya(self) -> str | bool:
        domain = random.choice(["12388101.xyz", "postixx.de", "takefast.casa"])
        nomor = random.randint(1000000, 100000000)
        namaacak = random.choice(["cikkawan", "meledakmamen", "anjayhayu", "yowwwww", "gaskan", "katamuhebat", "premnihdek"])
        email = f"{namaacak}{nomor}@{domain}"
        try:
            self.conn.request("GET", f"/create_mailbox?email={email}", headers=self.headers)
            res = self.conn.getresponse()
            data = res.read()
            email_data = json.loads(data.decode("utf-8"))
            email = email_data.get("email")
            # print(f"Email baru: {email}")
            return email
        except Exception as e:
            print(f"Error saat mendapatkan email: {e}")
            return False
    def jeda(self):
        timers = int(60)
        while timers > 0:
            print(f'\rMenunggu kode Dalam  Waktu {timers}                              ', end='\r')
            time.sleep(1)
            timers -= 1
    def kodeya(self, email: str) -> str | None:
        self.jeda()
        try:
            self.conn.request("GET", f"/get_emails_by_address?email={email}&limit=100", headers=self.headers)
            res = self.conn.getresponse()
            data = res.read()
            messages_data = json.loads(data.decode("utf-8"))
            if messages_data:
                content = messages_data[0]['text']
                match = re.search(r'\b\d{6}\b', content)
                if match:
                    return match.group()
                else:
                    print("Kode 6 digit tidak ditemukan.")
                    return None
            else:
                print("Tidak ada pesan di inbox.")
                return None
        except Exception as e:
            print(f"Error saat mendapatkan pesan: {e}")
            return None
lah = yesforu()
class instagram:
    def __init__(self, pwd):
        self.ses = requests.Session()
        self.pnw = pwd
        self.bacot,self.tokenz = emailp()
        self.riweh = self.bacot
        self.head_email = {'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','Accept-Encoding':'gzip, deflate','Accept-Language':'en-US,en;q=0.9','Pragma':'akamai-x-cache-on, akamai-x-cache-remote-on, akamai-x-check-cacheable, akamai-x-get-cache-key, akamai-x-get-extracted-values, akamai-x-get-ssl-client-session-id, akamai-x-get-true-cache-key, akamai-x-serial-no, akamai-x-get-request-id,akamai-x-get-nonces,akamai-x-get-client-ip,akamai-x-feo-trace','Sec-Ch-Ua':'','Sec-Ch-Ua-Mobile':'?1','Sec-Ch-Ua-Platform':'','Sec-Fetch-Dest':'document','Sec-Fetch-Mode':'navigate','Sec-Fetch-Site':'none','Sec-Fetch-User':'?1','Upgrade-Insecure-Requests':'1','User-Agent':'Mozilla/5.0 (Linux; Android 11; vivo 1918 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/112.0.0000.00 Mobile Safari/537.36'}
        
        version = random.randint(8, 12)
        build1  = random.randint(189999, 201217)
        build2  = random.randint(1, 9)
        ver1 = random.randint(90, 299)
        ver2 = random.randint(3800, 5000)
        self.bio = random.choice(["Hello Semua","Selamat Malam","Selamat Siang","Selamat Sore","Sehat Selalu","Berkah Selalu","Alhamdulilah"])
        self.us = "Mozilla/5.0 (Linux; Android 7.1.2; Redmi 4X Build/N2G47H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36"
        ver3 = random.randint(100, 299)
        self.headers = {'Host': 'www.instagram.com','X-Ig-Www-Claim': '0','X-Requested-With': 'XMLHttpRequest','Sec-Ch-Prefers-Color-Scheme': 'dark','X-Ig-App-Id': '567067343352427','User-Agent': f'{self.us}','Content-Type': 'application/x-www-form-urlencoded','Accept': '*/*','X-Asbd-Id': '129477','Origin': 'https://www.instagram.com','Sec-Fetch-Site': 'same-origin','Sec-Fetch-Mode': 'cors','Sec-Fetch-Dest': 'empty','Referer': 'https://www.instagram.com/accounts/signup/email/','Accept-Encoding': 'gzip, deflate','Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7','Priority': 'u=1, i'}

    def getname(self):
        self.username = nama()
        self.names = nama()
        self.display = (f" tahap  1")
        self.Looping()
        
    # Email One time
    def Ontime(self):
        self.email = self.riweh
       # print(self.email)
        self.display = (f" tahap  3")
        self.Looping()
    def CodeOntime(self):
        time.sleep(3)
        eemail = self.email
       # time.sleep(30)
        tokenza = self.tokenz
        self.code = inbox(tokenza)
      #  self.code = extract_otp(so)
      #  print(self.code)
    # Email Plus Plus
    def Plusplus(self):
        self.email = najay.emailnya()
        self.display = (f" tahap  3")
        self.Looping()
    def CodePlusplus(self):
       # time.sleep(40)
        mail = self.email
        self.code = najay.kodenya()
    
    # InboxKitten
    def Mohmal(self):
        self.email=bot.email()
        self.display = (f" tahap  3")
        self.Looping()
    def CodeMohmal(self):
        time.sleep(5)
        sele = self.email
        self.code = bot.kode(sele)
        
    def mailbru(self):
    	self.email = get_random_email()
    def mailib(self):
    	time.sleep(20)
    	yax = self.email[0]
    	inbox_name = yax.split("@")[0]
    	inbox_data = ib(inbox_name)
    	print(inbox_data)
#otp_code = 
    	self.code = extract_otp(inbox_data)
    	print(self.code)
    # Eyepaste
    
    def mailey(self):
    	self.email = fakes.emailya()
    	self.display = (" tahap 3")
    	self.Looping()
    def mailkode(self):
    	time.sleep(5)
    	self.code = fakes.kodeya()
    def Ninja(self):
        self.email=kal.mail()
        self.display = (f" tahap  3")
        self.Looping()
    def CodeNinja(self):
        time.sleep(3)
        self.code = kal.GetCodeV3(self.email)
        return self.code[0]
    
    # Manual 
    
    def Email(self,email):
        self.email = email
    def EmailCode(self):
       # time.sleep(40)
        self.code = input(f"+ Masukan Code : ")
        return self.code
    
    def GetData(self):
        headers = {
            'User-Agent': f'{self.us}',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'id,en-US;q=0.7,en;q=0.3',
            'Accept-Encoding': 'gzip, deflate',
            'Alt-Used': 'www.instagram.com',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Priority': 'u=0, i',
        }

        response = self.ses.get('https://www.instagram.com/', headers=headers,proxies=proxs).text
        self.cookies = ";".join([key+"="+value.replace('"','') for key, value in self.ses.cookies.get_dict().items()])
        match = re.search(r'"InstagramPasswordEncryption",\[\],{"key_id":"(\d+)","public_key":"(.*?)","version":"(\d+)"', str(response))
        if match: self.key_id, self.pub_key, self.version = match.group(1), match.group(2), match.group(3)
        self.clienid = re.search(r'"machine_id":"(.*?)"',str(response)).group(1)
        self.csrf    = re.search(r'csrftoken=(.*?);', str(self.cookies)).group(1)
        self.claim   = re.search(r'"claim":"(.*?)"', str(response)).group(1)
        self.display = (f" tahap  2")
        self.Looping()
    
    def encrypt_password(self):
        self.password = self.pnw
        enpas = '#PWD_INSTAGRAM:0:{}:{}'.format(str(time.time())[:10], self.password)
        return enpas
    
    def step1(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'X-Csrftoken': self.csrf,
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Asbd-Id': '129477',
            'X-Requested-With': 'XMLHttpRequest',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'Accept': '*/*',
            'User-Agent': f'{self.us}',
            'X-Ig-Www-Claim': self.claim,
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/email/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        response = self.ses.get('https://www.instagram.com/api/v1/web/login_page/', cookies={'cookie': self.cookies}, headers=headers, proxies=proxs, allow_redirects=True).text
        self.display = (f" tahap  4")
        self.Looping()
   #     print(response)
        #print()

    def step2(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/email/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }
        
        data = {'email': self.email}

        response = self.ses.post('https://www.instagram.com/api/v1/web/accounts/check_email/', cookies={'cookie': self.cookies}, data=data, proxies=proxs, headers=headers, allow_redirects=True).text
        self.display = (f" tahap  5")
        self.Looping()
        #print(response)
       # print()

    def step3(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/email/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'device_id': self.clienid,
            'email': self.email,
        }

        response = self.ses.post('https://www.instagram.com/api/v1/accounts/send_verify_email/', cookies={'cookie': self.cookies}, data=data, proxies=proxs, headers=headers, allow_redirects=True).text
        self.display = (f" tahap  6")
        self.Looping()
        #print(response)
        #print()

    def step4(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/emailConfirmation/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'code': self.code,
            'device_id': self.clienid,
            'email': self.email,
        }

        response = self.ses.post('https://www.instagram.com/api/v1/accounts/check_confirmation_code/', cookies={'cookie': self.cookies}, data=data, proxies=proxs, headers=headers, allow_redirects=True).json()
        self.konfircode = response["signup_code"]
        self.display = (f" tahap  7")
        self.Looping()

    def step5(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/name/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'enc_password': self.encrypt_password(),
            'email': self.email,
            'failed_birthday_year_count': '{}',
            'first_name': self.names,
            'username': '',
            'seamless_login_enabled': '1',
            'use_new_suggested_user_name': 'true',
        }

        response = self.ses.post('https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/', cookies={'cookie': self.cookies}, data=data, proxies=proxs, headers=headers, allow_redirects=True).text
        self.display = (f" tahap  8")
        self.Looping()
        #print(response)
     #   print()

    def step6(self):
        self.day = str(random.randint(1, 25))
        self.month = str(random.randint(1, 10))
        self.year  = str(random.randint(1998, 2005))
        headers = {
            'Host': 'www.instagram.com',
            # 'Content-Length': '23',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/birthday/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'day'  : self.day,
            'month': self.month,
            'year' : self.year,
        }

        response = self.ses.post('https://www.instagram.com/api/v1/web/consent/check_age_eligibility/', cookies={'cookie': self.cookies}, data=data, proxies=proxs, headers=headers, allow_redirects=True).text
        self.display = (f" tahap  9")
        self.Looping()
      #  print(response)
        #print()

    def step7(self):
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/username/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {'username': self.names}

        response = self.ses.post('https://www.instagram.com/api/v1/users/check_username/', cookies={'cookie': self.cookies}, data=data, headers=headers, proxies=proxs, allow_redirects=True).json()
        self.display = (f" tahap  10")
        self.Looping()
        #self.username = response["username_suggestions"]["suggestions"][4]
        #print(response)
        #print()

    def step8(self):
        global hasilnya
       # time.sleep(10)
        headers = {
            'Host': 'www.instagram.com',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
            'Sec-Ch-Ua-Mobile': '?1',
            'X-Ig-App-Id': '567067343352427',
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': '*/*',
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Instagram-Ajax': '1018644775',
            'X-Csrftoken': self.csrf,
            'X-Asbd-Id': '129477',
            'User-Agent': f'{self.us}',
            'Sec-Ch-Prefers-Color-Scheme': 'dark',
            'X-Ig-Www-Claim': self.claim,
            'Origin': 'https://www.instagram.com',
            'Sec-Fetch-Site': 'same-origin',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Dest': 'empty',
            'Referer': 'https://www.instagram.com/accounts/signup/username/',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            'Priority': 'u=1, i',
        }

        data = {
            'enc_password': self.encrypt_password(),
            'day': self.day,
            'email': self.email,
            'failed_birthday_year_count': '{}',
            'first_name': self.names,
            'month': self.month,
            'username': self.username,
            'year': self.year,
            'client_id': self.clienid,
            'seamless_login_enabled': '1',
            'tos_version': 'row',
            'force_sign_up_code': self.konfircode,
            # 'extra_session_id': '5oxdc6:1he7cf:6q5g2x',
        }

        response = self.ses.post('https://www.instagram.com/api/v1/web/accounts/web_create_ajax/', cookies={'cookie': self.cookies}, data=data, proxies=proxs, headers=headers, allow_redirects=True).text
        print(response)
        self.cookies = ";".join([key+"="+value.replace('"','') for key, value in self.ses.cookies.get_dict().items()])
        self.display = (f" tahap  12")
        mauenc = self.encrypt_password()
        print("")
        prints(f"[bold white][ ACCOUNT CREATE SUCCES ]")
        print("")
        prints(f"[bold white]Username  : [bold green]{self.username}")
        prints(f"[bold white]Password  : [bold green]{self.pnw}")
        prints(f"[bold white]Email     : [bold green]{self.email}")
        prints(f"[bold white]Tanggal   : [bold green]{self.day}/{self.month}/{self.year}")
        prints(f"[bold white]Clientid  : [bold green]{self.clienid}")
        prints(f"[bold white]End Pwd   : [bold green]{mauenc}")
        prints(f"[bold white]Cookies   : [bold green]{self.cookies}")
        print("")
        self.display = (f" tahap  11")
        self.Looping()
        user = f'{self.username}'
        pw = f'{self.pnw}'
        cok = f'{self.cookies}'
        tok = f'{self.csrf}'
        with open(f"/sdcard/stokcookie.txt", "a") as file: file.write(f"\n{cok}")
        posting(cok,tok)
        followig(cok,tok)
        update_bio_links(tok,cok,bio_links)
        Main2(user,pw, cok)
        hasilnya+=1
        self.Looping()
     #   print(response)
        #print()
        
    
    def Looping(self):
        konek()
        try:
            sys.stdout.write(f"\r╰─> Sedang Mode({self.display}) Hasil Create Akun {hasilnya}"),
            sys.stdout.flush()
        except (requests.exceptions.ConnectionError): print(f"{M}Koneksi anda bermasalah{P}" , end='\r'); time.sleep(31)

    
def follow1(cok,tok):
        user_id = "65351624025"
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
                'x-ig-app-id': '1217981644879628'
            }
            HD3 = {
                "Host": "www.instagram.com",
                "content-length": "108",
                "sec-ch-ua": '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                "x-ig-app-id": "1217981644879628",
                "x-ig-www-claim": "hmac.AR2bJKYJnPYmZqv19akfq13Zn4tplhuXb9TC9PwFk03Dg4v5",
                "sec-ch-ua-mobile": "?1",
                "x-instagram-ajax": "1007404816",
                "user-agent": headers['User-Agent'],
                "viewport-width": "360",
                "content-type": "application/x-www-form-urlencoded",
                "accept": "*/*",
                "x-requested-with": "XMLHttpRequest",
                "x-asbd-id": "198387",
                "sec-ch-ua-full-version-list": '"Chromium";v="110.0.5481.153", "Not A(Brand";v="24.0.0.0", "Google Chrome";v="110.0.5481.153"',
                "x-csrftoken":f'{tok}',
                "sec-ch-prefers-color-scheme": "light",
                "sec-ch-ua-platform": "Android",
                "origin": "https://www.instagram.com",
                "sec-fetch-site": "same-origin",
                "sec-fetch-mode": "cors",
                "sec-fetch-dest": "empty",
                "referer": "https://www.instagram.com/the.jpexec_/",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "cookie":f'{cok}'
            }
            Pay = {
                "container_module": "profile",
                "nav_chain": "PolarisProfileRoot:profilePage:1:via_cold_start",
                "user_id": user_id
            }
            API = requests.post(f'https://www.instagram.com/api/v1/friendships/create/{user_id}/', headers=HD3, data=Pay)
            if API.status_code == 200:
                tree = Tree('[bold white][ FOLLOW KE AKUN 1 ]')
                tree.add(f'[bold green]Sukses Follow Akun 1')
                prints(tree)
                return True
            else:
               #print('')
                print(f"Follow failed for user_id: {M}{user_id}, {P}Status code: {API.status_code}")
                return False
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
def komen(bio,cok):
        headers = {
            "Content-Length": "28",
            "sec-ch-ua": '"Not)A;Brand";v="99", "Google Chrome";v="127", "Chromium";v="127"',
            "x-ig-www-claim": "hmac.AR3Ns1l82Qzp1Zs1bJNgHSW8IJK4d-1Qj7qbIM9TN1evT-XS",
            "sec-ch-ua-platform-version": '"5.0.0"',
            "x-requested-with": "XMLHttpRequest",
            "sec-ch-ua-full-version-list": '"Not)A;Brand";v="99.0.0.0", "Google Chrome";v="127.0.6533.100", "Chromium";v="127.0.6533.100"',
            "sec-ch-prefers-color-scheme": "light",
            "x-csrftoken": re.search(r'csrftoken=(.*?);', cok).group(1),
            "sec-ch-ua-platform": '"Windows"',
            "x-ig-app-id": "936619743392459",
            "sec-ch-ua-model": '""',
            "sec-ch-ua-mobile": "?0",
            "x-instagram-ajax": "1015576910",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
            "content-type": "application/x-www-form-urlencoded",
            "accept": "/",
            "x-asbd-id": "129477",
            "origin": "https://www.instagram.com",
            "sec-fetch-site": "same-origin",
            "sec-fetch-mode": "cors",
            "sec-fetch-dest": "empty",
            "accept-encoding": "gzip, deflate, br, zstd",
            "accept-language": "id,en-US;q=0.9,en;q=0.8"
        }
        data = {"comment_text": f"{bio}"}
        try:
            response = requests.post(f"https://www.instagram.com/api/v1/web/comments/2243569220713804232/add/", headers=headers, data=data, cookies={"cookie": cok})
            response.raise_for_status()  # Raise an exception for HTTP errors
            return response.json()  # Return the JSON response
        except requests.RequestException as e:
            print(f"An error occurred: {e}")
def follow2(cok,tok):
        user_id = "65351624025"
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0.1; HUAWEI GRA-L09 Build/HUAWEIGRA-L09C150B196) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 Instagram 37.0.0.21.97 Android (21/5.0.1; 480dpi; 1080x1794; HUAWEI; HUAWEI GRA-L09; HWGRA; hi3635; hu_HU; 98288242)',
                'x-ig-app-id': '1217981644879628'
            }
            HD3 = {
                "Host": "www.instagram.com",
                "content-length": "108",
                "sec-ch-ua": '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                "x-ig-app-id": "1217981644879628",
                "x-ig-www-claim": "hmac.AR2bJKYJnPYmZqv19akfq13Zn4tplhuXb9TC9PwFk03Dg4v5",
                "sec-ch-ua-mobile": "?1",
                "x-instagram-ajax": "1007404816",
                "user-agent": headers['User-Agent'],
                "viewport-width": "360",
                "content-type": "application/x-www-form-urlencoded",
                "accept": "*/*",
                "x-requested-with": "XMLHttpRequest",
                "x-asbd-id": "198387",
                "sec-ch-ua-full-version-list": '"Chromium";v="110.0.5481.153", "Not A(Brand";v="24.0.0.0", "Google Chrome";v="110.0.5481.153"',
                "x-csrftoken":f'{tok}',
                "sec-ch-prefers-color-scheme": "light",
                "sec-ch-ua-platform": "Android",
                "origin": "https://www.instagram.com",
                "sec-fetch-site": "same-origin",
                "sec-fetch-mode": "cors",
                "sec-fetch-dest": "empty",
                "referer": "https://www.instagram.com/the.jpexec_/",
                "accept-encoding": "gzip, deflate, br",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "cookie":f'{cok}'
            }
            Pay = {
                "container_module": "profile",
                "nav_chain": "PolarisProfileRoot:profilePage:1:via_cold_start",
                "user_id": user_id
            }
            API = requests.post(f'https://www.instagram.com/api/v1/friendships/create/{user_id}/', headers=HD3, data=Pay)
            if API.status_code == 200:
                print(f"\r{R}[{G}√{R}]{G} Successfully Follow : {user_id}{P}")
                return True
            else:
                print(f"Follow failed for user_id: {M}{user_id}, {P}Status code: {API.status_code}")
                return False
        except Exception as e:
            print(f"An error occurred: {e}")
            return False
uass = "Mozilla/5.0 (Linux; Android 6.0; vivo Y67) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Mobile Safari/537.36"

# Fungsi untuk login dan CSRF Token
def get_csrf_token():
    konek()
    req = requests.get("https://www.instagram.com/accounts/login/", headers={'User-Agent': uass})
    csrf_token = re.findall('csrf_token":"(.*?)"', req.text)[0]
    return csrf_token

def login_instagram(username, password):
    konek()
   # global hasilnya
 #   print(username, password)
    csrf_token = get_csrf_token()  # Get CSRF token for login
    login_url = 'https://www.instagram.com/accounts/login/ajax/'

    # Prepare login data
    login_data = {
        'username': username,
        'enc_password': f'#PWD_INSTAGRAM_BROWSER:0:{round(time.time())}:{password}',
        'queryParams': '{}',
        'optIntoOneTap': 'false'
    }

    # Prepare headers
    headers = {
        'User-Agent': uass,
        'X-CSRFToken': csrf_token,
        'X-Instagram-AJAX': '1',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Referer': 'https://www.instagram.com/accounts/login/',
    }

    # Perform POST request to login
    response = requests.post(login_url, data=login_data, headers=headers)
    #print(response.json)
    if response.status_code == 200:
        # Check if login is successful
        response_json = response.json()
        if response_json.get('authenticated'):
  #          print(f"Login berhasil untuk {username}!")
            cookies = response.cookies.get_dict()
            cookie_str = '; '.join([f"{key}={value}" for key, value in cookies.items()])
            user = f'{username}'
            pw = f'enc2025'
            cok = f'{cookie_str}'
            tok = f'{csrf_token}'
            
            
    #        
           # DelayCreate2(wt , teks)
            # Extract and return cookies in string format
            
           # posting(tok,cok)
           # editbio(cok, tok, bio, email)
           # print(cookie_str)
            #time.sleep(10)
            return cok  # Return cookies as string
        else:
            time.sleep(10)
            print(f"Login gagal untuk {username}. Periksa username dan password Anda.")
            return None
    else:
    #    time.sleep(20)
    #    print(f"Login gagal dengan status code {response.status_code}.")
        return None
def editbio(cok, tok, bio, email):
    header = {
        'authority': 'www.instagram.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'cache-control': 'max-age=0',
        'dpr': '1.5',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-model': '"SM-J250F"',
        'sec-ch-ua-platform': '"Android"',
        'sec-ch-ua-platform-version': '"7.1.1"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        'viewport-width': '980',
        }
    req= requests.get('https://www.instagram.com/accounts/edit/', cookies={"cookie":cok}, headers=header).text 
    headers = {
        'authority': 'www.instagram.com',
        'accept': '*/*',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://www.instagram.com',
        'referer': 'https://www.instagram.com/accounts/edit/',
        'sec-ch-prefers-color-scheme': 'dark',
        'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
        'sec-ch-ua-full-version-list': '"Not-A.Brand";v="99.0.0.0", "Chromium";v="124.0.6327.4"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-model': '"SM-J250F"',
        'sec-ch-ua-platform': '"Android"',
        'sec-ch-ua-platform-version': '"7.1.1"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
        'x-asbd-id': '129477',
        'x-csrftoken': f"{tok}",
        'x-ig-app-id': '1217981644879628',
        'x-ig-www-claim': 'hmac.AR14eYoEFF2NWxaAbiIIbG3rGSSgS2VCHbfRjFoPoLm-5s0z',
        'x-instagram-ajax': '1015039620',
        'x-requested-with': 'XMLHttpRequest',
    }
    data = {
        'biography': bio,
        'chaining_enabled': 'on',
        'email': email,
        'external_url': '',
        'first_name': re.findall('"full_name":"(.*?)"',str(req)),
        'phone_number': '',
        'username': re.findall('"username":"(.*?)"',str(req)),
    }
    res = requests.post('https://www.instagram.com/api/v1/web/accounts/edit/', cookies={"cookie":cok}, headers=headers, data=data).text
    if '"status":"ok"' in str(res):
        tree = Tree('[bold white][ MEMASANG BIO ]')
        tree.add(f'[bold green]Sukses Memasang Bio')
        prints(tree)
    else:
        print("akun checkpoint")
        pass
import requests
import json
import random
from uuid import uuid4

def update_bio_links(tok, cok, bio_links):
    try:
        headers = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "user-agent": "Instagram 313.0.0.26.328 Android (33/13; 440dpi; 1080x2269; Xiaomi; 2201123G; cupid; qcom; it_IT; 554218560)",
            "x-ig-app-id": "198387",
            "x-requested-with": "XMLHttpRequest",
            "x-csrftoken": tok,
            "cookie": cok,
            "Referer": f"https://www.instagram.com/{''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))}/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        }

        url = "https://i.instagram.com/api/v1/accounts/update_bio_links/"
        payload = {
            "_uuid": str(uuid4()),
            "updated_links": [{"url": link["url"], "title": link["title"], "link_type": "external"} for link in bio_links]
        }

        response = requests.post(url, headers=headers, data={"signed_body": "SIGNATURE." + json.dumps(payload)})
        response_json = response.json()

        if response_json.get("status") == "ok":
            return "Bio links updated successfully!"
        elif response_json.get("message") == "login_required":
            return "Login expired! Please update your session ID."
        else:
            return "Failed to update bio links."
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"
    except ValueError:
        return "Invalid JSON response."
import requests
import random
import re

def get_userid(username):
    try:
        url = f"https://www.instagram.com/{username}/"
        response = requests.get(url)
        html = response.text
        pattern = r'"profilePage_([0-9]+)"'
        match = re.search(pattern, html)
        if match:
            return match.group(1)
        else:
            return None
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"

def follow(tok, cok, user_id):
    try:
        headers = {
            "accept": "*/*",
            "accept-language": "en-US,en;q=0.9",
            "user-agent": "Instagram 313.0.0.26.328 Android (33/13; 440dpi; 1080x2269; Xiaomi; 2201123G; cupid; qcom; it_IT; 554218560)",
            "x-ig-app-id": "198387",
            "x-ig-www-claim": "hmac.AR2mkRBy3FowqfYCnGVXZ9lzqaXP6KvNtFYb9LkPI7Fq4R5S",
            "x-instagram-ajax": "1007616494",
            "x-requested-with": "XMLHttpRequest",
            "x-csrftoken": tok,
            "cookie": cok,
            "Referer": f"https://www.instagram.com/{''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=5))}/",
            "Referrer-Policy": "strict-origin-when-cross-origin"
        }
        url = f"https://www.instagram.com/api/v1/friendships/create/{user_id}/"
        response = requests.post(url, headers=headers)
        response_json = response.json()
        if response_json.get("status") == "ok":
            return f"Successfully followed user {user_id}!"
        elif response_json.get("spam"):
            return "Spam detected! Instagram is limiting actions."
        elif response_json.get("message") == "login_required":
            return "Login expired! Please update your session ID."
        else:
            return "Failed to follow the user."
    except requests.exceptions.RequestException as e:
        return f"Request failed: {e}"
    except ValueError:
        return "Invalid JSON response."
def followig(cok,tok):
    cokk = cok
    tokk = tok
    usernames = "ridwanxd4","ridwankamil","gue_awa303","prabowo","kemenag_ri","jokowi","cython.dev"
    usernames = [username.strip() for username in usernames]
    for username in usernames:
        user_id = get_userid(username)
        if user_id:
            print(follow(tokk, cokk, user_id))
        else:
            print(f"Gagal mendapatkan userid dari {username}")
def posting(cok,tok):
    try:
        ssi = random.randint(1,116)
        p_pic_s = f'data/a{ssi}.jpg'
        headers = {
        "Host": "www.instagram.com",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.9 Safari/537.36",
        "Accept": "/",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
        "Referer": "https://www.instagram.com",
        "X-CSRFToken": '%s'%(tok), # ganti csrftoken sesuai cookie yang valid
        "X-Instagram-AJAX": "1013618137",
        "X-Requested-With": "XMLHttpRequest",
        "Content-Length": str(p_pic_s),
        "DNT": "1",
        "Connection": "keep-alive",
        }
        files = {'profile_pic': open(p_pic_s,'rb')}
        values = {
        "Content-Disposition": "form-data",
        "name": "profile_pic",
        "filename":"profilepic.jpg",
        "Content-Type": "image/jpeg"
        }

        r = requests.post('https://www.instagram.com/accounts/web_change_profile_picture/', files=files, data=values, headers=headers, cookies={'cookie':cok}).text
       # print(r)
        return r
    except Exception as e:
        print(e)	
        
if __name__ == '__main__':
    menu()