import requests, re, time, os, random, json, uuid
from faker import Faker
from datetime import datetime
from bs4 import BeautifulSoup as bs

from config.fake import FakeIdent
from config.profilpic import UploadProfile

Ok, Cp, Fail = 0, 0, 0

P = '\033[0m'
H = "\033[32m"
A = "\033[1;30m"
M = '\x1b[1;91m'

class Asset:
    def __init__(Jar):
        pass
    
    def kode(Jar, a):
        for sleep in range(int(a), 0, -1):
            print(f' > Tunggu code verifikasi {sleep}{" "*10}', end='\r')
            time.sleep(1)
    
    def default_headers(Jar, type: str) -> str:
        if type == 'Get':
            return {
                'host': 'www.instagram.com',
                'dpr': '1.712499976158142',
                'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
                'sec-ch-ua-mobile': '?1',
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua-platform-version': '"14.0.0"',
                'sec-ch-ua-model': '"itel S666LN"',
                'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Google Chrome";v="133.0.6943.137", "Chromium";v="133.0.6943.137"',
                'sec-ch-prefers-color-scheme': 'light',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-user': '?1',
                'sec-fetch-dest': 'document',
                'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
            }
        else:
            return {
                'host': 'www.instagram.com',
                'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Google Chrome";v="133.0.6943.137", "Chromium";v="133.0.6943.137"',
                'sec-ch-ua-platform': '"Android"',
                'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
                'sec-ch-ua-model': '"itel S666LN"',
                'sec-ch-ua-mobile': '?1',
                'x-ig-app-id': '1217981644879628',
                'x-requested-with': 'XMLHttpRequest',
                'accept': '*/*',
                'content-type': 'application/x-www-form-urlencoded',
                'x-instagram-ajax': '1020778384',
                'x-web-session-id': 'vjexvg:ay0wfo:wzgiu5',
                'x-asbd-id': '359341',
                'sec-ch-prefers-color-scheme': 'light',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
                'x-ig-www-claim': '0',
                'sec-ch-ua-platform-version': '"14.0.0"',
                'origin': 'https://www.instagram.com',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'referer': 'https://www.instagram.com/accounts/signup/email/',
                'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
            }
    
class MainMenu:
    def __init__(Jar):
        pass
    
    def menu(Jar):
        os.system('cls' if os.name == 'nt' else 'clear')
        print("""
 > 01. Buat akun instagram
 > 02. Tambahkan informasi profil
 > 03. exit
        """)
        user_input = input(" > pilih: ")
        if user_input == '1' or user_input == '01':
            Create().Setting()
        elif user_input == '2' or user_input == '02':
            pass
        elif user_input == '3' or user_input == '03':
            exit()
            
class Create:
    def __init__(Jar):
        pass
    
    def Setting(Jar):
        print("\n > ")
        try:
            total = int(input(" > Mau berapa akun yang di buat (default 5): ") or 5)
            delay = int(input(" > Masukkan waktu delay antar requests (default 60 detik): ") or 60)
        except ValueError:
            total, delay = 5, 60
        
        for i in range(total):
            AccountCreator()
            Jar.progres(i+1, total, delay)
        time.sleep(1.5)
        
    
    def progres(Jar, current, total, delay):
        for x in range(int(delay), 0, -1):
            print(f" > Progres: {current}/{total} | success: {Ok} | checkpoint: {Cp} | Failed: {Fail} | Next: {x}s ", end='\r')
            time.sleep(1)
            if current == total:
                break

class AccountCreator:
    def __init__(Jar):
        Jar.session = requests.Session()
        Jar.data_collection()
        Jar.mulai_pembuatan()
    
    def data_collection(Jar):
        Jar.nama_depan = FakeIdent().generate_name()
        Jar.birthdate = Jar.buat_tanggal_lahir()
        Jar.password = Jar.nama_depan.lower().replace(" ", "") +'1234'
        Jar.email = Jar.buat_email()
    
    def buat_nama(Jar):
        fake = Faker("id_ID")
        first_name = fake.first_name_female()
        last_name = fake.last_name_female()
        return f'{first_name} {last_name}'
        
    def buat_tanggal_lahir(Jar):
        year = random.randint(1980, 2007)
        month = random.randint(1, 12)
        day = random.randint(1, 28)
        return f"{day:02d}-{month:02d}-{year}"
        
    def buat_email(Jar):
        return f'{Jar.nama_depan.lower().replace(" ", "")}{str(random.randint(1000, 10000))}@inboxkitten.com'
    
    def dapatkan_kode(Jar, nama):
        try:
            headers = {
                'host': 'inboxkitten.com',
                'sec-ch-ua-platform': '"Android"',
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36',
                'accept': 'application/json, text/plain, */*',
                'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
                'sec-ch-ua-mobile': '?1',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'referer': f'https://inboxkitten.com/inbox/{nama}/list',
                'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
            }
            response = Jar.session.get(f'https://inboxkitten.com/api/v1/mail/list?recipient={nama}', headers=headers)
            if response.status_code != 200:
                return None
            
            data = response.json()
            if not isinstance(data, list) or len(data) == 0:
                return None
                
            email_data = data[0]
            storage = email_data.get("storage", {})
            key = storage.get("key")
            region = storage.get("region")
            if key and region:
                url = 'https://inboxkitten.com/api/v1/mail/getKey'
                params = {'region': region,'key': key}
                headers['referer'] = f'https://inboxkitten.com/inbox/{nama}/message/{region}/{key}'
                response2 = Jar.session.get(url, params = params, headers = headers)
                if response2.status_code != 200:
                    return None
                
                json_data = response2.json()
                subject = json_data.get("subject")
                if not subject:
                    return None
                
                code = re.search(r'(\d+)', subject)
                if code:
                    return code.group(1)
            return None
            
        except Exception as e:
            print(e)
    
    def mulai_pembuatan(Jar):
        try:
            headers = Asset().default_headers('Get')
            Jar.session.headers.update(headers)
            response = Jar.session.get('https://www.instagram.com/accounts/signup/email/').text
            Jar.machine_id = re.search('"machine_id":"(.*?)"', response).group(1)
            Jar.device_id = re.search('"device_id":"(.*?)"', response).group(1)
            Jar.csrf_token = re.search('"csrf_token":"(.*?)"', response).group(1)
            Jar.enpas = '#PWD_INSTAGRAM_BROWSER:0:{}:{}'.format(int(time.time()), Jar.password)
            Jar.headers_post = Asset().default_headers('Post')
            Jar.email_signup()
        except Exception as e:
            print(e)
    
    def email_signup(Jar):
        try:
            Jar.session.headers.update({
                **Jar.headers_post,
                'x-csrftoken': Jar.csrf_token,
            })
            data = {'email': Jar.email}
            response = Jar.session.post('https://www.instagram.com/api/v1/web/accounts/check_email/', data=data)
            if '"valid":true' in response.text:
                Jar.send_verif_email()
            else:
                print(' > goblok')
        except Exception as e:
            raise e
    
    def send_verif_email(Jar):
        try:
            Jar.session.headers.update({
                **Jar.headers_post,
                'x-csrftoken': Jar.csrf_token,
            })
            data = {"device_id": Jar.machine_id, "email": Jar.email}
            response = Jar.session.post('https://www.instagram.com/api/v1/accounts/send_verify_email/', data=data)
            if '"email_sent":true' in response.text:
                Asset().kode(20)
                Jar.codeV = Jar.dapatkan_kode(Jar.email) 
                print(f" > verification code > {Jar.codeV}{' ' *40}", end = '\r')
                Jar.verif_email()
            else:
                print(' > gagal kirim code')
        except Exception as e:
            raise e
    
    def verif_email(Jar):
        try:
            Jar.session.headers.update({
                **Jar.headers_post,
                'x-csrftoken': Jar.csrf_token,
            })
            data = {"code": Jar.codeV, "device_id": Jar.machine_id, "email": Jar.email}
            response = Jar.session.post('https://www.instagram.com/api/v1/accounts/check_confirmation_code/', data=data)
            if '"status":"ok"' in response.text:
                Jar.signup_code = response.json().get('signup_code')
                Jar.attempt()
            else:
                print(' > gagal verifikasi email')
        except Exception as e:
            raise e
    
    def attempt(Jar):
        try:
            Jar.session.headers.update({
                **Jar.headers_post,
                'x-csrftoken': Jar.csrf_token,
            })
            data = {
                "enc_password": Jar.enpas,
                "email": Jar.email,
                "failed_birthday_year_count": "{}",
                "first_name": Jar.nama_depan,
                "username": "",
                "seamless_login_enabled": "1",
                "use_new_suggested_user_name": "true",
            }
            response = Jar.session.post('https://www.instagram.com/api/v1/web/accounts/web_create_ajax/attempt/', data=data)
            if '"status": "ok"' in response.text:
                Jar.username = response.json().get('username_suggestions')[1]
                Jar.age_eligibility()
            else:
                print(' > tak tau la')
        except Exception as e:
            raise e
    
    def age_eligibility(Jar):
        try:
            Jar.session.headers.update({
                **Jar.headers_post,
                'x-csrftoken': Jar.csrf_token,
            })
            data = {
                "day": Jar.birthdate.split('-')[0],
                "month": Jar.birthdate.split('-')[1],
                "year": Jar.birthdate.split('-')[2],
            }
            response = Jar.session.post('https://www.instagram.com/api/v1/web/consent/check_age_eligibility/', data=data)
            if '"eligible_to_register":true' in response.text:
                Jar.final_create()
            else:
                print('> "eligible_to_register":false')
        except Exception as e:
            raise e
    
    def final_create(Jar):
        global Ok, Cp, Fail
        try:
            Jar.session.headers.update({
                **Jar.headers_post,
                'x-csrftoken': Jar.csrf_token,
            })
            data = {
                "enc_password": Jar.enpas,
                "day": Jar.birthdate.split('-')[0],
                "email": Jar.email,
                "failed_birthday_year_count": "{}",
                "first_name": Jar.nama_depan,
                "month": Jar.birthdate.split('-')[1],
                "username": Jar.username,
                "year": Jar.birthdate.split('-')[2],
                "client_id": Jar.machine_id,
                "seamless_login_enabled": "1",
                "tos_version": "row",
                "force_sign_up_code": Jar.signup_code,
                "extra_session_id": "vjexvg:ay0wfo:wzgiu5",
            }
            response = Jar.session.post('https://www.instagram.com/api/v1/web/accounts/web_create_ajax/', data=data)
            if '"account_created":true' in response.text:
                cookie = ';'.join(['%s=%s'%(key,value) for key,value in Jar.session.cookies.get_dict().items()])
                ds_user_id = re.search('ds_user_id=(\d+)', cookie).group(1)
                sessionid = re.search(r'sessionid=([^;]+)', cookie).group(1)
                cookies = f'ds_user_id={ds_user_id};sessionid={sessionid}'
                follow = Jar.follow_dong(cookie)
                #UploadProfile(cookie).ganti_profie()
                #up_id = UploadProfile(cookie).upload1()
                #profil = UploadProfile(cookie).upload2(up_id)
                Ok+=1
                print(f"""\r{' '*72}
 > success Create
  > nama    : {Jar.nama_depan}
  > username: {Jar.username}
  > email   : {Jar.email.replace('inboxkitten.com', 'yahaha.com')}
  > password: {Jar.enpas}
  > birthday: {Jar.birthdate}
  > follow  : {follow}
  > cookie  : {cookies}
                """)
                result = f"{Jar.nama_depan}|{Jar.password}\n{Jar.email}|{Jar.username}\n{Jar.birthdate}\n{cookie}\n"
                with open('Data/NewAccount.json', 'a') as file:
                    file.write(result)
            elif '"account_created":false' in response.text:
                print(' > account_created: false')
            elif 'https://www.instagram.com/accounts/suspended/' in response.text:
                print(' > akun terkena suspended')
            else:
                print(' > tak tau')
                Cp+=1
        except Exception as e:
            raise e
    
    def follow_dong(Jar, cookie):
        try:
            with requests.Session() as r:
                userid = re.search("ds_user_id=(\\d+)", cookie).group(1)
                r.headers.update({
                    'host': 'i.instagram.com',
                    'accept-language': 'id-ID, en-US',
                    'x-ig-connection-type': "MOBILE(LTE)",
                    'ig-u-ds-user-id': userid,
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'x-bloks-version-id': '16e9197b928710eafdf1e803935ed8c450a1a2e3eb696bff1184df088b900bcf',
                    'user-agent': 'Instagram 368.0.0.45.96 Android (34/14; 274dpi; 720x1471; ITEL/Itel; itel S666LN; itel-S666LN; mt6789; in_ID; 700073482)',
                })
                dev = 'android-{}'.format(str(uuid.uuid4().hex))[:16]
                data = {
                    'signed_body': f'SIGNATURE.{{"include_follow_friction_check":"1","user_id":"72846933362","radio_type":"mobile-lte","_uid":"{userid}","device_id":"{dev}","_uuid":"{str(uuid.uuid4())}","nav_chain":"ExploreFragment:explore_popular:2:main_search:{time.time():.3f}:::{time.time():.3f},ForYouSerpGridFragment:serp_top:4:button:{time.time():.3f}:::{time.time():.3f},UserDetailFragment:profile:5:search_result:{time.time():.3f}:::{time.time():.3f},ProfileMediaTabFragment:profile:6:button:{time.time():.3f}:::{time.time():.3f}","container_module":"profile"}}'
                }
                response = r.post("https://i.instagram.com/api/v1/friendships/create/72846933362/", data=data, cookies={'cookie': cookie}).json()
                if response.get("friendship_status", {}).get("following"):
                    return f'{H}True{P}'
                else:
                    return f'{M}False{P}'
        except:pass
            
if __name__ == '__main__':
    MainMenu().menu()