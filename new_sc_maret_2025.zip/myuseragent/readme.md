# GenerateUserAgent

GenerateUserAgent adalah alat untuk menghasilkan User-Agent Instagram secara acak berdasarkan berbagai perangkat Android populer. Tools ini berguna untuk **web scraping**, **otomasi**, atau **pengujian API** yang memerlukan User-Agent valid.

## Fitur
- Menghasilkan User-Agent Instagram yang valid.
- Memilih perangkat dari daftar smartphone populer (Google Pixel, Samsung, Xiaomi, dll.).
- Menyesuaikan versi Android dan API Level secara acak.
- Menentukan resolusi layar dan DPI secara dinamis.

## Instalasi
Gunakan Python 3 dan pastikan Anda memiliki pip terinstal. Clone repositori atau salin skrip ke direktori lokal Anda.

```bash
# Clone repository
git clone https://github.com/Fajarrrrky/insta-useragent
cd insta-useragent
```

## Penggunaan
Jalankan skrip untuk mendapatkan User-Agent acak:

```python
from generateuseragent import GenerateUserAgent

ua = GenerateUserAgent()
print(ua.get_useragent())
```

Atau jalankan langsung dari terminal:
```bash
python generateuseragent.py
```

## Contoh Output
```text
Instagram 368.0.0.45.96 Android (33/14; 480dpi; 1080x2400; Samsung; Galaxy S23 Ultra; dm3q; qcom; in_ID; 700073482)
```

## Lisensi
Proyek ini dirilis di bawah lisensi MIT. Silakan gunakan dan modifikasi sesuai kebutuhan.

## Kontribusi
Pull request dipersilakan! Untuk perubahan besar, silakan buka issue terlebih dahulu untuk mendiskusikan apa yang ingin Anda ubah.

---

Dibuat oleh [Fajarrrrky](https://github.com/Fajarrrrky).

