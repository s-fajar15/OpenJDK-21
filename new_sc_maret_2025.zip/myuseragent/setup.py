from setuptools import setup, find_packages

setup(
    name="myuseragent",
    version="0.1",
    author="Saepul fajar",
    author_email="saepulfajar440@gmail.com",
    description="Generator User-Agent Instagram untuk Android",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/Fajarrrrky/insta-useragent",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)