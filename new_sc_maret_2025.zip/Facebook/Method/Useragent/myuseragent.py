import random, subprocess

class DeviceCatalog:
	
	def generate_model(Jar):
		return {
			"Realme": ["Realme 12 Pro", "Realme GT Neo 6", "Realme C67", "Realme Narzo 60"],
			"Samsung": ["SM-A135F"],
			"Oppo": ["CPH2591"],
			"Vivo": ["Vivo X100 Pro", "Vivo V30", "Vivo Y200", "Vivo T2 5G"],
			"Huawei": ["Huawei P70 Pro", "Huawei Mate 60", "Huawei Nova 12", "Huawei Enjoy 70"],
			"Google": ["Pixel 9 Pro", "Pixel 8a", "Pixel 7", "Pixel Fold 2"],
			"Xiaomi": ["23053RN02A", "22111317PG"]
		}

class GenerateUseragent:
	
	os_ver = {'9': 'PPR1', '10': 'QP1A', '11': 'RP1A', '12': 'SP1A', '13': 'TP1A', '14': 'UP1A'}
	
	def __init__(Jar):
		Jar.brand = DeviceCatalog().generate_model()
		Jar.model_list = list(Jar.brand.keys())
	
	def versi_chrome(Jar):
		return f'{random.randrange(100, 133)}.0.{random.randrange(4200, 6900)}.{random.randrange(40, 190)}'
		
	def android_version(Jar, android_version):
		return Jar.os_ver.get(str(android_version), 'AP4A')
		
	def get_device(Jar, brand=None, system=False):
		if system:return Jar.get_system_device()
		if not brand or brand not in Jar.brand:
			brand = random.choice(Jar.model_list)
		model = random.choice(Jar.brand[brand])
		android = random.choice(['9', '10', '11', '12', '13', '14', '15'])
		build_code = Jar.android_version(android)
		build =f"{build_code}.{random.randint(211111, 233333)}.00{random.randint(1, 9)}"
		return {"model": model, 'android': android, 'chrome': Jar.versi_chrome(), 'build': build}
	
	def get_system_device(Jar):
		try:
			model = subprocess.check_output("getprop ro.product.model", shell=True).decode().strip()
			android = subprocess.check_output("getprop ro.build.version.release", shell=True).decode().strip()
			build = subprocess.check_output("getprop ro.product.build.id", shell=True).decode().strip()
			if not model or not android or not build:
				Jar.get_device()
			return {"model": model, 'android': android, 'chrome': Jar.versi_chrome(), 'build': build}
		except Exception:
			Jar.get_device()
	
	def get_device_2(Jar, brand=None, system=False):
		if system:return Jar.get_system_dalvik()
		if not brand or brand not in Jar.brand:
			brand = random.choice(Jar.model_list)
		model = random.choice(Jar.brand[brand])
		android = random.choice(['9', '10', '11', '12', '13', '14', '15'])
		simcard = random.choice(['Telkomsel', 'XL Axiata', 'Indosat', 'Smartfren', 'Tri'])
		return {'brand': brand, 'brand2': brand,'model': model, 'android': android, 'cpu': 'arm64-v8a', 'simcard': simcard}
		
	
	def get_system_dalvik(Jar):
		try:
			brand = subprocess.check_output("getprop ro.product.manufacturer", shell=True).decode().strip()
			brand2 = subprocess.check_output("getprop ro.product.brand", shell=True).decode().strip()
			model = subprocess.check_output("getprop ro.product.model", shell=True).decode().strip()
			android = subprocess.check_output("getprop ro.build.version.release", shell=True).decode().strip()
			simcard = subprocess.check_output('getprop gsm.operator.alpha', shell=True).decode().strip().split(",")[1].replace("\n","")
			cpu = subprocess.check_output("getprop ro.product.cpu.abi", shell=True).decode().strip()
			if not model or not android or not cpu:
				Jar.get_device_2()
			return {'brand': brand, 'brand2': brand2, 'model': model, 'android': android, 'cpu': cpu, 'simcard': simcard}
		except Exception:
			Jar.get_device_2()
	
	def useragent(Jar, brand=None, system=False, dalvik=False):
		density, width, height = round(random.uniform(1.0, 4.0), 2), random.randint(720, 1440), random.randint(1280, 2560)
		
		if dalvik:
			device_info = Jar.get_device_2(brand, system)
			brand, brand2, model, android, cpu, simcard = device_info.values()
			return f'[FBAN/FB4A;FBAV/486.0.0.66.70;FBBV/653066364;FBDM/{{density={density},width={width},height={height}}};FBLC/id_ID;FBRV/0;FBCR/{simcard};FBMF/{brand};FBBD/{brand2};FBPN/com.facebook.katana;FBDV/{model};FBSV/{android};FBOP/1;FBCA/{cpu}:;]'
		else:
			device_info = Jar.get_device(brand, system)
			model, android, chrome, build = device_info.values()
			return f'Mozilla/5.0 (Linux; Android {android}; {model} Build/{build}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome} Mobile Safari/537.36'
		
if __name__ == "__main__":
    os = GenerateUseragent()