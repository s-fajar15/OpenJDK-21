# Butuh akses root
import time
import os

while True:
	current_time = time.strftime("%H:%M:%S", time.localtime())
	print(f"{current_time} - Mode Pesawat diaktifkan!")
	os.system("su -c 'settings put global airplane_mode_on 1' > /dev/null 2>&1")
	os.system("su -c 'am broadcast -a android.intent.action.AIRPLANE_MODE --ez state true' > /dev/null 2>&1")
	time.sleep(5)
	
	current_time = time.strftime("%H:%M:%S", time.localtime())
	print(f"{current_time} - Mode Pesawat dinonaktifkan!")
	os.system("su -c 'settings put global airplane_mode_on 0' > /dev/null 2>&1")
	os.system("su -c 'am broadcast -a android.intent.action.AIRPLANE_MODE --ez state false' > /dev/null 2>&1")
	time.sleep(120)
