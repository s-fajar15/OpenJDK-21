class Pws:

    def generate_passwords(self, nama, asal, pw_tambahan):
        nama = nama.lower()
        asal = asal.lower() if asal else ""
        nama_split = nama.split()
        nama_depan = nama_split[0] if len(nama_split) > 0 else ""
        nama_belakang = nama_split[1] if len(nama_split) > 1 else ""
        pasw = set()

        if len(nama_depan) >= 3:
            pasw.update([
                nama_depan + "01",
                nama_depan + "02",
                nama_depan + "123",
                nama_depan + "12345",
                nama_depan + nama_belakang,
            ])

        if len(nama_belakang) >= 3:
            pasw.update([
                nama_belakang + "05",
                nama_belakang + "04",
                nama_belakang + "123",
                nama_belakang + "12345",
                nama_belakang + nama_depan,
            ])

        if len(asal) >= 3:
            pasw.update([
                asal,
                asal + "123",
            ])

        pasw.update(pw.lower() for pw in pw_tambahan if len(pw) >= 6)
        return list(pasw)[:8]
