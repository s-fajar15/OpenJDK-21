import os
import json
import random

class UserAgent:

    def __init__(self):
        ua_ig_path = "data/cache/.ua_ig.json"
        ua_fb_path = "data/cache/.ua_fb.json"
        sett_uaig_path = "data/cache/.sett_UaIG.json"
        sett_uafb_path = "data/cache/.sett_UaFB.json"
        
        if os.path.exists(sett_uaig_path):
            ua_ig_path = sett_uaig_path
        
        if os.path.exists(sett_uafb_path):
            ua_fb_path = sett_uafb_path
        
        with open(ua_fb_path, "r") as f:
            self.ua_fb = json.load(f)
        with open(ua_ig_path, "r") as a:
            self.ua_ig = json.load(a)

        self.android_versions = [
            "4.4.2", "5.0.1", "5.1.1", "6.0.1", "7.0", "7.1.2",
            "8.0.0", "8.1.0", "9", "10", "11", "12", "13", "14"
        ]
        self.api_devices = [d for d in self.ua_fb if "Ultra" in d['model'] or "+" in d['model']]

        if not self.api_devices:
            self.api_devices = self.ua_fb


    def ua_facebook(self, api_mode):
        if "api" in api_mode:
            while True:
                device = random.choice(self.api_devices)
                if "Unknown" in device["brand"] or "Unknown" in device["model"]:
                    continue  

                dpi = f"{round(float(device['density']) * 160)}"
                ua1 = {
                    'FBAN': 'FB4A',
                    'FBAV': "100.0.0.20.70",  # Facebook versi 2016
                    'FBBV': str(random.randint(20000000, 50000000)),
                    'FBDM': f"{{density={dpi},width={device['width']},height={device['height']}}}",
                    'FBLC': "id_ID",
                    'FBRV': '0',
                    'FBCR': device['operators'],
                    'FBMF': device['brand'],
                    'FBBD': device['brand'],
                    'FBPN': "com.facebook.katana",
                    'FBDV': device['model'],
                    'FBSV': device.get('android_version', random.choice(self.android_versions)),
                    'FBOP': '1',
                    'FBCA': "armeabi-v7a:;",
                }
                ua2 = {
                    'FBAN': 'FB4A',
                    'FBAV': "50.0.0.30.89",  # Facebook Lite versi 2016
                    'FBBV': str(random.randint(10000000, 40000000)),
                    'FBDM': f"{{density={dpi},width={device['width']},height={device['height']}}}",
                    'FBLC': "id_ID",
                    'FBRV': '0',
                    'FBCR': device['operators'],
                    'FBMF': device['brand'],
                    'FBBD': device['brand'],
                    'FBPN': "com.facebook.lite",
                    'FBDV': device['model'],
                    'FBSV': device.get('android_version', random.choice(self.android_versions)),
                    'FBOP': '1',
                    'FBCA': "armeabi-v7a:;",
                    }
                ua3 = {
                    'FBAN': 'FB4A',
                    'FBAV': "90.0.0.17.69",  # Facebook versi 2015
                    'FBBV': str(random.randint(30000000, 60000000)),
                    'FBDM': f"{{density={dpi},width={device['width']},height={device['height']}}}",
                    'FBLC': "id_ID",
                    'FBRV': '0',
                    'FBCR': device['operators'],
                    'FBMF': device['brand'],
                    'FBBD': device['brand'],
                    'FBPN': "com.facebook.mahos",
                    'FBDV': device['model'],
                    'FBSV': device.get('android_version', random.choice(self.android_versions)),
                    'FBOP': '1',
                    'FBCA': "armeabi:;",
                }

                chosen_ua = random.choice([ua3])
                ua_parts = [f"{k}/{v}" for k, v in chosen_ua.items()]
                return f"[{';'.join(ua_parts)}]".replace('  ', ' ')

        else:
            while True:
                device = random.choice(self.ua_fb)
                if "Unknown" in device["brand"] or "Unknown" in device["model"]:
                    continue

                build_prefix = random.choice(["TP1A", "SP1A", "SQ3A"])
                build_date = f"{random.randint(20, 23)}{random.randint(1,12):02}"
                build_number = f"{build_prefix}.{build_date}.{random.randint(100, 999)}"

                chrome_versions = [f"12{random.randint(0,2)}.0.{random.randint(1000, 9999)}.{random.randint(1, 99)}" for _ in range(3)]
                firefox_versions = ["115.0", "114.0.2"]
                edge_versions = [f"12{random.randint(0,2)}.0.{random.randint(1000, 9999)}.0" for _ in range(2)]
                browser_variants = ["Chrome", "Firefox", "Edge"]
                browser_variant = random.choice(browser_variants)

                android_version = random.choice(self.android_versions)
                if device["brand"].lower() == "samsung":
                    samsung_version = random.choice(["25.0.1.251", "24.0.0.7"])
                    chrome_core_version = random.choice(["114.0.5735.196", "115.0.5790.186"])
                    user_agent = (
                        f"Mozilla/5.0 (Linux; Android {android_version}; {device['model']} Build/{build_number}) "
                        f"AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/{samsung_version} Chrome/{chrome_core_version} Mobile Safari/537.36"
                    )
                else:
                    browser_version = (
                        random.choice(chrome_versions) if browser_variant == "Chrome"
                        else random.choice(firefox_versions) if browser_variant == "Firefox"
                        else random.choice(edge_versions)
                    )
                    user_agent = (
                        f"Mozilla/5.0 (Linux; Android {android_version}; {device['device']} Build/{build_number}) "
                        f"AppleWebKit/537.36 (KHTML, like Gecko) {browser_variant}/{browser_version} Mobile Safari/537.36"
                    )

                return user_agent.replace('  ', ' ')



    def get_valid_device(self):
        while True:
            device = random.choice(self.ua_ig)
            if any(val.lower() in ["unknown", ""] for val in [device["brand"], device["model"], device["model_chipset"]]):
                continue
            return device


    def ua_instagram(self, barcelona):
        version = '364.0.0.35.110' if barcelona else '360.0.0.52.192'
        version_code = '687078620' if barcelona else '672535977'
        device = self.get_valid_device()

        android_versions = [
            ('34', '12'), ('33', '11'),
            ('32', '10'), ('31', '10'),
            ('30', '11'), ('29', '10'),
            ('28', '9')
        ]
        android_ver = random.choice(android_versions)

        dpi = f"{round(float(device['density']) * 160)}dpi"
        chipset_mapping = {
            'qualcomm': lambda x: 'qcom',
            'exynos': lambda x: x.replace('_', ''),
            'mediatek': lambda x: x.split('_')[1] if "_" in x else x,
            'tensor': lambda x: 'tensor',
            'dimensity': lambda x: x.split('_')[1] if "_" in x else x,
            'helio': lambda x: x.split('_')[1] if "_" in x else x
        }

        chipset = device["model_chipset"].lower()
        processed_chipset = chipset.split('_')[0]
        for key in chipset_mapping:
            if key in chipset:
                processed_chipset = chipset_mapping[key](chipset)
                break

        model_prefix = ''.join([c for c in device['model'] if c.isalpha()])
        model_number = ''.join([c for c in device['model'] if c.isdigit()])
        short_model = f"{model_prefix.lower()}{model_number[:2]}" if model_prefix else device['model'][:4]
        #bahasa = random.choice(["in_ID", "fa_IR", "bs_BA", "en_ZA", "ar_AR", "es_MX"])
        ua1 = (
            f'Instagram {version} Android '
            f'({android_ver[0]}/{android_ver[1]}; '
            f'{dpi}; '
            f'{device["width"]}x{device["height"]}; '
            f'{device["brand"].lower()}; '
            f'{device["model"]}; '
            f'{short_model}; '
            f'{processed_chipset}; '
            f'in_ID; '
            f'{version_code})'
        )
        ua2 = (
            f'Instagram {version} Android '
            f'({android_ver[0]}/{android_ver[1]}; '
            f'{dpi}; '
            f'{device["width"]}x{device["height"]}; '
            f'{device["brand"]}/{device["model"]}; '
            f'{device["device"]}; '
            #f'{short_model}; '
            f'{processed_chipset}; '
            f'in_ID; '
            f'{version_code})'
        )
        ua3 = (
            f'Barcelona 348.1.0.44.109 Android '
            f'({android_ver[0]}/{android_ver[1]}; '
            f'{dpi}; '
            f'{device["width"]}x{device["height"]}; '
            f'{device["brand"].lower()}; '
            f'{device["model"]}; '
            f'{short_model}; '
            f'{processed_chipset}; '
            f'in_ID; '
            f'640443180)'
        )
        return random.choice([ua1, ua3]).replace('  ', ' ')


"""
import os
os.system("clear")
ua = UserAgent()
for _ in range(6):
    print()
    print(ua.ua_facebook("api"))
    print(ua.ua_facebook("bkn"))

"""