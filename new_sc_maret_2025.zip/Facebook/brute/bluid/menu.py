import os, re, requests, json

from .akses import Cek_lisen
from .logo import Logo

from yxdfb.Fesnuk import Wangsaff
from yxdig.kyna import Insta
from botfb.kyna import Main

M = '\x1b[1;91m' # MERAH
H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
N = '\x1b[0m'	 # WARNA MATI
R = "\x1b[0;31m" # Merah

class yayanxd:

    def __init__(self):
        pass

    def cekin(self):
        paket, lim = Cek_lisen().cek_lisen()
        asu = (
    f"""
        Hello {H}{paket["nama"]}!{N}, Anda adalah pengguna {lim}.  
  Lisensi Anda aktif hingga {M}{paket["expired"]}{N}, tersisa {H}{paket["readtext"]}{N}.  
  Gunakan tools ini dengan bijak dan manfaatkan sebaik mungkin! 🚀
""")
        yxz = self.remove_ansi(lim)
        if "Trial" in yxz:
            sc_crk_ig = f"[{H}Active{N}]"
            sc_crk_fb = f"[{H}Active{N}]"
            sc_bot_fb = f"[{H}Active{N}]"
            sc_bot_ig = f"[{H}Active{N}]"
        else:
            sc_crk_ig = f"[{H}Active{N}]" if "sc ig" in paket["paket"] else f"[{M}Not Active{N}]"
            sc_crk_fb = f"[{H}Active{N}]" if "sc fb" in paket["paket"] else f"[{M}Not Active{N}]"
            sc_bot_fb = f"[{H}Active{N}]" if "bot fb" in paket["paket"] else f"[{M}Not Active{N}]"
            sc_bot_ig = f"[{H}Active{N}]" if "bot ig" in paket["paket"] else f"[{M}Not Active{N}]"

        return sc_crk_ig, sc_crk_fb, sc_bot_fb, sc_bot_ig, yxz, asu

    def hapus(self):
        os.system("git pull")
        patch = [
            "botfb/data/apcb.txt"
            "data/HASIL-CEK-CP/CP/apcb.txt", "data/HASIL-CEK-CP/OK/apcb.txt", "data/HASIL-CEK-CP/json/apcb.txt",
            "data/result/OK/apcb.txt", "data/result/CP/apcb.txt", "data/results/OK/apcb.txt", "data/results/CP/apcb.txt",

        ]
        for file in patch:
            if os.path.exists(file):
                try:
                    os.remove(file)
                except:pass
            else:pass

    def remove_ansi(self, text):
        ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_escape.sub('', text)

    def menu(self):
        sc_crk_ig, sc_crk_fb, sc_bot_fb, sc_bot_ig, lim, asw  = self.cekin()
        while True:
            Logo("barme")
            print(asw)
            print(
        f"""    Jika status {M}Not Active{N} silahkan aktifkan paket tambahan
        agar status akses ke script nya menjadi {H}Active{N}

  01. Start Crack FB {sc_crk_fb}
  02. Start Crack IG {sc_crk_ig}
  03. Start Bot Fesnuk {sc_bot_fb}
""")
            asu = input(" >> ")
            if asu in ["1", "01"]:
                self.save_to_json("data/cache/.ua_fb.json", "https://pastebin.com/raw/69wptz3D")
                if "[Active]" in self.remove_ansi(sc_crk_fb):
                    Wangsaff(lim, asw)
                else:
                    exit(f"\n Anda tidak memiliki izin untuk mengakses {M}Script Crack FB{N}. Silakan tingkatkan paket layanan Anda melalui situs resmi: {H}https://mykey.yayanxd.my.id/{N}")

            elif asu in ["2", "02"]:
                self.save_to_json("data/cache/.ua_ig.json", "https://pastebin.com/raw/dgRettD3")
                if "[Active]" in self.remove_ansi(sc_crk_ig):
                    Insta(lim, asw).menu()
                else:
                    exit(f"\n Anda tidak memiliki izin untuk mengakses {M}Script Crack IG{N}. Silakan tingkatkan paket layanan Anda melalui situs resmi: {H}https://mykey.yayanxd.my.id/{N}")

            elif asu in ["3", "03"]:
                if "[Active]" in self.remove_ansi(sc_bot_fb):
                    Main(lim, asw).main_menu()
                else:
                    exit(f"\n Anda tidak memiliki izin untuk mengakses {M}Script Bot FB{N}. Silakan tingkatkan paket layanan Anda melalui situs resmi: {H}https://mykey.yayanxd.my.id/{N}")


    def save_to_json(self, filename, remote_url):
        try:
            headers = {
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'id,id-ID;q=0.9,en-US;q=0.8,en;q=0.7,ga;q=0.6',
                'cache-control': 'max-age=0',
                'priority': 'u=0, i',
                'referer': 'https://pastebin.com/69wptz3D',
                'sec-ch-ua': '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
                'sec-ch-ua-arch': '"x86"',
                'sec-ch-ua-bitness': '"64"',
                'sec-ch-ua-full-version': '"133.0.6943.141"',
                'sec-ch-ua-full-version-list': '"Not(A:Brand";v="99.0.0.0", "Google Chrome";v="133.0.6943.141", "Chromium";v="133.0.6943.141"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-model': '""',
                'sec-ch-ua-platform': '"Linux"',
                'sec-ch-ua-platform-version': '"6.8.0"',
                'sec-fetch-dest': 'document',
                'sec-fetch-mode': 'navigate',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-user': '?1',
                'upgrade-insecure-requests': '1',
                'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
            }
            response = requests.get(remote_url, headers=headers)
            response.raise_for_status()
            new_data = response.json()
        except requests.exceptions.RequestException as e:
            exit(f"\n[{M}!{N}] Gagal mengambil data")
        except json.JSONDecodeError:
            exit(f"\n[{M}!{N}] Data dari web tidak valid (bukan JSON)")

        if os.path.exists(filename):
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    old_data = json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                old_data = []
        else:
            old_data = []

        if new_data != old_data:
            if os.path.exists(filename):
                try:os.remove(filename)
                except:pass
        
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(new_data, f, indent=2, ensure_ascii=False)