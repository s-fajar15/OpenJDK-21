import os, json, time, sys, platform
from urllib.error import URLError
from urllib.parse import quote
from urllib import request

M = '\x1b[1;91m' # MERAH
H = '\x1b[1;92m' # HIJAU
K = '\x1b[1;93m' # KUNING
N = '\x1b[0m'	 # WARNA MATI

class Cek_lisen:

    def __init__(self):
        self.kya = "data/cache/.lisen.txt" #/data/data/com.termux/files/home/.lisen.txt
        self.url = "https://licensi.yayanxd.my.id"

    def cek_lisen(self):
        try:
            key = open(self.kya, "r").read()
        except FileNotFoundError:
            self.login_key()
        
        dev = self.cek_device()
        try:
            devc = quote(f"{dev['brand']} {dev['device']}")
            xnxx = request.urlopen(f"{self.url}/check.php?key={key}&dev={devc}")
            asuu = json.loads(xnxx.read())
            tod  = asuu["usage"].replace("premium", f"{H}Premium{N}").replace("trial", f"{M}Trial{N}")

            if asuu["status"] == "error":
                print(f"\n[{M}×{N}] {asuu['msg']}");exit()
            elif asuu["status"] in ["kadaluarsa", "sudah kadaluarsa"]:
                print(f"\n[{M}×{N}] opsh key anda telah mencapai batas masa aktif nya, silahkan upgrade ke premium.")
                time.sleep(5)
                os.system("xdg-open https://mykey.yayanxd.my.id/")
                exit()
        except KeyError:
            print(f"\n[{M}×{N}] {asuu['msg']}");exit()
        except (json.decoder.JSONDecodeError, URLError):
            print(f"\n[{M}×{N}] gagal menghubungkan ke server, silahkan cek koneksi anda dan mainkan mode pesawat 5 detik.");exit()
        return asuu, tod

    def cek_device(self):
        system_name = platform.system()
        os_name = os.popen("uname -o").read().strip()
        device_info = {"brand": "unknown","device": "unknown"}

        if system_name == "Windows":
            device_info["brand"] = "Windows"
            device_info["device"] = platform.node()
        elif system_name == "Darwin":
            device_info["brand"] = "Apple"
            device_info["device"] = platform.node()
        elif system_name == "Linux":
            if "Android" in os_name:
                device_info["brand"] = os.popen("getprop ro.product.manufacturer").read().strip() or "unknown"
                device_info["device"] = os.popen("getprop ro.product.marketname").read().strip() or os.popen("getprop ro.product.model").read().strip() or "unknown"
            else:
                try:
                    with open("/sys/devices/virtual/dmi/id/sys_vendor", "r") as f:
                        device_info["brand"] = f.read().strip() or "unknown"
                    with open("/sys/devices/virtual/dmi/id/product_name", "r") as f:
                        device_info["device"] = f.read().strip() or "unknown"
                except FileNotFoundError:
                    device_info["device"] = "Linux Machine"

        return device_info

    def login_key(self):
        if "win" in sys.platform:
            os.system("cls")
        else:
            os.system("clear")
        print(f"""
Hai! Selamat datang di script Brute Fb, jika ingin mendapatkan api key
    silahkan daftar ke situs ini: {H}https://mykey.yayanxd.my.id{N}
         -----------------------------------------------
""")
        key = input(f"[{H}*{N}] Masukkan API key kamu: ")
        if key in [""]:
            print(f"\n[{M}×{N}] Jangan kosong")
            time.sleep(3)
            self.login_key()
        
        dev = self.cek_device()
        try:
            devc = quote(f"{dev['brand']} {dev['device']}")
            reso = request.urlopen(f"{self.url}/check.php?key={key}&dev={devc}")
            xnxx = json.loads(reso.read())
            if xnxx["status"] == "error":
                print(f"\n[{M}×{N}] {xnxx['msg']}");exit()
            else:
                kadaluarsa = xnxx["expired"]
                user = xnxx["nama"]
                open(self.kya, "w").write(key)
                print(f"""\nHallo {H}{user}!{N} API key Anda masih berlaku sampai tanggal: {M}{kadaluarsa}{N}
Silakan gunakan dengan bijak ya 😊😊😊""")
                time.sleep(2)
                exit(f"\n[{M}!{N}] Jalankan ulang perintah dengan mengetik python run.py")
        except URLError:
            print(f"\n[{M}×{N}] Gagal menghubungkan ke server, silahkan cek koneksi Anda dan aktifkan mode pesawat 5 detik.")
            exit()